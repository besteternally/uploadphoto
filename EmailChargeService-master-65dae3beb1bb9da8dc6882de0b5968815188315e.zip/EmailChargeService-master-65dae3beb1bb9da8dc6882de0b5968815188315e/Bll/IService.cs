﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Bll
{
    [ServiceContract]
    interface IService
    {
        [OperationContract]
        string AddUser(string AmeUser, string UserName, string PassWord);

        [OperationContract]
        string ResetPwd(string AmeUser, string UserName, string OldPsw, string NewPsw);

        [OperationContract]
        string DeleteUser(string AmeUser, string UserName);

        [OperationContract]
        string ECCostSettlem(string AmeUser, string 年月);

        [OperationContract]
        string EC生成對賬單接口V6(string AmeUser, string 年月, string 賬單法人代碼, string 對賬窗口賬號, string 乙方公司代碼);

        [OperationContract]
        string EC生成對賬單BV5Y接口(string AmeUser, string 年月, string 事業群, string 賬單法人代碼, string 賬單法人名稱, string 對賬窗口賬號);
    }
}
