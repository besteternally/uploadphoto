
using Dal;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static Util.DownloadFile;
using static Util.PDFHelper;
using static Util.Compress;
using System.Web;

namespace Bll
{
    public class GetReportBll
    {
        private readonly log4net.ILog _log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private static readonly DbHelper dbhelper = new DbHelper();

        private static readonly string dzdReportUrl = dbhelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型 = '報表' and 參數名 = 'EC對賬單記錄查詢開票'").Split('&')[0];
        private static readonly string zjdReportUrl = dbhelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型 = '報表' and 參數名 = 'EC對賬單記錄查詢轉嫁'").Split('&')[0];
        private static readonly string ysdReportUrl = dbhelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型 = '報表' and 參數名 = 'EC對賬單記錄採購業務查詢'").Split('&')[0];
        private static readonly string ftpFileUrl = ConfigurationManager.AppSettings["ftpFileUrl"].ToString();
        private static readonly string reportUrl = System.Threading.Thread.GetDomain().BaseDirectory + "/DownLoad/report/djd/";
        private static readonly string zjdUrl = System.Threading.Thread.GetDomain().BaseDirectory + "/DownLoad/report/zjd/";
        private static readonly string mergrFileUrl = System.Threading.Thread.GetDomain().BaseDirectory + "/DownLoad/PDF/";
        private static readonly string mergrFileUrlDate = System.Threading.Thread.GetDomain().BaseDirectory + "/DownLoad/Purchasing/";
        private static readonly string mergrFzdUrlDate = System.Threading.Thread.GetDomain().BaseDirectory + "/DownLoad/Reconcilia/";

        /// <summary>
        /// 按订单年月分类生成每月对账单,费支单等PDF供对账管理员查看
        /// 按当前时间每天生成对账单,费支单等PDF供财务查看
        /// </summary>
        public void DoMain()
        {
            try
            {
                Dictionary<string, string> fzdFilenameMap = new Dictionary<string, string>();
                List<string> fzdFilenameList = new List<string>();
                List<string> largeFzdList = new List<string>();
                List<string> orderList = new List<string>();
                Dictionary<string,string> noFzdDzdList=new Dictionary<string, string>();
                //对接单
                DataTable dataTable = GetOrderNo();
                if (dataTable.Rows.Count > 0)
                {
                    //样式报表     
                    string url = ysdReportUrl +"&rs:Format=excel&rs:Command=Render";
                    if (!Directory.Exists(mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd")))
                    {
                        Directory.CreateDirectory(mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd"));
                    }

                    if (File.Exists(mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/" +
                                    DateTime.Now.ToString("yyyyMMdd") + "purchasingstyle.xls"))
                    {
                        File.Delete(mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/" + DateTime.Now.ToString("yyyyMMdd") + "purchasingstyle.xls");
                    }
                    DownLoadFileByUrl(url, mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/" + DateTime.Now.ToString("yyyyMMdd") + "purchasingstyle.xls");
                }
                foreach (DataRow dr in dataTable.Rows)
                {
                    orderList.Add(dr["訂單編號"].ToString().Trim());
                }
                foreach (DataRow dr in dataTable.Rows)
                {
                    Dictionary<string, string> fileMap = new Dictionary<string, string>();
                    string sql = "select 費支單,案號 from 收費對賬費支單表 where 來源訂單編號='" + dr["訂單編號"].ToString().Trim() + "' and 是否有效='Y' and 費支單 not like '%對賬單費支單合成檔.zip';";
                    DataTable dt = dbhelper.ExecuteSqlTable(sql);
                    if (dt.Rows.Count < 1)
                    {
                        noFzdDzdList.Add(dr["訂單編號"].ToString().Trim(), dr["年月"].ToString().Trim());
                        continue;
                    }
                    foreach (DataRow row in dt.Rows)
                    {
                        if (largeFzdList.Contains(row["案號"].ToString().Trim()))
                        {
                            continue;
                        }
                        fileMap.Add(dr["訂單編號"].ToString().Trim() + "@^@" + row["費支單"].ToString().Trim(), row["案號"].ToString().Trim());
                        if (fzdFilenameMap.Keys.Contains(row["案號"].ToString().Trim()))
                        {
                            continue;
                        }
                        fzdFilenameMap.Add(row["案號"].ToString().Trim(), ftpFileUrl + dr["訂單編號"].ToString().Trim() + "@^@" + row["費支單"].ToString().Trim());
                    }
                    string url = dzdReportUrl + "&NO=" + dr["訂單編號"].ToString().Trim() + "&rs:Format=PDF&rs:Command=Render";
                    DownLoadFileByUrl(url, dr["訂單編號"].ToString().Trim(), reportUrl);
                    MergePdf(reportUrl, ftpFileUrl, dr["訂單編號"].ToString().Trim(), mergrFileUrl + DateTime.Now.ToString("yyyyMMdd") + "/",mergrFileUrl + dr["年月"].ToString().Trim() + "/", fileMap, mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/", largeFzdList, orderList);
                    UpdateNoStatus(dr["訂單編號"].ToString().Trim(), true);
                }
                //费支单
                try
                {
                    if (fzdFilenameMap.Count > 0)
                    {
                        if (!Directory.Exists(mergrFzdUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/"))
                        {
                            Directory.CreateDirectory(mergrFzdUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/");
                        }

                        foreach (var a in fzdFilenameMap)
                        {
                            //fzdFilenameList.Add(a);
                            File.Copy(a.Value,
                                mergrFzdUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/" + $"{a.Key}.pdf", true);
                        }

                        //mergePDFFiles(fzdFilenameList, mergrFzdUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/" + DateTime.Now.ToString("yyyyMMdd") + "FZD.pdf");
                    }
                }
                catch(Exception ex)
                {
                    _log.Error(ex);
                }
                //转嫁单
                List<string> zjdFilePDFList = new List<string>();
                List<string> zjdFileExcelList = new List<string>();
                DataTable zjdDT = GetZJDOrderNo();
                foreach (DataRow dr in zjdDT.Rows)
                {
                    string url = zjdReportUrl + "&NO=" + dr["訂單編號"].ToString().Trim();
                    DownLoadFileByUrl(url + "&rs:Format=PDF&rs:Command=Render", dr["訂單編號"].ToString().Trim(), zjdUrl, dr["年月"].ToString().Trim());
                    DownLoadExcelByUrl(url + "&rs:Format=excel&rs:Command=Render", dr["訂單編號"].ToString().Trim(), zjdUrl, dr["年月"].ToString().Trim());
                    MergePDF(zjdUrl, dr["年月"].ToString().Trim(), mergrFileUrl + dr["年月"].ToString().Trim() + "/");
                    MergeExcle(zjdUrl, dr["年月"].ToString().Trim(), mergrFileUrl + dr["年月"].ToString().Trim() + "/");

                    zjdFilePDFList.Add(zjdUrl + dr["年月"].ToString() + dr["訂單編號"].ToString().Trim() + "Report.pdf");
                    zjdFileExcelList.Add(zjdUrl + dr["年月"].ToString().Trim() + dr["訂單編號"].ToString().Trim() + "Report.xls");

                    UpdateNoStatus(dr["訂單編號"].ToString().Trim(), false);
                }
                //合并每天的转嫁单
                if (zjdFilePDFList.Count != 0)
                {
                    mergePDFFiles(zjdFilePDFList, mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/" + DateTime.Now.ToString("yyyyMMdd") + "ZJD.pdf");
                    MergeExcle(zjdFileExcelList, mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/" + DateTime.Now.ToString("yyyyMMdd") + "ZJD.xls");
                }


                //没有费支单的对账单
                foreach (var orderNo in noFzdDzdList)
                {
                    string url = $"{dzdReportUrl}&NO={orderNo.Key}";
                    DownLoadFileByUrl(url+ "&rs:Format=PDF&rs:Command=Render", orderNo.Key, reportUrl);
                    DownLoadExcelByUrl(url + "&rs:Format=excel&rs:Command=Render", orderNo.Key, reportUrl,"");
                    File.Copy(reportUrl + orderNo.Key + "Report.pdf",mergrFileUrl + orderNo.Value + "/" + orderNo.Key + ".pdf",true);
                    File.Copy(reportUrl + orderNo.Key + "Report.xls", mergrFileUrl + orderNo.Value + "/" + orderNo.Key + ".xls", true);
                    File.Copy(reportUrl+ orderNo.Key + "Report.pdf", mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/"+ orderNo.Key + ".pdf",true);
                    File.Copy(reportUrl + orderNo.Key+ "Report.xls", mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/" + orderNo.Key + ".xls",true);
                    UpdateNoStatus(orderNo.Key, true);
                }


                if (dataTable.Rows.Count > 0 || zjdDT.Rows.Count > 0||noFzdDzdList.Count>0)
                {
                    //创建压缩文件档
                    CreateZip(mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/", mergrFileUrlDate + DateTime.Now.ToString("yyyyMMdd") + ".zip");
                    //发送邮件
                    SendPurchasingEmail("採購郵箱");
                    SendPurchasingEmail("業務郵箱");
                    //创建压缩文件档
                    CreateZip(mergrFzdUrlDate + DateTime.Now.ToString("yyyyMMdd") + "/", mergrFzdUrlDate + DateTime.Now.ToString("yyyyMMdd") + ".zip");
                    //发送邮件
                    SendReconciliaEmail(largeFzdList);

                }
            }
            catch (Exception ex)
            {
                _log.Error(ex.ToString());
            }
        }


        private DataTable GetOrderNo() =>
            dbhelper.ExecuteSqlTable("select 訂單編號,年月 from 郵箱費用明細表頭 where 付款方式=N'開票' and 單據狀態 in (N'已上傳費支單',N'已申請開票') and 是否有效='Y' and 是否已生成PDF='N'");
        private DataTable GetZJDOrderNo() =>
            dbhelper.ExecuteSqlTable("select 訂單編號,年月 from 郵箱費用明細表頭 where 付款方式=N'費用轉嫁' and 單據狀態=N'已轉嫁' and 是否有效='Y' and 是否已生成PDF='N'");
        private void UpdateNoStatus(string orderNo, bool insert)
        {
            List<string> sqlList = new List<string>();
            string sql = "update 郵箱費用明細表頭 set 是否已生成PDF='Y' where 訂單編號='" + orderNo + "'";
            sqlList.Add(sql);
            //      if (insert)
            //      {
            //          sql = @"insert into [收費對賬費支單表] ([來源訂單編號]
            //,[序號]
            //,[費支單名稱]
            //,[費支單]
            //,[案號]
            //,[費用代碼]
            //,[含稅金額]
            //,[未稅金額]
            //,[乙方稅率]
            //,[乙方幣別]
            //,[是否有效]
            //,[建立者]
            //,[建立時間]
            //,[修改者]
            //,[修改時間]
            //,[預留1]
            //,[預留2]
            //,[預留3]
            //,[預留4]
            //,[預留5]
            //,[預留6]
            //,[預留7]
            //,[預留8]
            //,[預留9]
            //,[預留10]) values(N'" + orderNo + "',(select max(序號) from 收費對賬費支單表 where 來源訂單編號=N'" + orderNo + "')+1,N'對賬單費支單合成檔',N'對賬單費支單合成檔.zip'," +
            //    @"'','',0,0,0,'','Y','admin',getdate(),'admin',getdate(),'','','','','',0,0,0,0,'1900-01-01')";
            //          sqlList.Add(sql);
            //}
            dbhelper.ExecSqlTransaction(sqlList);
        }


        private void SendPurchasingEmail(string user)
        {
            string role = user.Replace("郵箱", "");
            string consignee = dbhelper.ExecuteSql("select 郵箱 from 人員信息表 where 工號 = (select UserID from UinR where RoleID = '" + role + "')");
            if (consignee == null || "".Equals(consignee))
            {
                consignee = dbhelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型=N'" + user + "' and 是否有效='Y'");
                user = dbhelper.ExecuteSql("select 參數名 from 基本參數表 where 參數類型=N'" + user + "' and 是否有效='Y'");
            }
            else
            {
                user = dbhelper.ExecuteSql("select 姓名 from 人員信息表 where 工號 = (select UserID from UinR where RoleID = '" + role + "')");
            }
            //consignee += "," + dbhelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型=N'"+user+"' and 是否有效='Y'");
            DataTable dt = dbhelper.ExecuteSqlTable("select * from 送審跟催模板 where 流程ID='HB001' and 類型=N'合併PDF'");
            string tip = dt.Rows[0]["主旨"].ToString().Trim();
            string content = dt.Rows[0]["郵件頭"].ToString().Trim() + user + dt.Rows[0]["郵件正文"].ToString().Trim()
                + "<a href=\"http://" + HttpContext.Current.Request.Url.Authority + HttpContext.Current.Request.ApplicationPath + "/PDFDownload/DownZip/Purchasing/"
                + DateTime.Now.ToString("yyyyMMdd") + "\">" + DateTime.Now.ToString("yyyy-MM-dd") + "</a>" + dt.Rows[0]["郵件結尾"].ToString().Trim();
            string sql = @"INSERT INTO [dbo].[郵件發送表] (
	                            [ID],
	                            [發送郵件的IP],
	                            [端口號],
	                            [系統名稱],
	                            [數據庫名稱],
	                            [發件人],
	                            [收件人],
	                            [主題],
	                            [內容],
	                            [建立者],
	                            [建立時間],
	                            [發送狀態],
	                            [錯誤信息],
	                            [是否重發],
	                            [時間間隔],
	                            [發送時間],
	                            [發送次數],
	                            [參考單號],
	                            [預留1],
	                            [預留2],
	                            [預留3] 
                            )
                            VALUES
	                            (
		                            NEWID(),
		                            N'10.134.28.95',
		                            25,
		                            N'郵箱收費對賬系統',
		                            N'Ame_FSC1_EmailCharge',
		                            N'celersystemtest@mail.foxconn.com',
		                            N'" + consignee + "'," +
                                    "N'" + tip + "'," +
                                    "N'" + content + "'," +
                                    @"N'Auto',
                                    getdate(),
	                                N'N',
	                                N'',
	                                N'N',
	                                .00,
	                                getdate(),
	                                0,
	                                N'',
	                                0,
	                                N'',
                                    N''
                                 ); ";
            dbhelper.ExecuteSql(sql);
        }
        private void SendReconciliaEmail(List<string> largeList)
        {
            List<string> sqlList = new List<string>();
            DataTable consigneedt = dbhelper.ExecuteSqlTable(@"SELECT DISTINCT
	a.[姓名],
	a.[郵箱] 
FROM
	人員信息表 a
	INNER JOIN UinR b ON a.[工號] = b.UserID 
WHERE
	b.RoleID = N'對賬管理員' 
	AND a.[是否有效] = 'Y'");

            DataTable dt = dbhelper.ExecuteSqlTable("select * from 送審跟催模板 where 流程ID='HB002' and 類型=N'合併PDF'");
            string msg = "";
            string orderNos = "";
            foreach (var orderNo in largeList)
            {
                orderNos += "," + orderNo;
            }
            if (orderNos != "")
            {
                orderNos = orderNos.Substring(1);
                msg = $" 合併費支單時超過10頁，無法合併，請手動合併後發送至業務，文件保存在{orderNos}文件夾下";
            }
            foreach (DataRow dr in consigneedt.Rows)
            {
                string consignee = dr["郵箱"].ToString().Trim();
                string tip = dt.Rows[0]["主旨"].ToString().Trim();
                string content = dt.Rows[0]["郵件頭"].ToString().Trim() + dr["姓名"].ToString().Trim() + dt.Rows[0]["郵件正文"].ToString().Trim()
                    + "<a href=\"http://" + HttpContext.Current.Request.Url.Authority + HttpContext.Current.Request.ApplicationPath + "/PDFDownload/DownZip/Reconcilia/"
                    + DateTime.Now.ToString("yyyyMMdd") + "\">請點擊此處日期下載:" + DateTime.Now.ToString("yyyy-MM-dd") + "</a>" +"<br><br>"+msg+ dt.Rows[0]["郵件結尾"].ToString().Trim();
                string sql = @"INSERT INTO [dbo].[郵件發送表] (
	                            [ID],
	                            [發送郵件的IP],
	                            [端口號],
	                            [系統名稱],
	                            [數據庫名稱],
	                            [發件人],
	                            [收件人],
	                            [主題],
	                            [內容],
	                            [建立者],
	                            [建立時間],
	                            [發送狀態],
	                            [錯誤信息],
	                            [是否重發],
	                            [時間間隔],
	                            [發送時間],
	                            [發送次數],
	                            [參考單號],
	                            [預留1],
	                            [預留2],
	                            [預留3] 
                            )
                            VALUES
	                            (
		                            NEWID(),
		                            N'10.134.28.95',
		                            25,
		                            N'郵箱收費對賬系統',
		                            N'Ame_FSC1_EmailCharge',
		                            N'celersystemtest@mail.foxconn.com',
		                            N'" + consignee + "'," +
                                        "N'" + tip + "'," +
                                        "N'" + content + "'," +
                                        @"N'auto',
                                    getdate(),
	                                N'N',
	                                N'',
	                                N'N',
	                                .00,
	                                getdate(),
	                                0,
	                                N'',
	                                0,
	                                N'',
                                    N''
                                 ); ";
                sqlList.Add(sql);
            }
            if (sqlList.Count > 0)
            {
                dbhelper.ExecSqlTransaction(sqlList);
            }
        }
    }
}