﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class EmailFee
    {
        private string _no;
        private string _isPDF;
        private string _isDownload;
        private string _isVaild;
        private string _dateNo;
        /// <summary>
        /// 订单编号
        /// </summary>
        public string No
        {
            get
            {
                return _no;
            }

            set
            {
                _no = value;
            }
        }
        /// <summary>
        /// 是否已生成PDF
        /// </summary>
        public string IsPDF
        {
            get
            {
                return _isPDF;
            }

            set
            {
                _isPDF = value;
            }
        }
        /// <summary>
        /// 是否已下载
        /// </summary>
        public string IsDownload
        {
            get
            {
                return _isDownload;
            }

            set
            {
                _isDownload = value;
            }
        }
        /// <summary>
        /// 是否有效
        /// </summary>
        public string IsVaild
        {
            get
            {
                return _isVaild;
            }

            set
            {
                _isVaild = value;
            }
        }
        /// <summary>
        /// 年月
        /// </summary>
        public string DateNo
        {
            get
            {
                return _dateNo;
            }

            set
            {
                _dateNo = value;
            }
        }
    }
}
