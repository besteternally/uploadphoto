﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Util
{
    /// <summary>
    /// PDF超过10页时异常
    /// </summary>
    public class PdfLargeError:Exception
    {

        public PdfLargeError()
            : base("PDF超过10页")
        {

        }

        public PdfLargeError(string message)//指定错误消息
            : base(message)
        {
            
        }

        public PdfLargeError(string message, Exception inner)//指定错误消息和内部异常信息
            : base(message, inner)
        {

        }
    }
}
