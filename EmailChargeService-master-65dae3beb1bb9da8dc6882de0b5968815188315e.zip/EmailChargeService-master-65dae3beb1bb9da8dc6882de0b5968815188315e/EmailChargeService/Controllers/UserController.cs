﻿using Bll;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using Util;


namespace EmailChargeService.Controllers
{
    public class UserController : Controller
    {
        private log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private UserBll userBll = new UserBll();
        // GET: User
        public ActionResult FindPassword(string scope = "", string code = "")
        {
            if (code != "")
            {
                string appid = "NuMihrH9FfDqSbTmODu-Dw2";
                OAuthUser oauther = new OAuthUser();
                oauther = userBll.UserLogin(code, appid);
                if (userBll.ExistisUser(oauther.civetno))
                {
                    ViewData["UserId"] = oauther.civetno;
                    ViewData["UserName"] = oauther.nickname;
                }
            }
            return View();
        }

        public string ResetPassword(string id, string downstring)
        {
            try
            {
                string key = "ACasakjk4s43biynXrFYbdMdB83BEk7n";
                string newPassword = AesHelper.DecryptByAES(downstring, key);
                userBll.ResetPassword(id, newPassword);
                return "";
            }
            catch (Exception ex)
            {
                Log.Info(ex.ToString());
                return "系统错误";
            }
        }



    }
}