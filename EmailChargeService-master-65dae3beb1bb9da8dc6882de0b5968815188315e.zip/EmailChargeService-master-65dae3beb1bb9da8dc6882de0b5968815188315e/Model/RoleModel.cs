﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class RoleModel
    {
        private string _參數名;
        private string _說明;
        private string _預留2;
        public string 參數名 { get; set; }
        public string 說明 { get; set; }
        public string 預留2 { get; set; }
    }
}
