﻿using SqlSugar;

namespace Model
{
    /// <summary>
    /// 
    /// </summary>
    public class 香信事業群信息表
    {
        /// <summary>
        /// 
        /// </summary>
        public 香信事業群信息表()
        {
        }

        private System.String _事業群;
        /// <summary>
        /// 
        /// </summary>
        public System.String 事業群 { get { return this._事業群; } set { this._事業群 = value; } }
    }
}
