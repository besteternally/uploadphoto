﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Dal;
using System.Data;
using System.Net;
using static Util.Compress;
using static Util.DownloadFile;
using System.IO;
using System.Reflection;

namespace Bll
{
    public class DownloadBll
    {
        private DbHelper db = new DbHelper();
        public log4net.ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public LayuiResult<EmailFee> QueryDownloadTable()
        {
            LayuiResult<EmailFee> layuiResult = new LayuiResult<EmailFee>();
            List<EmailFee> emaliFeeList = new List<EmailFee>();
            try
            {
                int count = Convert.ToInt32(db.ExecuteSql("SELECT Count(DISTINCT 年月) FROM [dbo].[郵箱費用明細表頭] where [是否有效]='Y' and 是否已生成PDF='Y'"));
                string sql = "SELECT DISTINCT 年月 FROM [dbo].[郵箱費用明細表頭] where [是否有效]='Y' and 是否已生成PDF='Y'";
                DataTable dt = db.ExecuteSqlTable(sql);
                foreach (DataRow dr in dt.Rows)
                {
                    EmailFee emailFee = new EmailFee();
                    emailFee.DateNo = dr["年月"].ToString().Trim();
                    emaliFeeList.Add(emailFee);
                }
                layuiResult.code = 0;
                layuiResult.data = emaliFeeList;
                layuiResult.count = count;
            }
            catch (Exception ex)
            {
                layuiResult.code = 1;
                layuiResult.msg = ex.Message;
            }
            return layuiResult;
        }

        public string DownLoadPdf(string id, string downstring)
        {
            try
            {
                string sql = "";
                Dictionary<string, string> fileMap = new Dictionary<string, string>();               
                List<string> sqlList = new List<string>();
                List<string> noList = new List<string>();
                switch (downstring)
                {
                    //部分下载
                    case "1":
                        {
                            sql = @"SELECT
                                    a.訂單編號,
	                                b.案號
                                FROM
                                    [dbo].[郵箱費用明細表頭]
                                        a
                                    LEFT JOIN (SELECT * from [dbo].[收費對賬費支單表] where 是否有效='Y')
                                        b ON a.[訂單編號] = b.[來源訂單編號]
                                WHERE
                                    a.[是否有效] = 'Y' 
                                    AND a.[是否已生成PDF] = 'Y'
                                    AND a.[是否已下載] = 'N'
                                    AND a.[付款方式] = N'開票'
                                    AND a.[年月] = '" + id + "';";
                            DataTable dt = db.ExecuteSqlTable(sql);
                            if (dt.Rows.Count < 1)
                            {
                                return "该月份没有还未下载过的对账单费支单";
                            }
                            int i = 0;
                            foreach (DataRow dr in dt.Rows)
                            {
                                i++;
                                fileMap.Add(i.ToString(),
                                    string.IsNullOrWhiteSpace(dr["案號"].ToString().Trim())
                                        ? dr["訂單編號"].ToString().Trim()
                                        : dr["案號"].ToString().Trim());
                            }
                            DataTable dtHeader = dt.DefaultView.ToTable(true, new string[] { "訂單編號" });
                            foreach(DataRow dr in dtHeader.Rows)
                            {
                                noList.Add(dr["訂單編號"].ToString().Trim());
                            }
                        }
                        break;
                    //全部下载
                    case "2":
                        {
                            sql = @"SELECT
	                                a.訂單編號,
	                                b.案號 
                                FROM
	                                [dbo].[郵箱費用明細表頭] a
	                                LEFT JOIN (SELECT * from [dbo].[收費對賬費支單表] where 是否有效='Y')  b ON a.[訂單編號] = b.[來源訂單編號] 
                                WHERE
	                                a.[是否有效] = 'Y' 
	                                AND a.[是否已生成PDF] = 'Y' 
	                                AND a.[付款方式] = N'開票' 
                                    AND a.[年月] = '" + id + "';";
                            DataTable dt = db.ExecuteSqlTable(sql);
                            if (dt.Rows.Count < 1)
                            {
                                return "该月份没有对账单费支单";
                            }
                            int i = 0;
                            foreach (DataRow dr in dt.Rows)
                            {
                                i++;
                                fileMap.Add(i.ToString(),
                                    string.IsNullOrWhiteSpace(dr["案號"].ToString().Trim())
                                        ? dr["訂單編號"].ToString().Trim()
                                        : dr["案號"].ToString().Trim());
                            }
                            DataTable dtHeader = dt.DefaultView.ToTable(true, new string[] { "訂單編號" });
                            foreach (DataRow dr in dtHeader.Rows)
                            {
                                noList.Add(dr["訂單編號"].ToString().Trim());
                            }
                        }
                        break;
                    //下载转嫁单
                    case "3":
                        fileMap.Add(id, id + "ZJD");                      
                        break;
                }
                //从文件路径中获取文件名
                string url = System.Threading.Thread.GetDomain().BaseDirectory + "/DownLoad/PDF/" + id;
                CreateZip(url, url + ".zip", fileMap);
                foreach (string no in noList)
                {
                    sql = "update [dbo].[郵箱費用明細表頭] set 是否已下載='Y' where 訂單編號='" + no + "';";
                    sqlList.Add(sql);
                }
                db.ExecSqlTransaction(sqlList);
                return "";
            }
            catch (Exception ex)
            {
                log.Info(ex.Message);
                return "內部錯誤,下載失敗";
            }
        }
        
    }
}
