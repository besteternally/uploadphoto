﻿using Dal;
using Domino;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Bll
{
    public class MailDataBll
    {
        //notes計費配額方法       
        DbHelper dbHelper = new DbHelper();
        MsSqlDbContext<object> msSql = new MsSqlDbContext<object>();
        //MailDataDal mailDataDal = new MailDataDal();
        log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public string ImportData(string ym, string user)
        {
            string res = "";
            DateTime time1 = DateTime.Now;
            string sql = "";
            //old
            //supernote去重
            //string[] supernotesArr = { "郵箱地址", "項目", "賬號類型","工號","姓名","事業群","事業處","付費法人","費用代碼" ,"賬號服務器","賬號建立日期","最後一次修改日期","信箱配額","歸檔配額" };
            //Distinct(supernotesTable, supernotesArr);//4分鐘

            //讀取supernotes        
            DataTable supernotesTable = GetSuperNotes();
            //讀取notes 
            DataTable notesTable = GetNotes();
            //讀取vipmail
            DataTable vipmailTable = GetVIPMail();
            //讀取pushmail
            DataTable pushmailTable = GetPushMail();
            //讀取notes賬號服務器
            DataTable notesServer = GetNotesServer();
            //清空臨時表的數據
            dbHelper.Execute("delete from 使用者賬號信息臨時表");

            //DataTable數據寫入臨時表
            Insert(supernotesTable);
            Insert(notesTable);
            Insert(vipmailTable);
            Insert(pushmailTable);

            //清空Notes賬號服務器的數據
            dbHelper.Execute("delete from Notes賬號服務器");
            //DataTable數據寫入Notes賬號服務器
            InsertNotesServer(notesServer);

            List<string> cmdList1 = new List<string>();
            //修改notes郵箱地址
            sql = "update 使用者賬號信息臨時表 set 郵箱地址=replace(replace(replace(郵箱地址,'CN=',''),'OU=',''),'O=','') where 項目='notes' and 賬號類型='普通賬號'";
            cmdList1.Add(sql);
            sql = "update Notes賬號服務器 set 郵箱地址=replace(replace(replace(郵箱地址,'CN=',''),'OU=',''),'O=',''),賬號服務器=replace(replace(replace(賬號服務器,'CN=',''),'OU=',''),'O=','')";
            cmdList1.Add(sql);


            //notes賬號服務器更新到臨時表(普通賬號)        
            sql = @"update 使用者賬號信息臨時表 set 賬號服務器 =b.賬號服務器 from 使用者賬號信息臨時表 a,Notes賬號服務器 b
                    where a.郵箱地址 = b.郵箱地址 and 項目 = 'Notes' and 賬號類型 = '普通賬號' and b.賬號服務器 is not null";
            cmdList1.Add(sql);


            //vipmail其他欄位使用notes普通賬號的數據
            sql = "update 使用者賬號信息臨時表 set 工號=b.工號, 姓名=b.姓名, 事業群=b.事業群, 事業處=b.事業處, 付費法人=b.付費法人, 費用代碼=b.費用代碼, 賬號廠區=b.賬號廠區, 賬號建立日期=b.賬號建立日期, 最後一次修改日期=b.最後一次修改日期, 信箱配額=b.信箱配額, 歸檔配額=b.歸檔配額, 計費配額=b.計費配額 from 使用者賬號信息臨時表 a,(select * from 使用者賬號信息臨時表 where 項目='notes' and 賬號類型='普通賬號')b where a.郵箱地址=b.郵箱地址 and a.項目='notes' and a.賬號類型='VIPMail賬號'";
            cmdList1.Add(sql);

            //pushmail其他欄位使用notes普通賬號的數據          
            sql = "update 使用者賬號信息臨時表 set 工號=b.工號, 事業處=b.事業處, 付費法人=b.付費法人, 費用代碼=b.費用代碼, 賬號廠區=b.賬號廠區, 賬號建立日期=b.賬號建立日期, 最後一次修改日期=b.最後一次修改日期, 信箱配額=b.信箱配額, 歸檔配額=b.歸檔配額, 計費配額=b.計費配額 from 使用者賬號信息臨時表 a,(select * from 使用者賬號信息臨時表 where 項目='notes' and 賬號類型='普通賬號')b where a.郵箱地址=b.郵箱地址 and a.項目='notes' and a.賬號類型='PushMail賬號'";//, 姓名=b.姓名, 事業群=b.事業群
            cmdList1.Add(sql);


            //郵箱地址重複只能一筆，留最後一次修改的數據
            //刪除重複數據
            sql = @"update 使用者賬號信息臨時表 set 序號 =b.序號 from 使用者賬號信息臨時表 a,(select row_number() over(partition by 郵箱地址 order by 最後一次修改日期 desc)序號,ID,郵箱地址,最後一次修改日期 from [使用者賬號信息臨時表])b where a.ID=b.ID";
            cmdList1.Add(sql);

            sql = @"delete from 使用者賬號信息臨時表 where 序號!=1";
            cmdList1.Add(sql);


            //supernotes
            //信箱配額、歸檔配額、計費配額計算后更新到臨時表
            //計費配額=歸檔配額
            sql = @"update 使用者賬號信息臨時表 set 信箱配額=(case len(信箱配額) when 8 then left(信箱配額,2)+'M' when 9 then left(信箱配額,3)+'M' 
                 when 10 then left(信箱配額,4)+'M' when 11 then left(信箱配額,5)+'M' else 信箱配額 end)
                ,歸檔配額 =(case len(歸檔配額) when 10 then left(歸檔配額,1)+'G' when 11 then left(歸檔配額,2)+'G' else 歸檔配額 end)
                ,計費配額=(case len(歸檔配額) when 10 then left(歸檔配額,1)+'G' when 11 then left(歸檔配額,2)+'G' else 歸檔配額 end)
                 where 項目='SuperNotes'";
            cmdList1.Add(sql);

            //notes
            //信箱配額、歸檔配額、計費配額計算后更新到臨時表
            //計費配額=信箱配額
            //转换规则从Notes計費配額获取,特殊情况(0或者空)位无限量
            sql = @"UPDATE i 
SET i.[計費配額] = j.[計費配額] 
FROM
	[dbo].[使用者賬號信息臨時表] i
	INNER JOIN (
	SELECT DISTINCT
		* 
	FROM
		(
		SELECT
			a.[ID],
			(
			CASE
					
					WHEN [信箱配額] = '' THEN
					'無限量' 
					WHEN ( CAST ( [信箱配額] AS INT ) = 0 ) THEN
					'無限量' 
					WHEN ( CAST ( [信箱配額] AS INT ) > b.[上限] AND CAST ( [信箱配額] AS INT ) <= b.[下限] ) THEN
					b.[計費配額] 
				END 
				) AS [計費配額] 
			FROM
				[dbo].[使用者賬號信息臨時表] a,
				[Notes計費配額] b 
			WHERE
				項目= 'Notes' 
			) AS c 
		WHERE
			[計費配額] IS NOT NULL 
		) j ON i.ID = j.ID 
WHERE
	i.項目 = 'Notes'";
            cmdList1.Add(sql);
            //對賬窗口賬號、對賬窗口姓名、 對賬窗口聯繫方式、對賬窗口郵箱地址、賬單法人代碼、賬單法人名稱根據事業群與法人從生成賬單規則表帶出
            sql = @"update 使用者賬號信息臨時表 set 對賬窗口賬號=b.對賬窗口賬號,對賬窗口姓名=b.對賬窗口姓名,對賬窗口聯繫方式=c.手機號碼,對賬窗口郵箱地址=c.郵箱,賬單法人代碼=b.賬單法人代碼,賬單法人名稱=b.賬單法人名稱 from 使用者賬號信息臨時表 a,生成賬單規則表 b,人員信息表 c where a.事業群=b.事業群 and a.付費法人=b.法人 and b.是否有效='Y' and c.工號=b.對賬窗口賬號 and c.是否有效='Y'";
            cmdList1.Add(sql);

            msSql.ExecuteSqlTran(cmdList1);
            //mailDataDal.ExecuteSqlTran(cmdList1);
            //dbHelper.ExecSqlList(cmdList1);


            List<string> cmdList2 = new List<string>();



            //賬號廠區更新到臨時表
            sql = "update [使用者賬號信息臨時表] set 賬號廠區=b.賬號廠區 from 使用者賬號信息臨時表 a,(select 項目,事業群,賬號服務器,賬號廠區 from [賬號廠區對應表] where 是否有效='Y' group by 項目,事業群,賬號服務器,賬號廠區)b where a.項目=b.項目 and a.事業群=b.事業群 and a.賬號服務器=b.賬號服務器";
            cmdList2.Add(sql);

            if (ym == DateTime.Now.ToString("yyyyMM"))//使用者賬號信息表
            {
                #region 轉移歷史數據
                //第一次導入
                //上月數據移到上月
                //上月表中數據移到歷史
                //上月未計入賬單數據導入未出賬表
                string lastYM = DateTime.Now.AddMonths(-1).ToString("yyyyMM");//上月
                string lastLastYM = DateTime.Now.AddMonths(-2).ToString("yyyyMM");//上上月
                if (IsFirstImport(ym))
                {
                    //上月表中數據移到歷史
                    sql = "insert into 使用者賬號歷史表 select * from 使用者賬號上月表 where 年月='" + lastLastYM + "'";
                    cmdList2.Add(sql);
                    sql = "delete from 使用者賬號上月表 where 年月='" + lastLastYM + "'";
                    cmdList2.Add(sql);

                    //上月未計入賬單數據導入未出賬表
                    //update date:2019/7/5
                    //sql = "insert into 使用者賬號未出賬表 select * from 使用者賬號信息表 a where 年月='" + lastYM + "' and 賬號狀態 in ('新建','已確認','已移除') and 是否生成賬單='N'";// and not exists(select * from 使用者賬號未出賬表 b where b.年月='" + lastYM + "' and a.郵箱地址=b.郵箱地址)
                    sql = "insert into 使用者賬號未出賬表 select * from 使用者賬號信息表 a where 年月='" + lastYM + "' and 賬號狀態 not in ('免費','已刪除') and 是否生成賬單='N'";// and not exists(select * from 使用者賬號未出賬表 b where b.年月='" + lastYM + "' and a.郵箱地址=b.郵箱地址)
                    cmdList2.Add(sql);

                    //上月數據移到上月
                    sql = "insert into 使用者賬號上月表 select * from 使用者賬號信息表 where 年月='" + lastYM + "'";
                    cmdList2.Add(sql);
                    sql = "delete from 使用者賬號信息表 where 年月='" + lastYM + "'";
                    cmdList2.Add(sql);

                    if (!IsExistCloseAccout(ym))
                    {
                        sql = "insert into 關賬信息表(年月, 關賬狀態, 關賬人工號, 關賬人姓名, 關賬日期, 開賬人工號, 開賬人姓名, 開賬日期, 是否有效, 建立者, 建立時間, 修改者, 修改時間, 預留1, 預留2, 預留3, 預留4, 預留5, 預留6, 預留7, 預留8, 預留9, 預留10) values('" + ym + "','已開賬','auto','auto',getdate(),'','','1900/1/1','Y','auto',getdate(),'auto',getdate(),'','','','','',0,0,0,0,'1900/1/1')";
                        cmdList2.Add(sql);
                    }
                }
                #endregion

                //把上月法人信息延續到本月中來
                sql = @"UPDATE a 
SET a.[付費法人] = b.付費法人 
FROM
	[dbo].[使用者賬號信息臨時表] a
	INNER JOIN [使用者賬號上月表] b ON a.[郵箱地址] = b.[郵箱地址] 
    WHERE b.年月 = '" + lastYM + "'";
                cmdList2.Add(sql);

                //繼承上月未確認狀態和賬號狀態
                sql = @"UPDATE a 
SET a.[賬號狀態] = b.[賬號狀態],
a.[未確認狀態] = b.[未確認狀態] 
FROM
	[dbo].[使用者賬號信息臨時表] a
	INNER JOIN [使用者賬號上月表] b ON a.[郵箱地址] = b.[郵箱地址] 
WHERE
	b.年月 = '" + lastYM + @"' 
    AND (
	( b.[賬號狀態] = N'已移除' AND b.未確認狀態 = N'異常' ) 
	OR b.[賬號狀態] IN ( N'停用', N'待刪除', N'停用待接收', N'停用已接收' ))";
                cmdList2.Add(sql);

                //繼承上月是否臺干和事業群
                sql = @"UPDATE a 
SET a.[是否台幹]=b.[是否台幹],
a.[事業群]=b.[事業群]
FROM
	[dbo].[使用者賬號信息臨時表] a
	INNER JOIN [使用者賬號上月表] b ON a.[郵箱地址] = b.[郵箱地址] 
WHERE
	b.年月 = '" + lastYM + "'";
                cmdList2.Add(sql);

                //存在的郵箱--(賬號狀態非新建的提示)
                sql = "select a.編號,a.郵箱地址,a.項目,a.賬號類型,a.賬號狀態 from 使用者賬號信息表 a,使用者賬號信息臨時表 b where a.郵箱地址=b.郵箱地址 and a.項目=b.項目 and a.賬號類型=b.賬號類型 and a.年月='" + ym + "' and a.是否有效='Y' and a.賬號狀態!='新建'";


                //更新臨時表(只是當月)
                //是否提前付費, 已付費至年, 已付費至月, 賬號說明, 是否免費賬號欄位上月有數據並且未過期採用上月的數據              
                sql = "update 使用者賬號信息臨時表 set 是否提前付費=b.是否提前付費, 已付費至年=b.已付費至年, 已付費至月=b.已付費至月, 賬號說明=b.賬號說明, 是否免費賬號=b.是否免費賬號 from 使用者賬號信息臨時表 a ,使用者賬號上月表 b where a.郵箱地址=b.郵箱地址 and b.是否有效='Y' and 年月='" + DateTime.Now.AddMonths(-1).ToString("yyyyMM") + "' and b.是否提前付費='Y' and dateadd(ms,-1,dateadd(month,1,cast(b.已付費至年+'/'+b.已付費至月+'/01' as datetime)))>=GETDATE() and a.項目=b.項目 and a.賬號類型=b.賬號類型";
                cmdList2.Add(sql);


                //該月存在的郵箱-upd(只有賬號狀態新建的可以修改)
                sql = "update 使用者賬號信息表 set 工號 =b.工號,姓名 =b.姓名 ,事業群 =b.事業群 ,事業處 =b.事業處 ,付費法人 =b.付費法人 ,費用代碼 = b.費用代碼,賬號服務器 =b.賬號服務器,賬號廠區 =b.賬號廠區,賬號建立日期 = b.賬號建立日期,最後一次修改日期 = b.最後一次修改日期,信箱配額 = b.信箱配額,歸檔配額 =b.歸檔配額,計費配額 = b.歸檔配額,對賬窗口賬號=b.對賬窗口賬號,對賬窗口姓名=b.對賬窗口姓名,對賬窗口聯繫方式=b.對賬窗口聯繫方式,對賬窗口郵箱地址=b.對賬窗口郵箱地址,賬單法人代碼=b.賬單法人代碼,賬單法人名稱=b.賬單法人名稱,修改者='" + user + "',修改時間=getdate()  from 使用者賬號信息表 a,使用者賬號信息臨時表 b where a.郵箱地址=b.郵箱地址 and a.年月='" + ym + "' and a.是否有效='Y' and a.賬號狀態='新建' and a.項目=b.項目 and a.賬號類型=b.賬號類型";
                cmdList2.Add(sql);

                //該月不存在的郵箱-ins
                sql = "insert into 使用者賬號信息表 select '" + DateTime.Now.ToString("yyyyMMdd") + "'+right('000000000000'+cast(dbo.getmaxSeq('使用者賬號信息表')+(row_number() over(order by 事業群,事業處)) as nvarchar(32)),12) 編號,'" + ym + "' as 年月, 郵箱地址, 項目, 賬號類型, 工號, 姓名, 事業群, 事業處, 付費法人, 費用代碼, 賬號服務器, 賬號廠區, 賬號建立日期, 最後一次修改日期,'1900/1/1' 最後一次登錄時間, 信箱配額, 歸檔配額,歸檔配額 as 計費配額,0 信箱費用,0 歸檔費用,0 費用合計, 是否提前付費, 已付費至年, 已付費至月, 賬號說明,'N' 是否移除事業群,'1900/1/1' 移除事業群日期,'N' 是否刪除,'N' 是否結算,'N' 是否生成賬單,'' 賬單編號,'N' 當月是否收款, 是否免費賬號, 未確認狀態, 賬號狀態,'' 退回標記,對賬窗口賬號,對賬窗口姓名,對賬窗口聯繫方式,對賬窗口郵箱地址,賬單法人代碼,賬單法人名稱,'1900/1/1' 停用日期,'1900/1/1' 解鎖日期,'1900/1/1' 第一次郵件提醒時間,'1900/1/1' 郵件提醒時間,0 郵件提醒次數, 是否台幹,'Y' 是否有效,'" + user + "' 建立者,getdate() 建立時間,'" + user + "' 修改者,getdate() 修改時間,'' 預留1,'' 預留2,'' 預留3,'' 預留4,'' 預留5,0 預留6,0 預留7,0 預留8,0 預留9,'1900/1/1' 預留10 from 使用者賬號信息臨時表 a where not exists(select * from 使用者賬號信息表 b where a.郵箱地址=b.郵箱地址 and b.年月='" + ym + "' and b.是否有效='Y' and a.項目=b.項目 and a.賬號類型=b.賬號類型)";
                cmdList2.Add(sql);
            }


            else if (ym == DateTime.Now.AddMonths(-1).ToString("yyyyMM"))//使用者賬號上月表、使用者未出賬的表
            {
                //存在的郵箱--(賬號狀態非新建的提示)
                sql = "select a.編號,a.郵箱地址,a.項目,a.賬號類型,a.賬號狀態 from 使用者賬號上月表 a,使用者賬號信息臨時表 b where a.郵箱地址=b.郵箱地址 and a.項目=b.項目 and a.賬號類型=b.賬號類型 and a.年月='" + ym + "' and a.是否有效='Y' and a.賬號狀態!='新建'";

                //1.使用者賬號上月表
                //該月存在的郵箱-upd
                //只有賬號狀態新建的可以修改
                sql = "update 使用者賬號上月表 set 工號 =b.工號,姓名 =b.姓名 ,事業群 =b.事業群 ,事業處 =b.事業處 ,付費法人 =b.付費法人 ,費用代碼 = b.費用代碼,賬號服務器 =b.賬號服務器,賬號廠區 =b.賬號廠區,賬號建立日期 = b.賬號建立日期,最後一次修改日期 = b.最後一次修改日期,信箱配額 = b.信箱配額,歸檔配額 =b.歸檔配額,計費配額 = b.歸檔配額,對賬窗口賬號=b.對賬窗口賬號,對賬窗口姓名=b.對賬窗口姓名,對賬窗口聯繫方式=b.對賬窗口聯繫方式,對賬窗口郵箱地址=b.對賬窗口郵箱地址,賬單法人代碼=b.賬單法人代碼,賬單法人名稱=b.賬單法人名稱,修改者='" + user + "',修改時間=getdate()  from 使用者賬號上月表 a,使用者賬號信息臨時表 b where a.郵箱地址=b.郵箱地址 and a.年月='" + ym + "' and a.是否有效='Y' and a.賬號狀態='新建' and a.項目=b.項目 and a.賬號類型=b.賬號類型";
                cmdList2.Add(sql);

                //該月不存在的郵箱-ins
                sql = "insert into 使用者賬號上月表 select '" + DateTime.Now.ToString("yyyyMMdd") + "'+right('000000000000'+cast(dbo.getmaxSeq('使用者賬號上月表')+(row_number() over(order by 事業群,事業處)) as nvarchar(32)),12) 編號,'" + ym + "' as 年月, 郵箱地址, 項目, 賬號類型, 工號, 姓名, 事業群, 事業處, 付費法人, 費用代碼, 賬號服務器, 賬號廠區, 賬號建立日期, 最後一次修改日期,'1900/1/1' 最後一次登錄時間, 信箱配額, 歸檔配額,歸檔配額 as 計費配額,0 信箱費用,0 歸檔費用,0 費用合計, 是否提前付費, 已付費至年, 已付費至月, 賬號說明,'N' 是否移除事業群,'1900/1/1' 移除事業群日期,'N' 是否刪除,'N' 是否結算,'N' 是否生成賬單,'' 賬單編號,'N' 當月是否收款, 是否免費賬號,'' 未確認狀態,'新建' as 賬號狀態,'' 退回標記,對賬窗口賬號,對賬窗口姓名,對賬窗口聯繫方式,對賬窗口郵箱地址,賬單法人代碼,賬單法人名稱,'1900/1/1' 停用日期,'1900/1/1' 解鎖日期,'1900/1/1' 第一次郵件提醒時間,'1900/1/1' 郵件提醒時間,0 郵件提醒次數,'N' 是否台幹,'Y' 是否有效,'" + user + "' 建立者,getdate() 建立時間,'" + user + "' 修改者,getdate() 修改時間,'' 預留1,'' 預留2,'' 預留3,'' 預留4,'' 預留5,0 預留6,0 預留7,0 預留8,0 預留9,'1900/1/1' 預留10 from 使用者賬號信息臨時表 a where not exists(select * from 使用者賬號上月表 b where a.郵箱地址=b.郵箱地址 and b.年月='" + ym + "' and b.是否有效='Y' and a.項目=b.項目 and a.賬號類型=b.賬號類型)";
                cmdList2.Add(sql);

                //2.使用者賬號未出賬表
                //該月存在的郵箱-upd(只有賬號狀態新建的可以修改)
                sql = "update 使用者賬號未出賬表 set 工號 =b.工號,姓名 =b.姓名 ,事業群 =b.事業群 ,事業處 =b.事業處 ,付費法人 =b.付費法人 ,費用代碼 = b.費用代碼,賬號服務器 =b.賬號服務器,賬號廠區 =b.賬號廠區,賬號建立日期 = b.賬號建立日期,最後一次修改日期 = b.最後一次修改日期,信箱配額 = b.信箱配額,歸檔配額 =b.歸檔配額,計費配額 = b.歸檔配額,對賬窗口賬號=b.對賬窗口賬號,對賬窗口姓名=b.對賬窗口姓名,對賬窗口聯繫方式=b.對賬窗口聯繫方式,對賬窗口郵箱地址=b.對賬窗口郵箱地址,賬單法人代碼=b.賬單法人代碼,賬單法人名稱=b.賬單法人名稱,修改者='" + user + "',修改時間=getdate()  from 使用者賬號未出賬表 a,使用者賬號信息臨時表 b where a.郵箱地址=b.郵箱地址 and a.年月='" + ym + "' and a.是否有效='Y' and a.賬號狀態='新建' and a.項目=b.項目 and a.賬號類型=b.賬號類型";
                cmdList2.Add(sql);

                //該月不存在的郵箱-ins
                sql = "insert into 使用者賬號未出賬表 select '" + DateTime.Now.ToString("yyyyMMdd") + "'+right('000000000000'+cast(dbo.getmaxSeq('使用者賬號未出賬表')+(row_number() over(order by 事業群,事業處)) as nvarchar(32)),12) 編號,'" + ym + "' as 年月, 郵箱地址, 項目, 賬號類型, 工號, 姓名, 事業群, 事業處, 付費法人, 費用代碼, 賬號服務器, 賬號廠區, 賬號建立日期, 最後一次修改日期,'1900/1/1' 最後一次登錄時間, 信箱配額, 歸檔配額,歸檔配額 as 計費配額,0 信箱費用,0 歸檔費用,0 費用合計, 是否提前付費, 已付費至年, 已付費至月, 賬號說明,'N' 是否移除事業群,'1900/1/1' 移除事業群日期,'N' 是否刪除,'N' 是否結算,'N' 是否生成賬單,'' 賬單編號,'N' 當月是否收款, 是否免費賬號,'' 未確認狀態,'新建' as 賬號狀態,'' 退回標記,對賬窗口賬號,對賬窗口姓名,對賬窗口聯繫方式,對賬窗口郵箱地址,賬單法人代碼,賬單法人名稱,'1900/1/1' 停用日期,'1900/1/1' 解鎖日期,'1900/1/1' 第一次郵件提醒時間,'1900/1/1' 郵件提醒時間,0 郵件提醒次數,'N' 是否台幹,'Y' 是否有效,'" + user + "' 建立者,getdate() 建立時間,'" + user + "' 修改者,getdate() 修改時間,'' 預留1,'' 預留2,'' 預留3,'' 預留4,'' 預留5,0 預留6,0 預留7,0 預留8,0 預留9,'1900/1/1' 預留10 from 使用者賬號信息臨時表 a where not exists(select * from 使用者賬號未出賬表 b where a.郵箱地址=b.郵箱地址 and b.年月='" + ym + "' and b.是否有效='Y' and a.項目=b.項目 and a.賬號類型=b.賬號類型)";
                cmdList2.Add(sql);
            }
            else//使用者賬號歷史表、使用者未出賬的表
            {
                //存在的郵箱--(賬號狀態非新建的提示)
                sql = "select a.編號,a.郵箱地址,a.項目,a.賬號類型,a.賬號狀態 from 使用者賬號歷史表 a,使用者賬號信息臨時表 b where a.郵箱地址=b.郵箱地址 and a.項目=b.項目 and a.賬號類型=b.賬號類型 and a.年月='" + ym + "' and a.是否有效='Y' and a.賬號狀態!='新建'";

                //1.使用者賬號歷史表
                //該月存在的郵箱-upd(只有賬號狀態新建的可以修改)
                sql = "update 使用者賬號歷史表 set 工號 =b.工號,姓名 =b.姓名 ,事業群 =b.事業群 ,事業處 =b.事業處 ,付費法人 =b.付費法人 ,費用代碼 = b.費用代碼,賬號服務器 =b.賬號服務器,賬號廠區 =b.賬號廠區,賬號建立日期 = b.賬號建立日期,最後一次修改日期 = b.最後一次修改日期,信箱配額 = b.信箱配額,歸檔配額 =b.歸檔配額,計費配額 = b.歸檔配額,對賬窗口賬號=b.對賬窗口賬號,對賬窗口姓名=b.對賬窗口姓名,對賬窗口聯繫方式=b.對賬窗口聯繫方式,對賬窗口郵箱地址=b.對賬窗口郵箱地址,賬單法人代碼=b.賬單法人代碼,賬單法人名稱=b.賬單法人名稱,修改者='" + user + "',修改時間=getdate()  from 使用者賬號歷史表 a,使用者賬號信息臨時表 b where a.郵箱地址=b.郵箱地址 and a.年月='" + ym + "' and a.是否有效='Y' and a.賬號狀態='新建' and a.項目=b.項目 and a.賬號類型=b.賬號類型";
                cmdList2.Add(sql);

                //該月不存在的郵箱-ins
                sql = "insert into 使用者賬號歷史表 select '" + DateTime.Now.ToString("yyyyMMdd") + "'+right('000000000000'+cast(dbo.getmaxSeq('使用者賬號歷史表')+(row_number() over(order by 事業群,事業處)) as nvarchar(32)),12) 編號,'" + ym + "' as 年月, 郵箱地址, 項目, 賬號類型, 工號, 姓名, 事業群, 事業處, 付費法人, 費用代碼, 賬號服務器, 賬號廠區, 賬號建立日期, 最後一次修改日期,'1900/1/1' 最後一次登錄時間, 信箱配額, 歸檔配額,歸檔配額 as 計費配額,0 信箱費用,0 歸檔費用,0 費用合計, 是否提前付費, 已付費至年, 已付費至月, 賬號說明,'N' 是否移除事業群,'1900/1/1' 移除事業群日期,'N' 是否刪除,'N' 是否結算,'N' 是否生成賬單,'' 賬單編號,'N' 當月是否收款, 是否免費賬號,'' 未確認狀態,'新建' as 賬號狀態,'' 退回標記,對賬窗口賬號,對賬窗口姓名,對賬窗口聯繫方式,對賬窗口郵箱地址,賬單法人代碼,賬單法人名稱,'1900/1/1' 停用日期,'1900/1/1' 解鎖日期,'1900/1/1' 第一次郵件提醒時間,'1900/1/1' 郵件提醒時間,0 郵件提醒次數,'N' 是否台幹,'Y' 是否有效,'" + user + "' 建立者,getdate() 建立時間,'" + user + "' 修改者,getdate() 修改時間,'' 預留1,'' 預留2,'' 預留3,'' 預留4,'' 預留5,0 預留6,0 預留7,0 預留8,0 預留9,'1900/1/1' 預留10 from 使用者賬號信息臨時表 a where not exists(select * from 使用者賬號歷史表 b where a.郵箱地址=b.郵箱地址 and b.年月='" + ym + "' and b.是否有效='Y' and a.項目=b.項目 and a.賬號類型=b.賬號類型)";
                cmdList2.Add(sql);

                //2.使用者賬號未出賬表
                //該月存在的郵箱-upd(只有賬號狀態新建的可以修改)
                sql = "update 使用者賬號未出賬表 set 工號 =b.工號,姓名 =b.姓名 ,事業群 =b.事業群 ,事業處 =b.事業處 ,付費法人 =b.付費法人 ,費用代碼 = b.費用代碼,賬號服務器 =b.賬號服務器,賬號廠區 =b.賬號廠區,賬號建立日期 = b.賬號建立日期,最後一次修改日期 = b.最後一次修改日期,信箱配額 = b.信箱配額,歸檔配額 =b.歸檔配額,計費配額 = b.歸檔配額,對賬窗口賬號=b.對賬窗口賬號,對賬窗口姓名=b.對賬窗口姓名,對賬窗口聯繫方式=b.對賬窗口聯繫方式,對賬窗口郵箱地址=b.對賬窗口郵箱地址,賬單法人代碼=b.賬單法人代碼,賬單法人名稱=b.賬單法人名稱,修改者='" + user + "',修改時間=getdate()  from 使用者賬號未出賬表 a,使用者賬號信息臨時表 b where a.郵箱地址=b.郵箱地址 and a.年月='" + ym + "' and a.是否有效='Y' and a.賬號狀態='新建' and a.項目=b.項目 and a.賬號類型=b.賬號類型";
                cmdList2.Add(sql);

                //該月不存在的郵箱-ins
                sql = "insert into 使用者賬號未出賬表 select '" + DateTime.Now.ToString("yyyyMMdd") + "'+right('000000000000'+cast(dbo.getmaxSeq('使用者賬號未出賬表')+(row_number() over(order by 事業群,事業處)) as nvarchar(32)),12) 編號,'" + ym + "' as 年月, 郵箱地址, 項目, 賬號類型, 工號, 姓名, 事業群, 事業處, 付費法人, 費用代碼, 賬號服務器, 賬號廠區, 賬號建立日期, 最後一次修改日期,'1900/1/1' 最後一次登錄時間, 信箱配額, 歸檔配額,歸檔配額 as 計費配額,0 信箱費用,0 歸檔費用,0 費用合計, 是否提前付費, 已付費至年, 已付費至月, 賬號說明,'N' 是否移除事業群,'1900/1/1' 移除事業群日期,'N' 是否刪除,'N' 是否結算,'N' 是否生成賬單,'' 賬單編號,'N' 當月是否收款, 是否免費賬號,'' 未確認狀態,'新建' as 賬號狀態,'' 退回標記,對賬窗口賬號,對賬窗口姓名,對賬窗口聯繫方式,對賬窗口郵箱地址,賬單法人代碼,賬單法人名稱,'1900/1/1' 停用日期,'1900/1/1' 解鎖日期,'1900/1/1' 第一次郵件提醒時間,'1900/1/1' 郵件提醒時間,0 郵件提醒次數,'N' 是否台幹,'Y' 是否有效,'" + user + "' 建立者,getdate() 建立時間,'" + user + "' 修改者,getdate() 修改時間,'' 預留1,'' 預留2,'' 預留3,'' 預留4,'' 預留5,0 預留6,0 預留7,0 預留8,0 預留9,'1900/1/1' 預留10 from 使用者賬號信息臨時表 a where not exists(select * from 使用者賬號未出賬表 b where a.郵箱地址=b.郵箱地址 and b.年月='" + ym + "' and b.是否有效='Y' and a.項目=b.項目 and a.賬號類型=b.賬號類型)";
                cmdList2.Add(sql);
            }
            #region 生成賬單規則
            //沒有的數據寫入賬單規則表
            sql = @"insert into [生成賬單規則表] select 'GZ'+right('00000000'+cast((row_number() over(order by 事業群))+" + GetMaxRuleSeq() + " as nvarchar(32)),8) 規則編號, 事業群,'' 事業處,'' 廠區, 付費法人 as 法人,'' 費用代碼,'' 賬單法人代碼,'' 賬單法人名稱,'D' 有效欄位,'' 對賬窗口賬號,'' 對賬窗口姓名,'Y' 是否有效,'" + user + "' 建立者,getdate() 建立時間,'" + user + @"' 修改者,getdate() 修改時間,'' 預留1,'' 預留2,'' 預留3,'' 預留4,'' 預留5,0 預留6,0 預留7,0 預留8,0 預留9,'1900/1/1' 預留10 from(select 事業群,付費法人 from [使用者賬號信息臨時表] group by 事業群,付費法人)a where not exists(select * from [生成賬單規則表] b where a.事業群=b.事業群 and a.付費法人=b.法人 and b.是否有效='Y')";
            cmdList2.Add(sql);

            //更新單據取號管理
            sql = "update 單據取號管理 set 目前號碼=(select right(max(規則編號),8) from 生成賬單規則表),修改人員='" + user + "',修改時間=getdate() where 單據類別='規則編號' and 單據名稱='規則編號' and 是否有效='Y'";
            cmdList2.Add(sql);
            #endregion

            if (msSql.ExecuteSqlTran(cmdList2))
            {
                res = "導入完成";
            }
            else
            {
                res = "導入失敗";
            }

            DateTime time2 = DateTime.Now;
            string executeTime = (time2 - time1).ToString();
            dbHelper.Execute("update 基本參數表 set 預留1='" + executeTime + "' where 參數類型='郵件使用者信息對接' and 參數名='執行時間'");
            SendMail(res);
            return res;
        }

        /// <summary>
        /// 导入执行结束后发送邮件通知
        /// </summary>
        /// <param name="err"></param>
        private void SendMail(string msg)
        {
            string sql = "";
            List<string> sqlList = new List<string>();
            if ("導入完成".Equals(msg))
            {
                DataTable consigneedt = dbHelper.ExecuteSqlTable(@"SELECT DISTINCT
	a.[工號],
	a.[郵箱],
	a.[姓名] 
FROM
	人員信息表 a
	INNER JOIN UinR b ON a.[工號] = b.UserID 
WHERE
	b.RoleID = N'對賬管理員' 
	AND a.[是否有效] = 'Y'");
                string projectID = dbHelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型='ProjectID' and 參數名='ProjectID' and 是否有效 = 'Y'");
                string pagename = "使用者信息維護";
                pagename = Convert.ToBase64String(Encoding.Unicode.GetBytes(pagename));
                DataTable dt = dbHelper.ExecuteSqlTable("select * from 送審跟催模板 where 流程ID='ZHDR001' and 類型=N'導入完成'");
                foreach (DataRow dr in consigneedt.Rows)
                {
                    msg = "'<a href=''http://10.134.96.125:8003/Pages/EmailJump/JumpLogin.aspx?userID=" + dr["工號"].ToString().Trim() + "&ProjectID=" + projectID + "&Pagename=" + pagename + "''>數據對接已經完成,請點擊這裡登錄查看處理</a>  <br><br>'";
                    string consignee = dr["郵箱"].ToString().Trim();
                    string tip = dt.Rows[0]["主旨"].ToString().Trim();
                    string content = dt.Rows[0]["郵件正文"].ToString().Trim();
                    content = dt.Rows[0]["郵件頭"].ToString().Trim() + dr["姓名"].ToString().Trim() + content + msg + dt.Rows[0]["郵件結尾"].ToString().Trim();
                    sql = SendMail(consignee, tip, content);
                    sqlList.Add(sql);
                }
                dbHelper.ExecSqlTransaction(sqlList);
            }
            else
            {
                string consignee = dbHelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型=N'異常狀況聯繫人' and 是否有效 = 'Y'");
                DataTable dt3 = dbHelper.ExecuteSqlTable("select * from 送審跟催模板 where 流程ID='ZDFS001' and 類型=N'自動發送賬號失败'");
                string tip = dt3.Rows[0]["主旨"].ToString().Trim();
                string content = dt3.Rows[0]["郵件頭"].ToString().Trim() + "異常狀況聯繫人" + dt3.Rows[0]["郵件正文"].ToString().Trim()
                    + "出現錯誤日期:" + DateTime.Now.ToString("yyyy-MM-dd") + dt3.Rows[0]["郵件結尾"].ToString().Trim();
                sql = SendMail(consignee, tip, content);
                dbHelper.ExecuteSql(sql);
            }
        }

        public string GetPerformTime()
        {
            string sql = "select 說明 from 基本參數表 where 參數類型='郵件使用者信息對接' and 參數名='執行時間'";
            DataTable dt = dbHelper.ExecuteSqlTable(sql);
            return dt.Rows[0]["說明"].ToString();
        }


        //判斷是否第一次寫入賬單規則表
        private bool IsFirstWirte()
        {
            string sql = "select * from 生成賬單規則表 where 是否有效='Y' and 有效欄位!='K'";
            if (dbHelper.Exists(sql))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool IsExistCloseAccout(string ym)
        {
            string sql = "select * from 關賬信息表 where 年月='" + ym + "' and 是否有效='Y'";
            return dbHelper.Exists(sql);
        }
        public bool IsFirstImport(string ym)
        {
            string sql = "select isnull(count(*),0) from 使用者賬號信息表 where 年月='" + ym + "'";
            int count = Convert.ToInt32(dbHelper.ExecuteSql(sql));
            if (count == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //獲取標識代碼
        private DataTable GetIdentificationCode()
        {
            string sql = @"select * from(select 0 順序,參數名,說明 from 基本參數表 where 參數類型='標識代碼' and 是否有效='Y' and 參數名='A'
                union select row_number() over(order by 參數名 desc) 順序,參數名,說明 from 基本參數表 where 參數類型 = '標識代碼' and 是否有效 = 'Y' and 參數名 != 'A')t order by 順序";
            return dbHelper.ExecuteSqlTable(sql);
        }

        //獲取最大的規則編號的序列號
        private int GetMaxRuleSeq()
        {
            //string sql = "select 目前號碼 from 單據取號管理 where 單據類別='規則編號' and 單據名稱='規則編號' and 是否有效='Y'";         
            string sql = "select right(max(規則編號),8) from 生成賬單規則表";
            string seq = dbHelper.ExecuteSql(sql);
            if (seq == "")
            {
                seq = "0";
            }
            return Convert.ToInt32(seq);
        }

        public static DataTable Distinct(DataTable dt, string[] filedNames)
        {
            DataView dv = dt.DefaultView;
            DataTable DistTable = dv.ToTable("Dist", true, filedNames);
            return DistTable;
        }

        /// <summary>
        /// 判斷是否關賬
        /// </summary>
        /// <param name="ym"></param>
        /// <returns></returns>
        public bool IsCloseAccount(string ym)
        {
            if (dbHelper.Exists("select * from 關賬信息表 where 年月 = '" + ym + "' and 關賬狀態 = '已關賬' and 是否有效 = 'Y'"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 獲取notes計費配額
        /// </summary>
        /// <param name="mailboxQuota">信箱配額</param>
        /// <returns></returns>
        private string GetNotesBillingQuota(string mailboxQuota)
        {
            try
            {
                if (mailboxQuota.Substring(mailboxQuota.Length - 1, 1) == "M")
                {
                    return mailboxQuota.Substring(0, mailboxQuota.Length - 1) + "M";
                }
                else if (mailboxQuota.Substring(mailboxQuota.Length - 1, 1) == "G")
                {
                    return Convert.ToString(Convert.ToDouble(mailboxQuota.Substring(0, mailboxQuota.Length - 1)) * 1000) + "M";
                }
                else
                {
                    return "無限量";
                }
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        /// <summary>
        /// 判斷使用者賬號信息表郵箱地址是否存在
        /// </summary>
        /// <param name="email"></param>
        /// <param name="ym"></param>
        /// <returns></returns>
        private string IsExistUserInfo(string email, string ym)
        {
            string sql = "select 編號 FROM 使用者賬號信息表 where 郵箱地址 = '" + email + "' and 年月 = '" + ym + "' and 是否有效='Y'";
            return dbHelper.ExecuteSql(sql);
        }
        /// <summary>
        /// 判斷使用者賬號歷史表郵箱地址是否存在
        /// </summary>
        /// <param name="email"></param>
        /// <param name="ym"></param>
        /// <returns></returns>
        private string IsExistUserInfoHistory(string email, string ym)
        {
            string sql = "select 編號 FROM 使用者賬號歷史表 where 郵箱地址 = '" + email + "' and 年月 = '" + ym + "' and 是否有效='Y'";
            return dbHelper.ExecuteSql(sql);
        }
        /// <summary>
        /// 判斷使用者賬號上月表郵箱地址是否存在
        /// </summary>
        /// <param name="email"></param>
        /// <param name="ym"></param>
        /// <returns></returns>
        private string IsUserInfoLast(string email, string ym)
        {
            string sql = "select 編號 FROM 使用者賬號上月表 where 郵箱地址 = '" + email + "' and 年月 = '" + ym + "' and 是否有效='Y'";
            return dbHelper.ExecuteSql(sql);
        }

        /// <summary>
        /// 獲取上月郵箱賬號信息
        /// </summary>
        /// <param name="email">郵箱</param>
        /// <param name="ym">年月</param>
        /// <returns></returns>
        private DataTable GetLastMailInfo(string email, string ym)
        {
            string sql = "select 是否提前付費, 已付費至年, 已付費至月, 賬號說明, 是否免費賬號 from 使用者賬號上月表 where 郵箱地址 = '" + email + "' and 年月 = '" + ym + "' and 是否提前付費 = 'Y' and 是否有效 = 'Y' and 已付費至年+right('0' + 已付費至月, 2) >= '" + DateTime.Now.ToString("yyyyMM") + "'";
            return dbHelper.ExecuteSqlTable(sql);
        }

        public string GetNextNo(string tableName)
        {
            string no = "";
            string head = DateTime.Now.ToString("yyyyMMdd");
            string sql = "select top(1) 編號 FROM " + tableName + " where 編號 like '" + head + "%' order by 編號 desc";
            if (dbHelper.Exists(sql))
            {
                string maxNO = dbHelper.ExecuteSql(sql);
                int max = Convert.ToInt32(maxNO.Substring(8, maxNO.Length - 8)) + 1;
                no = head + string.Format("{0:000000000000}", max);
            }
            else
            {
                no = head + string.Format("{0:000000000000}", 1);
            }
            return no;
        }



        public DataTable GetSuperNotes()
        {
            MySqlHelper mySql = new MySqlHelper();
            string sql = @"select a.Foxeramail 郵箱地址,'SuperNotes' 項目,'普通賬號' 賬號類型,a.EmpNo 工號,a.Cname 姓名,a.BG 事業群,
                          a.BU 事業處,a.Code 費用代碼,c.domain 賬號服務器,c.created 賬號建立日期,c.modified 最後一次修改日期,
                          c.quota as 信箱配額,c.quota2 as 歸檔配額                          
                          FROM foxconncontrol.NotesToMySql a, postfix.alias b, postfix.mailbox c
                          where a.Foxeramail = b.address and b.goto= c.username
                          and a.active = 1 and b.active = 1 and c.active = 1";// limit 10 
            try
            {
                DataTable dt = mySql.GetDataSet(sql).Tables[0];
                return dt;
            }
            catch (Exception ex)
            {
                Log.Info(ex.ToString());
                throw ex;
            }
        }
        private static void Insert(DataTable dt)
        {
            string strConnstring = ConfigurationManager.ConnectionStrings["ProjectDB"].ConnectionString;
            using (System.Data.SqlClient.SqlBulkCopy sqlBC = new System.Data.SqlClient.SqlBulkCopy(strConnstring))
            {
                sqlBC.BatchSize = 100000;
                sqlBC.BulkCopyTimeout = 60;
                sqlBC.DestinationTableName = "使用者賬號信息臨時表";
                sqlBC.ColumnMappings.Add("郵箱地址", "郵箱地址");
                sqlBC.ColumnMappings.Add("項目", "項目");
                sqlBC.ColumnMappings.Add("賬號類型", "賬號類型");
                sqlBC.ColumnMappings.Add("工號", "工號");
                sqlBC.ColumnMappings.Add("姓名", "姓名");
                sqlBC.ColumnMappings.Add("事業群", "事業群");
                sqlBC.ColumnMappings.Add("事業處", "事業處");
                sqlBC.ColumnMappings.Add("費用代碼", "費用代碼");
                sqlBC.ColumnMappings.Add("賬號服務器", "賬號服務器");
                sqlBC.ColumnMappings.Add("賬號建立日期", "賬號建立日期");
                sqlBC.ColumnMappings.Add("最後一次修改日期", "最後一次修改日期");
                sqlBC.ColumnMappings.Add("信箱配額", "信箱配額");
                sqlBC.ColumnMappings.Add("歸檔配額", "歸檔配額");
                sqlBC.WriteToServer(dt);
            }
        }
        private static void InsertNotesServer(DataTable dt)
        {
            string strConnstring = ConfigurationManager.ConnectionStrings["ProjectDB"].ConnectionString;
            using (System.Data.SqlClient.SqlBulkCopy sqlBC = new System.Data.SqlClient.SqlBulkCopy(strConnstring))
            {
                sqlBC.BatchSize = 100000;
                sqlBC.BulkCopyTimeout = 60;
                sqlBC.DestinationTableName = "Notes賬號服務器";
                sqlBC.ColumnMappings.Add("郵箱地址", "郵箱地址");
                sqlBC.ColumnMappings.Add("賬號服務器", "賬號服務器");
                sqlBC.WriteToServer(dt);
            }
        }

        public DataTable GetNotes()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("郵箱地址", typeof(System.String));
            dt.Columns.Add("項目", typeof(System.String));
            dt.Columns.Add("賬號類型", typeof(System.String));
            dt.Columns.Add("工號", typeof(System.String));
            dt.Columns.Add("姓名", typeof(System.String));
            dt.Columns.Add("事業群", typeof(System.String));
            dt.Columns.Add("事業處", typeof(System.String));
            dt.Columns.Add("費用代碼", typeof(System.String));
            dt.Columns.Add("賬號服務器", typeof(System.String));
            dt.Columns.Add("賬號建立日期", typeof(System.DateTime));
            dt.Columns.Add("最後一次修改日期", typeof(System.DateTime));
            dt.Columns.Add("信箱配額", typeof(System.String));
            dt.Columns.Add("歸檔配額", typeof(System.String));
            NotesSession ns = new NotesSession();
            ns.Initialize("89386141");

            if (ns != null)
            {
                NotesDatabase db = ns.GetDatabase("CHNLH01/FOXCONN", "foxconncontrol.nsf", false);
                NotesView view = db.GetView(@"人員資料\Only Notes");//人員資料\依組織 //人員資料\Only Notes
                int count = view.EntryCount;

                NotesDocument doc = view.GetFirstDocument();
                int i = 0;

                while (doc != null)// && i < 5
                {
                    DataRow dr = dt.NewRow();
                    dr["郵箱地址"] = ((object[])doc.GetItemValue("Notes"))[0];//.ToString().Replace("CN=", "").Replace("OU=", "").Replace("O=", "")
                    dr["項目"] = "Notes";
                    dr["賬號類型"] = "普通賬號";
                    dr["工號"] = ((object[])doc.GetItemValue("EmpNo"))[0];//.ToString();
                    dr["姓名"] = ((object[])doc.GetItemValue("CName"))[0];//.ToString();
                    dr["事業群"] = ((object[])doc.GetItemValue("BG"))[0];//.ToString();
                    dr["事業處"] = ((object[])doc.GetItemValue("BU"))[0];//.ToString();
                    dr["費用代碼"] = ((object[])doc.GetItemValue("Code"))[0];//.ToString();
                    dr["賬號服務器"] = "";
                    dr["賬號建立日期"] = Convert.ToDateTime("1900/1/1");
                    dr["最後一次修改日期"] = Convert.ToDateTime("1900/1/1");
                    dr["信箱配額"] = ((object[])doc.GetItemValue("MailQuota"))[0];//.ToString();
                    dr["歸檔配額"] = "";
                    dt.Rows.Add(dr);
                    doc = view.GetNextDocument(doc);
                    //i++;
                }
            }
            return dt;
        }


        public DataTable GetVIPMail()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("郵箱地址", typeof(System.String));
            dt.Columns.Add("項目", typeof(System.String));
            dt.Columns.Add("賬號類型", typeof(System.String));
            dt.Columns.Add("賬號服務器", typeof(System.String));

            dt.Columns.Add("工號", typeof(System.String));
            dt.Columns.Add("姓名", typeof(System.String));
            dt.Columns.Add("事業群", typeof(System.String));
            dt.Columns.Add("事業處", typeof(System.String));
            dt.Columns.Add("費用代碼", typeof(System.String));
            dt.Columns.Add("賬號建立日期", typeof(System.DateTime));
            dt.Columns.Add("最後一次修改日期", typeof(System.DateTime));
            dt.Columns.Add("信箱配額", typeof(System.String));
            dt.Columns.Add("歸檔配額", typeof(System.String));
            NotesSession ns = new NotesSession();
            ns.Initialize("89386141");

            if (ns != null)
            {
                NotesDatabase db = ns.GetDatabase("CHNLHDB01/FOXCONN", "vipmailuserlist.nsf", false);
                NotesView view = db.GetView(@"VIPmail userList");
                int count = view.EntryCount;

                NotesDocument doc = view.GetFirstDocument();
                int i = 0;

                while (doc != null)// && i < 5
                {
                    DataRow dr = dt.NewRow();
                    dr["郵箱地址"] = ((object[])doc.GetItemValue("Notes"))[0];//.ToString().Replace("CN=", "").Replace("OU=", "").Replace("O=", "");
                    dr["項目"] = "Notes";
                    dr["賬號類型"] = "VIPMail賬號";
                    dr["賬號服務器"] = ((object[])doc.GetItemValue("MailServer"))[0];//.ToString();

                    dr["工號"] = "";
                    dr["姓名"] = "";
                    dr["事業群"] = "";
                    dr["事業處"] = "";
                    dr["費用代碼"] = "";
                    dr["賬號建立日期"] = "1900/1/1";
                    dr["最後一次修改日期"] = "1900/1/1";
                    dr["信箱配額"] = "";
                    dr["歸檔配額"] = "";
                    dt.Rows.Add(dr);
                    doc = view.GetNextDocument(doc);
                    //i++;
                }
            }
            return dt;
        }

        public DataTable GetPushMail()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("郵箱地址", typeof(System.String));
            dt.Columns.Add("項目", typeof(System.String));
            dt.Columns.Add("賬號類型", typeof(System.String));
            dt.Columns.Add("姓名", typeof(System.String));
            dt.Columns.Add("事業群", typeof(System.String));
            dt.Columns.Add("賬號服務器", typeof(System.String));
            dt.Columns.Add("狀態", typeof(System.String));

            dt.Columns.Add("工號", typeof(System.String));
            dt.Columns.Add("事業處", typeof(System.String));
            dt.Columns.Add("費用代碼", typeof(System.String));
            dt.Columns.Add("賬號建立日期", typeof(System.DateTime));
            dt.Columns.Add("最後一次修改日期", typeof(System.DateTime));
            dt.Columns.Add("信箱配額", typeof(System.String));
            dt.Columns.Add("歸檔配額", typeof(System.String));
            NotesSession ns = new NotesSession();
            ns.Initialize("89386141");

            if (ns != null)
            {
                NotesDatabase db = ns.GetDatabase("CHNLHDB01/FOXCONN", "vipmailuserlist.nsf", false);
                NotesView view = db.GetView(@"Pushmail User List");
                int count = view.EntryCount;

                NotesDocument doc = view.GetFirstDocument();
                int i = 0;

                while (doc != null)// && i < 5
                {
                    DataRow dr = dt.NewRow();
                    dr["郵箱地址"] = ((object[])doc.GetItemValue("NotesAddress"))[0];//.ToString().Replace("CN=", "").Replace("OU=", "").Replace("O=", "");
                    dr["項目"] = "Notes";
                    dr["賬號類型"] = "PushMail賬號";
                    dr["姓名"] = ((object[])doc.GetItemValue("Cname"))[0];//.ToString();
                    dr["事業群"] = ((object[])doc.GetItemValue("BG"))[0];//.ToString();
                    dr["賬號服務器"] = ((object[])doc.GetItemValue("Server"))[0];//.ToString();
                    dr["狀態"] = ((object[])doc.GetItemValue("Status"))[0];//.ToString();

                    dr["工號"] = "";
                    dr["事業處"] = "";
                    dr["費用代碼"] = "";
                    dr["賬號建立日期"] = "1900/1/1";
                    dr["最後一次修改日期"] = "1900/1/1";
                    dr["信箱配額"] = "";
                    dr["歸檔配額"] = "";
                    dt.Rows.Add(dr);
                    doc = view.GetNextDocument(doc);
                    //i++;
                }
            }
            DataView dv = dt.DefaultView;
            dv.RowFilter = "狀態 = 'Enable'";
            DataTable dt2 = dv.ToTable();
            return dt2;
        }

        public DataTable GetNotesServer()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("郵箱地址", typeof(System.String));
            dt.Columns.Add("賬號服務器", typeof(System.String));
            NotesSession ns = new NotesSession();
            ns.Initialize("89386141");

            if (ns != null)
            {
                //Log.Info(ns);
                NotesDatabase db = ns.GetDatabase("ZLHDGATE1/FOXCONN", "names.nsf", false);
                //Log.Info("NotesDatabase:" + db);
                NotesView view = db.GetView(@"People By Mail Directory");
                int count = view.EntryCount;
                NotesDocument doc = view.GetFirstDocument();
                int i = 0;

                while (doc != null)// && i < 5
                {
                    DataRow dr = dt.NewRow();
                    dr["郵箱地址"] = ((object[])doc.GetItemValue("FullName"))[0];//.ToString();             
                    dr["賬號服務器"] = ((object[])doc.GetItemValue("MailServer"))[0];//.ToString();
                    dt.Rows.Add(dr);
                    doc = view.GetNextDocument(doc);
                    //i++;
                }
            }
            return dt;
        }

        /// <summary>
        /// 插入郵件發送表
        /// </summary>
        /// <param name="consignee">收件人</param>
        /// <param name="tip">主題</param>
        /// <param name="content">郵件正文</param>
        private string SendMail(string consignee, string tip, string content)
        {
            string sql = @"INSERT INTO [dbo].[郵件發送表] (
	                            [ID],
	                            [發送郵件的IP],
	                            [端口號],
	                            [系統名稱],
	                            [數據庫名稱],
	                            [發件人],
	                            [收件人],
	                            [主題],
	                            [內容],
	                            [建立者],
	                            [建立時間],
	                            [發送狀態],
	                            [錯誤信息],
	                            [是否重發],
	                            [時間間隔],
	                            [發送時間],
	                            [發送次數],
	                            [參考單號],
	                            [預留1],
	                            [預留2],
	                            [預留3] 
                            )
                            VALUES
	                            (
		                            NEWID(),
		                            N'10.134.28.95',
		                            25,
		                            N'郵箱收費對賬系統',
		                            N'Ame_FSC1_EmailCharge',
		                            N'celersystemtest@mail.foxconn.com',
		                            N'" + consignee + "'," +
                        "N'" + tip + "'," +
                        "N'" + content + "'," +
                        @"N'Auto',
                                    getdate(),
	                                N'N',
	                                N'',
	                                N'N',
	                                .00,
	                                getdate(),
	                                0,
	                                N'',
	                                0,
	                                N'',
                                    N''
                                 ); ";
            return sql;
        }
    }
}
