﻿using SqlSugar;

namespace Model
{
    /// <summary>
    /// 
    /// </summary>
    public class 使用者賬號未出賬表
    {
        /// <summary>
        /// 
        /// </summary>
        public 使用者賬號未出賬表()
        {
        }

        private System.String _編號;
        /// <summary>
        /// 
        /// </summary>
        public System.String 編號 { get { return this._編號; } set { this._編號 = value; } }

        private System.String _年月;
        /// <summary>
        /// 
        /// </summary>
        public System.String 年月 { get { return this._年月; } set { this._年月 = value; } }

        private System.String _郵箱地址;
        /// <summary>
        /// 
        /// </summary>
        public System.String 郵箱地址 { get { return this._郵箱地址; } set { this._郵箱地址 = value; } }

        private System.String _項目;
        /// <summary>
        /// 
        /// </summary>
        public System.String 項目 { get { return this._項目; } set { this._項目 = value; } }

        private System.String _賬號類型;
        /// <summary>
        /// 
        /// </summary>
        public System.String 賬號類型 { get { return this._賬號類型; } set { this._賬號類型 = value; } }

        private System.String _工號;
        /// <summary>
        /// 
        /// </summary>
        public System.String 工號 { get { return this._工號; } set { this._工號 = value; } }

        private System.String _姓名;
        /// <summary>
        /// 
        /// </summary>
        public System.String 姓名 { get { return this._姓名; } set { this._姓名 = value; } }

        private System.String _事業群;
        /// <summary>
        /// 
        /// </summary>
        public System.String 事業群 { get { return this._事業群; } set { this._事業群 = value; } }

        private System.String _事業處;
        /// <summary>
        /// 
        /// </summary>
        public System.String 事業處 { get { return this._事業處; } set { this._事業處 = value; } }

        private System.String _付費法人;
        /// <summary>
        /// 
        /// </summary>
        public System.String 付費法人 { get { return this._付費法人; } set { this._付費法人 = value; } }

        private System.String _費用代碼;
        /// <summary>
        /// 
        /// </summary>
        public System.String 費用代碼 { get { return this._費用代碼; } set { this._費用代碼 = value; } }

        private System.String _賬號服務器;
        /// <summary>
        /// 
        /// </summary>
        public System.String 賬號服務器 { get { return this._賬號服務器; } set { this._賬號服務器 = value; } }

        private System.String _賬號廠區;
        /// <summary>
        /// 
        /// </summary>
        public System.String 賬號廠區 { get { return this._賬號廠區; } set { this._賬號廠區 = value; } }

        private System.DateTime _賬號建立日期;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 賬號建立日期 { get { return this._賬號建立日期; } set { this._賬號建立日期 = value; } }

        private System.DateTime _最後一次修改日期;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 最後一次修改日期 { get { return this._最後一次修改日期; } set { this._最後一次修改日期 = value; } }

        private System.DateTime _最後一次登錄時間;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 最後一次登錄時間 { get { return this._最後一次登錄時間; } set { this._最後一次登錄時間 = value; } }

        private System.String _信箱配額;
        /// <summary>
        /// 
        /// </summary>
        public System.String 信箱配額 { get { return this._信箱配額; } set { this._信箱配額 = value; } }

        private System.String _歸檔配額;
        /// <summary>
        /// 
        /// </summary>
        public System.String 歸檔配額 { get { return this._歸檔配額; } set { this._歸檔配額 = value; } }

        private System.String _計費配額;
        /// <summary>
        /// 
        /// </summary>
        public System.String 計費配額 { get { return this._計費配額; } set { this._計費配額 = value; } }

        private System.Decimal _信箱費用;
        /// <summary>
        /// 
        /// </summary>
        public System.Decimal 信箱費用 { get { return this._信箱費用; } set { this._信箱費用 = value; } }

        private System.Decimal _歸檔費用;
        /// <summary>
        /// 
        /// </summary>
        public System.Decimal 歸檔費用 { get { return this._歸檔費用; } set { this._歸檔費用 = value; } }

        private System.Decimal _費用合計;
        /// <summary>
        /// 
        /// </summary>
        public System.Decimal 費用合計 { get { return this._費用合計; } set { this._費用合計 = value; } }

        private System.String _是否提前付費;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否提前付費 { get { return this._是否提前付費; } set { this._是否提前付費 = value; } }

        private System.String _已付費至年;
        /// <summary>
        /// 
        /// </summary>
        public System.String 已付費至年 { get { return this._已付費至年; } set { this._已付費至年 = value; } }

        private System.String _已付費至月;
        /// <summary>
        /// 
        /// </summary>
        public System.String 已付費至月 { get { return this._已付費至月; } set { this._已付費至月 = value; } }

        private System.String _賬號說明;
        /// <summary>
        /// 
        /// </summary>
        public System.String 賬號說明 { get { return this._賬號說明; } set { this._賬號說明 = value; } }

        private System.String _是否移除事業群;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否移除事業群 { get { return this._是否移除事業群; } set { this._是否移除事業群 = value; } }

        private System.DateTime _移除事業群日期;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 移除事業群日期 { get { return this._移除事業群日期; } set { this._移除事業群日期 = value; } }

        private System.String _是否刪除;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否刪除 { get { return this._是否刪除; } set { this._是否刪除 = value; } }

        private System.String _是否結算;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否結算 { get { return this._是否結算; } set { this._是否結算 = value; } }

        private System.String _是否生成賬單;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否生成賬單 { get { return this._是否生成賬單; } set { this._是否生成賬單 = value; } }

        private System.String _賬單編號;
        /// <summary>
        /// 
        /// </summary>
        public System.String 賬單編號 { get { return this._賬單編號; } set { this._賬單編號 = value; } }

        private System.String _當月是否收款;
        /// <summary>
        /// 
        /// </summary>
        public System.String 當月是否收款 { get { return this._當月是否收款; } set { this._當月是否收款 = value; } }

        private System.String _是否免費賬號;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否免費賬號 { get { return this._是否免費賬號; } set { this._是否免費賬號 = value; } }

        private System.String _未確認狀態;
        /// <summary>
        /// 
        /// </summary>
        public System.String 未確認狀態 { get { return this._未確認狀態; } set { this._未確認狀態 = value; } }

        private System.String _賬號狀態;
        /// <summary>
        /// 
        /// </summary>
        public System.String 賬號狀態 { get { return this._賬號狀態; } set { this._賬號狀態 = value; } }

        private System.String _退回標記;
        /// <summary>
        /// 
        /// </summary>
        public System.String 退回標記 { get { return this._退回標記; } set { this._退回標記 = value; } }

        private System.String _對賬窗口賬號;
        /// <summary>
        /// 
        /// </summary>
        public System.String 對賬窗口賬號 { get { return this._對賬窗口賬號; } set { this._對賬窗口賬號 = value; } }

        private System.String _對賬窗口姓名;
        /// <summary>
        /// 
        /// </summary>
        public System.String 對賬窗口姓名 { get { return this._對賬窗口姓名; } set { this._對賬窗口姓名 = value; } }

        private System.String _對賬窗口聯繫方式;
        /// <summary>
        /// 
        /// </summary>
        public System.String 對賬窗口聯繫方式 { get { return this._對賬窗口聯繫方式; } set { this._對賬窗口聯繫方式 = value; } }

        private System.String _對賬窗口郵箱地址;
        /// <summary>
        /// 
        /// </summary>
        public System.String 對賬窗口郵箱地址 { get { return this._對賬窗口郵箱地址; } set { this._對賬窗口郵箱地址 = value; } }

        private System.String _賬單法人代碼;
        /// <summary>
        /// 
        /// </summary>
        public System.String 賬單法人代碼 { get { return this._賬單法人代碼; } set { this._賬單法人代碼 = value; } }

        private System.String _賬單法人名稱;
        /// <summary>
        /// 
        /// </summary>
        public System.String 賬單法人名稱 { get { return this._賬單法人名稱; } set { this._賬單法人名稱 = value; } }

        private System.DateTime _停用日期;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 停用日期 { get { return this._停用日期; } set { this._停用日期 = value; } }

        private System.DateTime _解鎖日期;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 解鎖日期 { get { return this._解鎖日期; } set { this._解鎖日期 = value; } }

        private System.DateTime _第一次郵件提醒時間;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 第一次郵件提醒時間 { get { return this._第一次郵件提醒時間; } set { this._第一次郵件提醒時間 = value; } }

        private System.DateTime _郵件提醒時間;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 郵件提醒時間 { get { return this._郵件提醒時間; } set { this._郵件提醒時間 = value; } }

        private System.Int32 _郵件提醒次數;
        /// <summary>
        /// 
        /// </summary>
        public System.Int32 郵件提醒次數 { get { return this._郵件提醒次數; } set { this._郵件提醒次數 = value; } }

        private System.String _是否台幹;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否台幹 { get { return this._是否台幹; } set { this._是否台幹 = value; } }

        private System.String _異動賬號;
        /// <summary>
        /// 
        /// </summary>
        public System.String 異動賬號 { get { return this._異動賬號; } set { this._異動賬號 = value; } }

        private System.String _香信對接;
        /// <summary>
        /// 
        /// </summary>
        public System.String 香信對接 { get { return this._香信對接; } set { this._香信對接 = value; } }

        private System.String _是否有效;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否有效 { get { return this._是否有效; } set { this._是否有效 = value; } }

        private System.String _建立者;
        /// <summary>
        /// 
        /// </summary>
        public System.String 建立者 { get { return this._建立者; } set { this._建立者 = value; } }

        private System.DateTime _建立時間;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 建立時間 { get { return this._建立時間; } set { this._建立時間 = value; } }

        private System.String _修改者;
        /// <summary>
        /// 
        /// </summary>
        public System.String 修改者 { get { return this._修改者; } set { this._修改者 = value; } }

        private System.DateTime _修改時間;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 修改時間 { get { return this._修改時間; } set { this._修改時間 = value; } }

        private System.String _預留1;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留1 { get { return this._預留1; } set { this._預留1 = value; } }

        private System.String _預留2;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留2 { get { return this._預留2; } set { this._預留2 = value; } }

        private System.String _預留3;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留3 { get { return this._預留3; } set { this._預留3 = value; } }

        private System.String _預留4;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留4 { get { return this._預留4; } set { this._預留4 = value; } }

        private System.String _預留5;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留5 { get { return this._預留5; } set { this._預留5 = value; } }

        private System.Int32 _預留6;
        /// <summary>
        /// 
        /// </summary>
        public System.Int32 預留6 { get { return this._預留6; } set { this._預留6 = value; } }

        private System.Int32 _預留7;
        /// <summary>
        /// 
        /// </summary>
        public System.Int32 預留7 { get { return this._預留7; } set { this._預留7 = value; } }

        private System.Decimal _預留8;
        /// <summary>
        /// 
        /// </summary>
        public System.Decimal 預留8 { get { return this._預留8; } set { this._預留8 = value; } }

        private System.Decimal _預留9;
        /// <summary>
        /// 
        /// </summary>
        public System.Decimal 預留9 { get { return this._預留9; } set { this._預留9 = value; } }

        private System.DateTime _預留10;
        /// <summary>
        /// 
        /// </summary>
        public System.DateTime 預留10 { get { return this._預留10; } set { this._預留10 = value; } }
    }
}
