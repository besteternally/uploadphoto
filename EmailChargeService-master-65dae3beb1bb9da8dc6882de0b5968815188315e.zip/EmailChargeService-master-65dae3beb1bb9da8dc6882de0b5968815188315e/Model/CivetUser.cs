﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class CivetUser
    {
        private string _username;
        private string _fn;
        private string _sex;
        private string _country;
        private string _suborg;
        private string _orgname;
        private string _bg;
        private string _bu;
        private string _costcode;
        private string _area;
        private string _brithday;
        private string _edudegree;
        private string _class;
        private string _title;
        private string _grade;
        private string _jobstatus;
        private string _hiredate;
        private string _leavedata;
        private string _civetid;
        private string _head;
        private string _userid;
        private string _mobile;

        /// <summary>
        /// 工号
        /// </summary>
        public string USERNAME
        {
            get
            {
                return _username;
            }

            set
            {
                _username = value;
            }
        }
        /// <summary>
        /// 姓名
        /// </summary>
        public string FN
        {
            get
            {
                return _fn;
            }

            set
            {
                _fn = value;
            }
        }
        /// <summary>
        /// 性别
        /// </summary>
        public string SEX
        {
            get
            {
                return _sex;
            }

            set
            {
                _sex = value;
            }
        }
        /// <summary>
        /// 国籍
        /// </summary>
        public string COUNTRY
        {
            get
            {
                return _country;
            }

            set
            {
                _country = value;
            }
        }
        /// <summary>
        /// 次集团
        /// </summary>
        public string SUBORG
        {
            get
            {
                return _suborg;
            }

            set
            {
                _suborg = value;
            }
        }
        /// <summary>
        /// 法人
        /// </summary>
        public string ORGNAME
        {
            get
            {
                return _orgname;
            }

            set
            {
                _orgname = value;
            }
        }
        /// <summary>
        /// 事业群
        /// </summary>
        public string BG
        {
            get
            {
                return _bg;
            }

            set
            {
                _bg = value;
            }
        }
        /// <summary>
        /// 事业处
        /// </summary>
        public string BU
        {
            get
            {
                return _bu;
            }

            set
            {
                _bu = value;
            }
        }
        /// <summary>
        /// 费用代码
        /// </summary>
        public string COST_CODE
        {
            get
            {
                return _costcode;
            }

            set
            {
                _costcode = value;
            }
        }
        /// <summary>
        /// 地区
        /// </summary>
        public string AREA
        {
            get
            {
                return _area;
            }

            set
            {
                _area = value;
            }
        }
        /// <summary>
        /// 出生日期
        /// </summary>
        public string BIRTHDAY
        {
            get
            {
                return _brithday;
            }

            set
            {
                _brithday = value;
            }
        }
        /// <summary>
        /// 学历
        /// </summary>
        public string EDU_DEGREE
        {
            get
            {
                return _edudegree;
            }

            set
            {
                _edudegree = value;
            }
        }
        /// <summary>
        /// 资位
        /// </summary>
        public string CLASS
        {
            get
            {
                return _class;
            }

            set
            {
                _class = value;
            }
        }
        /// <summary>
        /// 职务
        /// </summary>
        public string TITLE
        {
            get
            {
                return _title;
            }

            set
            {
                _title = value;
            }
        }
        /// <summary>
        /// 技委会
        /// </summary>
        public string GRADE
        {
            get
            {
                return _grade;
            }

            set
            {
                _grade = value;
            }
        }
        /// <summary>
        /// 状态
        /// </summary>
        public string JOB_STATUS
        {
            get
            {
                return _jobstatus;
            }

            set
            {
                _jobstatus = value;
            }
        }
        /// <summary>
        /// 入职日期
        /// </summary>
        public string HIREDATE
        {
            get
            {
                return _hiredate;
            }

            set
            {
                _hiredate = value;
            }
        }
        /// <summary>
        /// 离职日期
        /// </summary>
        public string LEAVEDATE
        {
            get
            {
                return _leavedata;
            }

            set
            {
                _leavedata = value;
            }
        }
        public string CIVETID
        {
            get
            {
                return _civetid;
            }

            set
            {
                _civetid = value;
            }
        }
        /// <summary>
        /// 头像
        /// </summary>
        public string HEAD
        {
            get
            {
                return _head;
            }

            set
            {
                _head = value;
            }
        }
        /// <summary>
        /// 邮箱
        /// </summary>
        public string USERID
        {
            get
            {
                return _userid;
            }

            set
            {
                _userid = value;
            }
        }
        /// <summary>
        /// 手机号
        /// </summary>
        public string MOBILE
        {
            get
            {
                return _mobile;
            }

            set
            {
                _mobile = value;
            }
        }
    }
}
