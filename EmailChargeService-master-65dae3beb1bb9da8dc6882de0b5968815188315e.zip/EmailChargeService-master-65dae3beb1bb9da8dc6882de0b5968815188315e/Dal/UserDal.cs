﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Dal
{
    public class UserDal:MsSqlDbContext<使用者賬號信息表>
    {
        log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        //执行事务更新表
        public void UpdateUser(List<使用者賬號信息表> updateUserList)
        {
            int i = 0;
            try
            {
                Db.Ado.BeginTran();
                foreach (var user in updateUserList)
                {
                    CurrentDb.AsUpdateable(user).UpdateColumns(it => new {it.事業群,it.事業處,it.付費法人,it.費用代碼 ,it.香信對接,it.修改時間,it.修改者 }).ExecuteCommand();
                }
                Db.Ado.CommitTran();
            }
            catch (Exception ex)
            {
                Db.Ado.RollbackTran();
                Log.Info(ex.ToString());
                Log.Info(updateUserList[i]);
                throw ex;
            }
        }
    }
}
