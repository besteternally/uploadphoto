﻿using Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Bll
{
    public static class GetUserFromICivet
    {
        private static readonly string APPID = "luu8d5wuDwhrwEQ1kPa24HFJTUQOpy5s0";
        private static readonly string KEY = "Emailcivet1909";
        private static log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        public static CivetResult<CivetUser> getUserByEmpNo(string empNo)
        {
            try
            {
                FSC.Civet.UserInfoAPI.CivetUserAPI.Config = new FSC.Civet.UserInfoAPI.APIConfig(APPID, KEY);
                string result = FSC.Civet.UserInfoAPI.CivetUserAPI.SearchByEmpNo(empNo);
                JsonSerializer serializer = new JsonSerializer();
                StringReader sr = new StringReader(result);
                object o = serializer.Deserialize(new JsonTextReader(sr), typeof(CivetResult<CivetUser>));
                CivetResult<CivetUser> resultObj = o as CivetResult<CivetUser>;
                //Log.Info(empNo+""+resultObj.data.Count);               
                return resultObj;
            }
            catch (Exception ex)
            {
                Log.Info(ex);
                return null;
            }
        }
    }
}
