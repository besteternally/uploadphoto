﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class LayuiResult<T>
    {
        private int _code;
        private string _msg;
        private int _count;
        private List<T> _data;

        public int code
        {
            get
            {
                return _code;
            }

            set
            {
                _code = value;
            }
        }

        public string msg
        {
            get
            {
                return _msg;
            }

            set
            {
                _msg = value;
            }
        }

        public int count
        {
            get
            {
                return _count;
            }

            set
            {
                _count = value;
            }
        }

        public List<T> data
        {
            get
            {
                return _data;
            }

            set
            {
                _data = value;
            }
        }
    }
}
