﻿using Bll;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;

namespace EmailChargeService.Controllers
{
    public class DoMainController : ApiController
    {
        private readonly GetReportBll _getReportBll = new GetReportBll();
        private readonly GenerateBillBll _generateBillBll = new GenerateBillBll();
        private readonly log4net.ILog _log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        [HttpPost]
        public void PDFDoMain()
        {
            _log.Info("開始合成PDF");
            _getReportBll.DoMain();
            _log.Info("合成PDF完毕");
        }

        [HttpPost]
        public string BillDoMain(string id)
        {
            _log.Info("开始生成对账单");
            string res = _generateBillBll.DoMain(id);
            _log.Info("生成对账单完毕");
            return res;
        }

        [HttpPost]
        public string ECCDoMain(string id)
        {
            _log.Info("开始结算");
            string res = _generateBillBll.UseECCostSettlem(id);
            _log.Info("结束结算");
            return res;
        }

        [HttpPut]
        public string UpdateUser()
        {
            _log.Info("开始对接香信信息");
            EmailUserInfoBll emailUserInfoBll = new EmailUserInfoBll();
            string res=emailUserInfoBll.UpdateEmailUserInfo();
            if (res != "")
            {
                _log.Info(res);
                return "执行失败";
            }
            _log.Info("对接香信信息结束");
            return "";
        }

        [HttpPost]
        public string UpdateRule(string bg)
        {
            _log.Info("开始修改账单规则");
            string res = RuleBll.Instance.UpdateRule(bg);
            if (res != "")
            {
                _log.Info(res);
                return $"事業群{bg}修改賬單規則出現錯誤!";
            }
            return "修改賬單規則成功!";
        }

        [HttpGet]
        public CivetResult<CivetUser> GetUserFromCivet(string userId)=>GetUserFromICivet.getUserByEmpNo(userId);


        [HttpGet]
        public void TestRole() => (new EmailUserInfoBll()).UpdateRule();
    }
}
