﻿using EmailChargeService.App_Start;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;

namespace EmailChargeService
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            //跨域配置
            config.EnableCors(new EnableCorsAttribute(origins: "http://10.134.96.123", headers: "*", methods: "POST"));

            config.MapHttpAttributeRoutes();
            config.Routes.MapHttpRoute(
                name: "BillApi",
                routeTemplate: "api/{controller}/{action}/{yearMonth}/{partBId}",
                defaults: new { id = DateTime.Now.ToString("yyyyMM") }
            );
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{action}/{id}",
                defaults: new { id = DateTime.Now.ToString("yyyyMM") }
            );
            //异常处理
            config.Filters.Add(new WebApiExceptionFilterAttribute());
        }
    }
}
