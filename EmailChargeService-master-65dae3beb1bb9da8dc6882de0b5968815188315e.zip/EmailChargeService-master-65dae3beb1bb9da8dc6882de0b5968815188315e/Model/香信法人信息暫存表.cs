﻿using SqlSugar;

namespace Model
{
    /// <summary>
    /// 
    /// </summary>
    public class 香信法人信息暫存表
    {
        /// <summary>
        /// 
        /// </summary>
        public 香信法人信息暫存表()
        {
        }

        private System.String _工號;
        /// <summary>
        /// 
        /// </summary>
        public System.String 工號 { get { return this._工號; } set { this._工號 = value; } }

        private System.String _法人;
        /// <summary>
        /// 
        /// </summary>
        public System.String 法人 { get { return this._法人; } set { this._法人 = value; } }

        private System.String _是否台幹;
        /// <summary>
        /// 
        /// </summary>
        public System.String 是否台幹 { get { return this._是否台幹; } set { this._是否台幹 = value; } }

        private System.String _預留1;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留1 { get { return this._預留1; } set { this._預留1 = value; } }

        private System.String _預留2;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留2 { get { return this._預留2; } set { this._預留2 = value; } }

        private System.String _預留3;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留3 { get { return this._預留3; } set { this._預留3 = value; } }

        private System.String _預留4;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留4 { get { return this._預留4; } set { this._預留4 = value; } }

        private System.String _預留5;
        /// <summary>
        /// 
        /// </summary>
        public System.String 預留5 { get { return this._預留5; } set { this._預留5 = value; } }
    }
}
