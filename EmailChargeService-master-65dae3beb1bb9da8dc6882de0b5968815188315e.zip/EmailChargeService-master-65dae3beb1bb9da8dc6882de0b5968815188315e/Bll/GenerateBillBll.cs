﻿using Dal;
using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Util;
using static Util.CommonUse;

namespace Bll
{
    public class GenerateBillBll
    {
        private log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private DbHelper dbhelper = new DbHelper();
        private static readonly string adminUserAccount = System.Configuration.ConfigurationManager.AppSettings["adminUserAccount"].ToString();
        private static readonly string adminUserPasswd = System.Configuration.ConfigurationManager.AppSettings["adminUserPasswd"].ToString();
        private static readonly string reportDomainString = System.Configuration.ConfigurationManager.AppSettings["reportDomainString"].ToString();
        private static readonly string emaliChargeWebserviceUrl = System.Configuration.ConfigurationManager.AppSettings["emaliChargeWebserviceUrl"].ToString();

        /// <summary>
        /// 生成對賬單
        /// </summary>
        /// <param name="id">年月</param>
        /// <returns></returns>
        public string DoMain(string id)
        {
            try
            {
                //DataTable partBId = dbhelper.ExecuteSqlTable("SELECT 公司代碼 FROM [dbo].[乙方資料信息表] where 是否有效='Y'");
                //if (partBId == null || partBId.Rows.Count != 1)
                //{
                //    return $"有多個開票法人!";
                //}
                if (!dbhelper.Exists("select 年月 from 關賬信息表 where 關賬狀態 = '已關賬' and 年月 = '" + id + "'"))
                {
                    return id + "還未關賬不能生產對賬單!";
                }
                if (dbhelper.ExecuteSql("select top 1 IsRunning from IsRun") == "N")
                {
                    dbhelper.Execute("update IsRun set IsRunning='Y'");
                    int countBefore =
                        Convert.ToInt32(dbhelper.ExecuteSql("select count(1) from 郵箱費用明細表頭 where [是否有效]='Y'"));
                    int count=GenerateBill(id, "");
                    dbhelper.Execute("update IsRun set IsRunning='N'");
                    int countAfter =
                        Convert.ToInt32(dbhelper.ExecuteSql("select count(1) from 郵箱費用明細表頭 where [是否有效]='Y'"));
                    count = countAfter - countBefore;
                    DataTable consigneedt = dbhelper.ExecuteSqlTable(@"SELECT DISTINCT
	                                                                    a.[工號],
	                                                                    a.[郵箱],
	                                                                    a.[姓名] 
                                                                    FROM
	                                                                    人員信息表 a
	                                                                    INNER JOIN UinR b ON a.[工號] = b.UserID 
                                                                    WHERE
	                                                                    b.RoleID = N'對賬管理員' 
	                                                                    AND a.[是否有效] = 'Y'");

                    DataTable dt2 = dbhelper.ExecuteSqlTable("select * from 送審跟催模板 where 流程ID='生成對賬單' and 類型=N'success'");
                    foreach (DataRow dr in consigneedt.Rows)
                    {
                        string tip = dt2.Rows[0]["主旨"].ToString().Trim();
                        string content = dt2.Rows[0]["郵件頭"].ToString().Trim() + dr["姓名"].ToString().Trim().Replace("'", "''") + dt2.Rows[0]["郵件正文"].ToString().Trim() + "對賬單年月：" + id+"，生成對賬單的數量："+count + dt2.Rows[0]["郵件結尾"].ToString().Trim();
                        string sql = SendMail(dr["郵箱"].ToString().Trim(), tip, content);
                        dbhelper.ExecuteSql(sql);
                    }
                    return "";
                }
                return "當前有其他人或者程序正在生成對賬單!";
            }
            catch (Exception ex)
            {
                dbhelper.Execute("update IsRun set IsRunning='N'");
                Log.Error(ex.Message);
                string consignee = dbhelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型=N'異常狀況聯繫人' and 是否有效 = 'Y'");
                DataTable dt3 = dbhelper.ExecuteSqlTable("select * from 送審跟催模板 where 流程ID='生成對賬單' and 類型=N'fail'");
                string tip = dt3.Rows[0]["主旨"].ToString().Trim();
                string content = dt3.Rows[0]["郵件頭"].ToString().Trim()+ "異常狀況聯繫人" + dt3.Rows[0]["郵件正文"].ToString().Trim()
                    + "錯誤的年月:" + id + dt3.Rows[0]["郵件結尾"].ToString().Trim();
                string sql = SendMail(consignee, tip, content);
                dbhelper.ExecuteSql(sql);
                DataTable consigneedt = dbhelper.ExecuteSqlTable(@"SELECT DISTINCT
	                                                                    a.[工號],
	                                                                    a.[郵箱],
	                                                                    a.[姓名] 
                                                                    FROM
	                                                                    人員信息表 a
	                                                                    INNER JOIN UinR b ON a.[工號] = b.UserID 
                                                                    WHERE
	                                                                    b.RoleID = N'對賬管理員' 
	                                                                    AND a.[是否有效] = 'Y'");
                foreach (DataRow dr in consigneedt.Rows)
                {
                    content = dt3.Rows[0]["郵件頭"].ToString().Trim() + dr["姓名"].ToString().Trim().Replace("'", "''") + dt3.Rows[0]["郵件正文"].ToString().Trim()
                    + "錯誤的年月:" + id + dt3.Rows[0]["郵件結尾"].ToString().Trim();
                    sql = SendMail(dr["郵箱"].ToString().Trim(), tip, content);
                    dbhelper.ExecuteSql(sql);
                }
                return "系統內部錯誤,生成對賬單失敗!";
            }
        }

        private int GenerateBill(string id,string partBId)
        {
            string sql = "";
            if (id == dbhelper.ExecuteSql("select max(年月) from 關賬信息表 where 是否有效='Y'"))
            {
                sql = @"SELECT [賬單法人代碼],
	[編號],
    對賬窗口賬號
FROM
	使用者賬號信息表 
WHERE
	是否結算 = 'Y' 
	AND 是否免費賬號 = 'N' 
	AND 賬號狀態 IN ( N'已確認', N'提前付費' ) 
	AND 是否生成賬單 = 'N' 
	AND [是否有效] = 'Y' 
	AND 賬單法人代碼!= '' 
	AND 賬單法人名稱!= '' 
	AND [年月] = '" + id + "'";
            }
            else
            {
                sql = @"SELECT [賬單法人代碼],
	[編號],
    對賬窗口賬號
FROM
 使用者賬號未出賬表 
WHERE
 是否結算 = 'Y' 
	AND 是否免費賬號 = 'N' 
	AND 賬號狀態 IN ( N'已確認', N'提前付費' ) 
	AND 是否生成賬單 = 'N' 
	AND [是否有效] = 'Y' 
	AND 賬單法人代碼!= '' 
	AND 賬單法人名稱!= ''
	AND [年月] = '" + id + "'";
            }
            DataTable dt = dbhelper.ExecuteSqlTable(sql);
            DataTable header = dt.DefaultView.ToTable(true, new string[] { "賬單法人代碼", "對賬窗口賬號" });
            foreach (DataRow dr in header.Rows)
            {
                string ameuser = CheckAmeUser(adminUserAccount, adminUserPasswd);
                IService proxy = WcfInvokeFactory.CreateServiceByUrl<IService>(emaliChargeWebserviceUrl);
                string res = proxy.EC生成對賬單接口V6(ameuser, id,  dr["賬單法人代碼"].ToString().Trim(), dr["對賬窗口賬號"].ToString().Trim(),partBId);
                if (res != "")
                {
                    Log.Info("生成对账单webservice异常:"+res);
                    throw new Exception();
                }
            }
            return header.Rows.Count;
        }


        /// <summary>
        /// 判断年月生成结算相应数据
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string UseECCostSettlem(string id)
        {
            List<string> tables = new List<string>(3);
            if (id == dbhelper.ExecuteSql("select max(年月) from 關賬信息表 where 是否有效='Y'"))
            {
                tables.Add("使用者賬號信息表");
            }
            else
            {
                tables.Add("使用者賬號未出賬表");
                tables.Add("使用者賬號上月表");
                tables.Add("使用者賬號歷史表");
            }
            string res = UseECCostSettlem(id, tables);
            return res;
        }

        /// <summary>
        /// 计算费用
        /// </summary>
        public string UseECCostSettlem(string id, List<string> tables)
        {
            List<string> sqlList = new List<string>();
            string sql = "";
            foreach (string table in tables)
            {
                //更新信箱費用为账号收费标准表的单价
                sql = @"UPDATE a 
                    SET a.信箱費用 = b.單價 
                    FROM
	                    [dbo].[" + table + @"] a
	                    INNER JOIN [dbo].[賬號收費標準表] b ON a.項目 = b.項目 
	                    AND a.賬號類型 = b.賬號類型 
                    WHERE
	                    a.[是否有效] = 'Y' 
	                    --AND a.[賬號狀態] != N'新建' 
	                    --AND a.[賬號狀態] != N'已送出' 
	                    AND b.[狀態] = N'已通過' 
	                    AND b.[是否有效] = 'Y' 
	                    AND a.[是否生成賬單] = 'N' 
	                    AND a.年月 = '" + id + @"'";
                sqlList.Add(sql);
                sql = $@"UPDATE a 
                    SET a.歸檔費用 = b.單價 
                    FROM
	                    [dbo].[{table}] a
	                    INNER JOIN 容量收費標準表 b ON a.項目 = b.項目 
	                    AND a.計費配額 = b.容量 
                    WHERE
	                    a.[是否有效] = 'Y' 
	                    --AND a.[賬號狀態] != N'新建' 
	                    --AND a.[賬號狀態] != N'已送出' 
	                    AND b.[狀態] = N'已通過' 
	                    AND b.[是否有效] = 'Y' 
	                    AND a.[是否生成賬單] = 'N' 
	                    AND a.年月 = '{id}' 
	                    AND a.賬號類型 NOT IN ( N'VIPMail賬號', N'PushMail賬號' ) 
	                    AND a.編號 NOT IN (
	                    SELECT
		                    d.編號 
	                    FROM
		                    [{table}] d, 賬號廠區對應表 e 
	                    WHERE
		                    d.項目 = e.項目 
		                    AND (d.事業群 = e.事業群 OR e.事業群='ALL')
		                    AND d.賬號服務器 LIKE REPLACE( e.賬號服務器, '*', '%' ) 
	                    AND d.賬號類型 = N'普通賬號' 
	                    AND e.是否有效 = 'Y'
	                    );";
                sqlList.Add(sql);
                sql = $@"UPDATE a 
                    SET a.費用合計 = a.歸檔費用 + a.信箱費用,
                    a.是否結算 = 'Y',
                    a.[修改時間] = GETDATE() 
                    FROM
	                    {table} a
	                    INNER JOIN 賬號收費標準表 b ON a.賬號類型 = b.賬號類型 
	                    AND a.項目 = b.項目
	                    INNER JOIN 容量收費標準表 c ON a.項目 = c.項目 
	                    AND a.計費配額 = c.容量 
                    WHERE
	                    a.[是否有效] = 'Y' 
	                    AND a.[是否生成賬單] = 'N' 
	                    AND a.[年月] = '{id}' 
	                    --AND a.[賬號狀態] not in( N'新建',N'已送出' )
	                    AND b.[狀態] = N'已通過' 
	                    AND b.[是否有效] = 'Y' 
	                    AND c.[狀態] = N'已通過' 
	                    AND c.[是否有效] = 'Y'";
                sqlList.Add(sql);
                sql = @"UPDATE a 
                    SET a.費用合計 = 0
                    ,a.歸檔費用 = 0
                    ,a.信箱費用 = 0
                    ,a.[修改時間] = GETDATE() 
                    FROM
	                    " + table + @" a 
                    WHERE
	                    a.[是否有效] = 'Y' 
	                    AND a.是否結算 = 'N';";
                sqlList.Add(sql);
            }
            try
            {
                #region 发送对账管理员容量不正确的使用者信息
                DataTable consigneedt = dbhelper.ExecuteSqlTable(@"SELECT DISTINCT
	                                                                    a.[工號],
	                                                                    a.[郵箱],
	                                                                    a.[姓名] 
                                                                    FROM
	                                                                    人員信息表 a
	                                                                    INNER JOIN UinR b ON a.[工號] = b.UserID 
                                                                    WHERE
	                                                                    b.RoleID = N'對賬管理員' 
	                                                                    AND a.[是否有效] = 'Y'");
                string projectID = dbhelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型='ProjectID' and 參數名='ProjectID' and 是否有效 = 'Y'");
                string pagename = "收費標準維護";
                pagename = Convert.ToBase64String(Encoding.Unicode.GetBytes(pagename));
                DataTable dt = dbhelper.ExecuteSqlTable("select * from 送審跟催模板 where 流程ID='ZDJS001' and 類型=N'自動結算'");
                DataTable errorDt = null;
                DataTable errTable2 = null;
                if (id == dbhelper.ExecuteSql("select max(年月) from 關賬信息表 where 是否有效='Y'"))
                {
                    errorDt = dbhelper.ExecuteSqlTable($@"SELECT DISTINCT
	                                                        a.項目,
	                                                        a.計費配額 
                                                        FROM
	                                                        使用者賬號信息表 a
	                                                        LEFT JOIN ( SELECT * FROM 容量收費標準表 WHERE [狀態] = N'已通過' AND [是否有效] = 'Y' ) c ON a.項目 = c.項目 
	                                                        AND a.計費配額 = c.容量 
                                                        WHERE
	                                                        a.[是否有效] = 'Y' 
	                                                        AND a.[年月] = '{id}' 
	                                                        AND a.[是否生成賬單] = 'N' 
	                                                        --AND a.[賬號狀態] != N'新建' 
	                                                        --AND a.[賬號狀態] != N'已送出' 
	                                                        AND c.容量 IS NULL;");
                    errTable2 = dbhelper.ExecuteSqlTable($@"SELECT DISTINCT
	                                                            a.項目,
	                                                            a.賬號類型 
                                                            FROM
	                                                            使用者賬號信息表 a
	                                                            LEFT JOIN ( SELECT * FROM 賬號收費標準表 WHERE [狀態] = N'已通過' AND [是否有效] = 'Y' ) b ON a.賬號類型 = b.賬號類型 
	                                                            AND a.項目 = b.項目 
                                                            WHERE
	                                                            a.[是否有效] = 'Y' 
	                                                            AND a.[年月] = '{id}' 
	                                                            AND a.[是否生成賬單] = 'N' 
	                                                            --AND a.[賬號狀態] != N'新建' 
	                                                            --AND a.[賬號狀態] != N'已送出' 
	                                                            AND b.項目 IS NULL;");
                }
                else
                {
                    errorDt = dbhelper.ExecuteSqlTable($@"SELECT DISTINCT
	                                                        a.項目,
	                                                        a.計費配額 
                                                        FROM
	                                                        使用者賬號未出賬表 a
	                                                        LEFT JOIN ( SELECT * FROM 容量收費標準表 WHERE [狀態] = N'已通過' AND [是否有效] = 'Y' ) c ON a.項目 = c.項目 
	                                                        AND a.計費配額 = c.容量 
                                                        WHERE
	                                                        a.[是否有效] = 'Y' 
	                                                        AND a.[年月] = '{id}' 
	                                                        AND a.[是否生成賬單] = 'N' 
	                                                        --AND a.[賬號狀態] != N'新建' 
	                                                        --AND a.[賬號狀態] != N'已送出' 
	                                                        AND c.容量 IS NULL;");
                    errTable2 = dbhelper.ExecuteSqlTable($@"SELECT DISTINCT
	                                                            a.項目,
	                                                            a.賬號類型 
                                                            FROM
	                                                            使用者賬號未出賬表 a
	                                                            LEFT JOIN ( SELECT * FROM 賬號收費標準表 WHERE [狀態] = N'已通過' AND [是否有效] = 'Y' ) b ON a.賬號類型 = b.賬號類型 
	                                                            AND a.項目 = b.項目 
                                                            WHERE
	                                                            a.[是否有效] = 'Y' 
	                                                            AND a.[年月] = '{id}' 
	                                                            AND a.[是否生成賬單] = 'N' 
	                                                            --AND a.[賬號狀態] != N'新建' 
	                                                            --AND a.[賬號狀態] != N'已送出' 
	                                                            AND b.項目 IS NULL;");
                }
                string msg = "";
                if (errorDt.Rows.Count == 0&&errTable2.Rows.Count==0)
                {
                    msg = "自動結算執行成功!<br><br>";
                    sql = "delete [dbo].[待辦事項表] where 待辦事項=N'窗口確認完成'";
                    sqlList.Add(sql);
                }
                else
                {
                    msg = "自動結算有錯誤出現,原因為以下信息錯誤:<br><br>";
                    foreach (DataRow dr in errorDt.Rows)
                    {
                        msg += "容量收費標準缺失:<br>項目:" + dr["項目"].ToString().Trim() + ",計費配額" + dr["計費配額"].ToString().Trim() + ";<br><br>";
                    }

                    foreach (DataRow dr in errTable2.Rows)
                    {
                        msg += $"賬號收費標準缺失:<br>項目:{dr["項目"].ToString().Trim()},賬號類型:{dr["賬號類型"].ToString().Trim()};<br><br>";
                    }
                }
                foreach (DataRow dr in consigneedt.Rows)
                {
                    string content = msg;
                    if (msg.IndexOf("錯誤", StringComparison.Ordinal) > 0)
                    { 
                        content += "<a href=''http://10.134.96.125:8003/Pages/EmailJump/JumpLogin.aspx?userID=" + dr["工號"].ToString().Trim() + "&ProjectID=" + projectID + "&Pagename=" + pagename + "''>請點擊這裡登錄查看處理</a>  <br><br>";
                    }
                    string consignee = dr["郵箱"].ToString().Trim();
                    string tip = dt.Rows[0]["主旨"].ToString().Trim();
                    content = dt.Rows[0]["郵件正文"].ToString().Trim() + content;
                    content = dt.Rows[0]["郵件頭"].ToString().Trim() + dr["姓名"].ToString().Trim().Replace("'","''") + content + dt.Rows[0]["郵件結尾"].ToString().Trim();
                    sql = SendMail(consignee, tip, content);
                    sqlList.Add(sql);
                }
                #endregion
                dbhelper.ExecSqlList(sqlList);
                return "";
            }
            catch (Exception ex)
            {
                Log.Info(ex.ToString());
                return "结算失败";
            }
        }

        public static string SendMail(string consignee, string tip, string content)
        {
            string sql = @"INSERT INTO [dbo].[郵件發送表] (
	                            [ID],
	                            [發送郵件的IP],
	                            [端口號],
	                            [系統名稱],
	                            [數據庫名稱],
	                            [發件人],
	                            [收件人],
	                            [主題],
	                            [內容],
	                            [建立者],
	                            [建立時間],
	                            [發送狀態],
	                            [錯誤信息],
	                            [是否重發],
	                            [時間間隔],
	                            [發送時間],
	                            [發送次數],
	                            [參考單號],
	                            [預留1],
	                            [預留2],
	                            [預留3] 
                            )
                            VALUES
	                            (
		                            NEWID(),
		                            N'10.134.28.95',
		                            25,
		                            N'郵箱收費對賬系統',
		                            N'Ame_FSC1_EmailCharge',
		                            N'celersystemtest@mail.foxconn.com',
		                            N'" + consignee + "'," +
                        "N'" + tip + "'," +
                        "N'" + content + "'," +
                        @"N'Auto',
                                    getdate(),
	                                N'N',
	                                N'',
	                                N'N',
	                                .00,
	                                getdate(),
	                                0,
	                                N'',
	                                0,
	                                N'',
                                    N''
                                 ); ";
            return sql;
        }
    }
}
