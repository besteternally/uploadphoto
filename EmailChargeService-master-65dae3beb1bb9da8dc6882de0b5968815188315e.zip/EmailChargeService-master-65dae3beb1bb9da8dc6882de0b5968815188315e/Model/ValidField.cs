﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public enum ValidField
    {
        /// <summary>
        /// 事業群;
        /// </summary>
        A,
        /// <summary>
        /// 事業群;事業處;
        /// </summary>
        B,
        /// <summary>
        /// 事業群;廠區;
        /// </summary>
        C,
        /// <summary>
        /// 事業群;法人
        /// </summary>
        D,
        /// <summary>
        /// 事業群;費用代碼
        /// </summary>
        E,
        /// <summary>
        /// 事業群;事業處;廠區
        /// </summary>
        F,
        /// <summary>
        /// 事業群;事業處;法人
        /// </summary>
        G,
        /// <summary>
        /// 事業群;事業處;費用代碼
        /// </summary>
        H,
        /// <summary>
        /// 事業群;廠區;法人
        /// </summary>
        I,
        /// <summary>
        /// 事業群;廠區;費用代碼
        /// </summary>
        J,
        /// <summary>
        /// 事業群;法人;費用代碼
        /// </summary>
        K,
        /// <summary>
        /// 事業群;事業處;廠區;費用代碼
        /// </summary>
        L,
        /// <summary>
        /// 事業群;事業處;法人;費用代碼
        /// </summary>
        M,
        /// <summary>
        /// 事業群;廠區;法人;費用代碼
        /// </summary>
        N,
        /// <summary>
        /// 事業群;事業處;廠區;法人
        /// </summary>
        O,
        /// <summary>
        /// 事業群;事業處;廠區;法人;費用代碼
        /// </summary>
        P
    }
}
