﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class CivetResult<T>
    {
        private string _returnResult;
        private string _message;
        private List<T> _data;

        /// <summary>
        /// 是否成功
        /// </summary>
        public string return_result
        {
            get
            {
                return _returnResult;
            }

            set
            {
                _returnResult = value;
            }
        }

        /// <summary>
        /// 错误信息
        /// </summary>
        public string message
        {
            get
            {
                return _message;
            }

            set
            {
                _message = value;
            }
        }

        /// <summary>
        /// 接口返回内容
        /// </summary>
        public List<T> data
        {
            get
            {
                return _data;
            }

            set
            {
                _data = value;
            }
        }
    }
}
