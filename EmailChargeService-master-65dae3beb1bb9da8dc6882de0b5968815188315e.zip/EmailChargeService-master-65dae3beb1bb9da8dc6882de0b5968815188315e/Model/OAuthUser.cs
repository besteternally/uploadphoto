﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class OAuthUser
    {
        public OAuthUser()
        { }
        private string _openid;
        private string _access_token;
        private string _expires_in;
        private string _civetno;
        private string _nickname;
        private string _area;
        private string _sign;

        /// <summary>
        /// 用户的唯一标识
        /// </summary>
        public string openid
        {
            set { _openid = value; }
            get { return _openid; }
        }
        /// <summary>
        /// 访问Token
        /// </summary>
        public string access_token
        {
            set { _access_token = value; }
            get { return _access_token; }
        }
        /// <summary>
        /// 3600 
        /// </summary>
        public string expires_in
        {
            set { _expires_in = value; }
            get { return _expires_in; }
        }
        /// <summary>
        /// 用户的工号 
        /// </summary>
        public string civetno
        {
            set { _civetno = value; }
            get { return _civetno; }
        }
        /// <summary>
        /// 用户姓名
        /// </summary>
        public string nickname
        {
            set { _nickname = value; }
            get { return _nickname; }
        }
        /// <summary>
        /// 用户所在地区 
        /// </summary>
        public string area
        {
            set { _area = value; }
            get { return _area; }
        }
        /// <summary>
        /// 签名信息
        /// </summary>
        public string sign
        {
            set { _sign = value; }
            get { return _sign; }
        }
    }
}
