﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Util
{
    public static class CommonUse
    {
        /// <summary>
        /// 用戶信息加密
        /// </summary>
        static uint AmeKey = 231;
        private static string AmeEncode(string str)
        {
            if (string.IsNullOrEmpty(str)) return "";
            char[] f = str.ToCharArray();
            int len = f.Length;
            for (int i = 0; i < len; i++)
            {
                f[i] = (char)((uint)f[i] ^ AmeKey);
            }
            return new string(f);
        }

        /// <summary>
        /// 獲得Ame用戶驗證字符串
        /// </summary>
        /// <param name="UserName">帳號</param>
        /// <param name="Password">密碼</param>
        /// <returns></returns>
        public static string CheckAmeUser(string UserName, string Password)
        {
            //string AmeUser = "Powerplant" + "," + UserName + "@|@" + Password + "," + "Powerplant";
            string AmeUser = "JeffCelERP" + "," + UserName + "@|@" + Password + "," + "JeffCelERP";
            AmeUser = AmeEncode(AmeUser);
            return AmeUser;
        }
    }
}
