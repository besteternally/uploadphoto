﻿using EmailChargeService.App_Start;
using FluentScheduler;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;

namespace EmailChargeService
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            AreaRegistration.RegisterAllAreas();

            //log
            log4net.Config.XmlConfigurator.Configure();

            //web api异常过滤器
            GlobalConfiguration.Configuration.Filters.Add(new WebApiExceptionFilterAttribute());
            ModifyInMemory.ActivateMemoryPatching();
        }
    }
}
