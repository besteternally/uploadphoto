﻿using Dal;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Bll
{
    public class TestCopyPDFBll
    {
        private log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private static readonly string ftpFileUrl = ConfigurationManager.AppSettings["ftpFileUrl"].ToString();
        private DbHelper dbhelper = new DbHelper();

        public string DoMain()
        {
            DataTable dataTable = GetOrderNo();
            foreach(DataRow dr in dataTable.Rows)
            {
                int num = (new Random()).Next(1, 5);
                for(int i=1;i<= num; i++)
                {
                    string sql = @"insert into 收費對賬費支單表 (	[來源訂單編號],
	[序號],
	[費支單名稱],
	[費支單],
	[案號],
	[費用代碼],
	[含稅金額],
	[未稅金額],
	[乙方稅率],
	[乙方幣別],
	[是否有效],
	[建立者],
	[建立時間],
	[修改者],
	[修改時間],
	[預留1],
	[預留2],
	[預留3],
	[預留4],
	[預留5],
	[預留6],
	[預留7],
	[預留8],
	[預留9],
	[預留10] 
) SELECT
a.訂單編號,
" + i + @",
		N'" + i + @"',
        N'" + i+ @".pdf',
		a.訂單編號+N'"+i+ @"',
		N'123',
		1.00,
		.00,
		.0600,
		N'RMB',
		N'Y',
		N'Auto',
		'2019-07-05 11:30:19.523',
		N'J001',
		'2019-07-05 11:30:19.523',
		N'',
		N'',
		N'',
		N'',
		N'',
		0,
		0,
		.00,
		.00,
		'1900-01-01 00:00:00.000' 
FROM
	郵箱費用明細表頭 a
where a.訂單編號='" + dr["訂單編號"].ToString().Trim()+"';";
                    dbhelper.Execute(sql);
                    File.Copy(ftpFileUrl+ "DD19071200001.pdf", ftpFileUrl+ dr["訂單編號"].ToString().Trim()+"@^@"+i.ToString()+".pdf");
                }
            }
            return ""; 
        }


        private DataTable GetOrderNo() =>
            dbhelper.ExecuteSqlTable("select 訂單編號,年月 from 郵箱費用明細表頭 where 付款方式=N'開票' and 單據狀態!=N'已上傳費支單' and 是否有效='Y' and 是否已生成PDF='N'");

    }
}
