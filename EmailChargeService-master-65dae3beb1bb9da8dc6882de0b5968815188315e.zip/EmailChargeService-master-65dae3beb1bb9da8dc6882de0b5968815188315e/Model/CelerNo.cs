﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class CelerNo
    {
        private System.String _单据类别;
        /// <summary>
        /// 
        /// </summary>
        public System.String 单据类别 { get { return this._单据类别; } set { this._单据类别 = value; } }

        private System.String _单据名称;
        /// <summary>
        /// 
        /// </summary>
        public System.String 单据名称 { get { return this._单据名称; } set { this._单据名称 = value; } }

        private System.String _单据前缀;
        /// <summary>
        /// 
        /// </summary>
        public System.String 单据前缀 { get { return this._单据前缀; } set { this._单据前缀 = value; } }

        private System.String _单据日期中缀;
        /// <summary>
        /// 
        /// </summary>
        public System.String 单据日期中缀 { get { return this._单据日期中缀; } set { this._单据日期中缀 = value; } }

        private System.Int32 _单据总长度;
        /// <summary>
        /// 
        /// </summary>
        public System.Int32 单据总长度 { get { return this._单据总长度; } set { this._单据总长度 = value; } }

        private System.String _目前中缀号码;
        /// <summary>
        /// 
        /// </summary>
        public System.String 目前中缀号码 { get { return this._目前中缀号码; } set { this._目前中缀号码 = value; } }

        private System.String _目前号码;
        /// <summary>
        /// 
        /// </summary>
        public System.String 目前号码 { get { return this._目前号码; } set { this._目前号码 = value; } }

    }
}
