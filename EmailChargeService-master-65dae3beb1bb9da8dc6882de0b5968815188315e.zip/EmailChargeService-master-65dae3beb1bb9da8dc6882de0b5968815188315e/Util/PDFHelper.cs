﻿using NPOI.HSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text;
using iTextSharp.text.pdf;
using static Util.Compress;
using Excel = Microsoft.Office.Interop.Excel;
using PdfDocument = Spire.Pdf.PdfDocument;
using Dal;

namespace Util
{
    public static class PDFHelper
    {
        private static log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// 读取对接单和费支单PDF路径
        /// </summary>
        /// <param name="reportDirectorypath">报表生成PDF路径</param>
        /// <param name="ftpDirectorypath">FTP上传文件路径</param>
        /// <param name="orderNo">订单号</param>
        /// <param name="outpath">输出路径</param>
        /// <param name="fileMap">费支单名称与单号</param>
        /// <param name="mergrFileUrlDate">每天发送给财务的文件地址</param>
        /// <param name="largeFzdList">错误的费支单案号</param>
        /// <param name="orderList">所有的订单号</param>
        public static void MergePdf(string reportDirectorypath, string ftpDirectorypath, string orderNo, string tempPath,string outpath, Dictionary<string, string> fileMap, string mergrFileUrlDate, List<string> largeFzdList, List<string> orderList)
        {
            //List<string> noList = new List<string>();
            if (!Directory.Exists(outpath))//如果路径不存在
            {
                Directory.CreateDirectory(outpath);//创建一个路径的文件夹
            }
            if (!Directory.Exists(tempPath))//如果路径不存在
            {
                Directory.CreateDirectory(tempPath);//创建一个路径的文件夹
            }
            if (!Directory.Exists(mergrFileUrlDate))
            {
                Directory.CreateDirectory(mergrFileUrlDate);
            }
            List<string> reportFilelist = GetFileList(reportDirectorypath, orderNo);
            if (reportFilelist.Count <= 0)
            {
                return;
            }
            GetFileList(ftpDirectorypath, reportFilelist, orderNo, tempPath, outpath, fileMap, mergrFileUrlDate, largeFzdList, orderList);
            //CreateZip(outpath, ftpDirectorypath + orderNo + "@^@對賬單費支單合成檔.zip", fileMap);
        }

        /// <summary>
        /// 读取转嫁单PDF路径
        /// </summary>
        /// <param name="reportDirectorypath"></param>
        /// <param name="dateNo"></param>
        /// <param name="outpath"></param>
        /// <param name="mergrFileUrlDate">每天发送给财务的文件地址</param>
        public static void MergePDF(string reportDirectorypath, string dateNo, string outpath)
        {
            if (!Directory.Exists(outpath))//如果路径不存在
            {
                Directory.CreateDirectory(outpath);//创建一个路径的文件夹
            }
            List<string> reportFilelist = GetFileList(reportDirectorypath, dateNo);
            if (reportFilelist.Count <= 0)
            {
                return;
            }
            mergePDFFiles(reportFilelist, outpath + dateNo + "ZJD.pdf");
        }

        /// <summary>
        /// 获取目录下文件
        /// </summary>
        /// <param name="directoryPath">目标文件夹</param>
        /// <param name="orderNo">文件名前缀</param>
        /// <returns></returns>
        private static List<string> GetFileList(string directoryPath, string orderNo)
        {
            List<string> filelist = new List<string>();
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(directoryPath);
            FileInfo[] reportFiles = null;
            reportFiles = di.GetFiles(orderNo + "*.pdf");

            foreach (FileInfo temp in reportFiles)
            {
                filelist.Add(temp.FullName);

            }
            return filelist;
        }

        /// <summary>
        /// 合成费支单-对账单
        /// </summary>
        /// <param name="directoryPath">费支单目录</param>
        /// <param name="reportFilelist">对账单文件路径列表</param>
        /// <param name="orderNo">对账单单号</param>
        /// <param name="outpath">输出文件路径</param>
        /// <param name="fileMap">费支单名称与单号</param>
        /// <param name="mergrFileUrlDate">每天发送给财务的文件地址</param>
        /// <param name="largeList"></param>
        /// <param name="orderList">所有的订单号</param>
        /// <returns></returns>
        private static void GetFileList(string directoryPath, List<string> reportFilelist, string orderNo,string tempPath, string outpath, Dictionary<string, string> fileMap, string mergrFileUrlDate, List<string> largeList, List<string> orderList)
        {
            //出现错误的费支单集合
            Dictionary<string, FileInfo> errorFtpFileDictionary = new Dictionary<string, FileInfo>();
            DirectoryInfo di = new DirectoryInfo(directoryPath);
            FileInfo[] reportFiles = null;
            reportFiles = di.GetFiles(orderNo + "*.pdf");
            if (fileMap == null)
            {
                return;
            }
            foreach (FileInfo temp in reportFiles)
            {
                try
                {
                    if (fileMap.Keys.Contains(temp.Name) && !errorFtpFileDictionary.Values.Contains(temp))
                    {
                        bool fileExists = File.Exists(tempPath + fileMap[temp.Name] + ".pdf");
                        string ftpFile = temp.FullName;
                        if (fileExists)
                        {
                            ftpFile = tempPath + fileMap[temp.Name] + ".pdf";
                            mergePDFFiles(ftpFile, reportFilelist[0],
                                tempPath + fileMap[temp.Name] + "temp.pdf");
                            File.Copy(tempPath + fileMap[temp.Name] + "temp.pdf", tempPath + fileMap[temp.Name] + ".pdf",
                                true);
                            File.Copy(tempPath + fileMap[temp.Name] + "temp.pdf", outpath + fileMap[temp.Name] + ".pdf",
                                true);
                            File.Delete(tempPath + fileMap[temp.Name] + "temp.pdf");
                        }
                        else
                        {
                            mergePDFFiles(ftpFile, reportFilelist[0], tempPath + fileMap[temp.Name] + ".pdf");
                            File.Copy(tempPath + fileMap[temp.Name] + ".pdf", outpath + fileMap[temp.Name] + ".pdf",
                                true);
                        }

                        //另保存一份文件到按每天yyyyMMdd命名的文件夹,以方便发给财务下载
                        File.Copy(outpath + fileMap[temp.Name] + ".pdf", mergrFileUrlDate + fileMap[temp.Name] + ".pdf",
                            true);
                    }
                }
                //超过10页时,记录错误pdf
                catch (PdfLargeError)
                {
                    errorFtpFileDictionary.Add(fileMap[temp.Name], temp);
                    largeList.Add(fileMap[temp.Name]);
                    if (File.Exists(mergrFileUrlDate + fileMap[temp.Name] + ".pdf"))
                    {
                        File.Delete(mergrFileUrlDate + fileMap[temp.Name] + ".pdf");
                    }

                    if (File.Exists(tempPath + fileMap[temp.Name] + ".pdf"))
                    {
                        File.Delete(tempPath + fileMap[temp.Name] + ".pdf");
                    }
                    if (File.Exists(outpath + fileMap[temp.Name] + ".pdf"))
                    {
                        File.Delete(outpath + fileMap[temp.Name] + ".pdf");
                    }
                }
            }
            LargeFileSendToAdmin(errorFtpFileDictionary, orderList);
        }

        /// <summary>
        /// 超过10页的费支单与对账单处理
        /// </summary>
        /// <param name="errorFtpFileDictionary"></param>
        private static void LargeFileSendToAdmin(Dictionary<string, FileInfo> errorFtpFileDictionary, List<string> orderList)
        {
            DbHelper dbHelper = new DbHelper();
            string mergrFzdUrlDate = System.Threading.Thread.GetDomain().BaseDirectory + "/DownLoad/Reconcilia/" + DateTime.Now.ToString("yyyyMMdd") + "/";
            foreach (var temp in errorFtpFileDictionary)
            {
                if (!Directory.Exists(mergrFzdUrlDate + temp.Key))
                {
                    Directory.CreateDirectory(mergrFzdUrlDate + temp.Key);
                }

                DataTable dt = dbHelper.ExecuteSqlTable($"SELECT 來源訂單編號 FROM [dbo].[收費對賬費支單表] where 案號='{temp.Key}'");
                File.Copy(temp.Value.FullName, mergrFzdUrlDate + temp.Key + "/" + temp.Key + ".pdf", true);
                foreach (DataRow dr in dt.Rows)
                {
                    if (orderList.Contains(dr["來源訂單編號"].ToString().Trim()))
                    {
                        string uri = dbHelper.ExecuteSql("select 說明 from 基本參數表 where 參數類型 = '報表' and 參數名 = 'EC對賬單記錄查詢開票'").Split('&')[0] + "&NO=" + dr["來源訂單編號"].ToString().Trim() +
                                     "&rs:Format=PDF&rs:Command=Render";
                        DownloadFile.DownLoadFileByUrl(uri, dr["來源訂單編號"].ToString().Trim(), mergrFzdUrlDate + temp.Key+"/");
                    }
                }
            }
        }

        /// <summary>
        /// 合成对账单+费支单
        /// </summary>
        /// <param name="ftpFile">费支单</param>
        /// <param name="reportFile">对账单</param>
        /// <param name="outMergeFile">目标PDF</param>
        public static void mergePDFFiles(string ftpFile, string reportFile, string outMergeFile)
        {
            int num = (new PdfReader(ftpFile)).NumberOfPages + (new PdfReader(reportFile)).NumberOfPages;
            if (num > 10)
            {
                throw new PdfLargeError();
            }
            try
            {
                PdfDocument pdfDocument = new PdfDocument(ftpFile);
                PdfDocument pdfDocument2 = new PdfDocument(reportFile);
                pdfDocument.AppendPage(pdfDocument2);
                pdfDocument.SaveToFile(outMergeFile);
            }
            catch (Exception ex)
            {
                Log.Error(ex.ToString());
                Log.Error("源文件"+reportFile);
                Log.Error("保存路径"+outMergeFile);
                throw ex;
            }
        }
        /// <summary>
        /// 合成pdf文件
        /// </summary>
        /// <param name="fileList">文件名list</param>
        /// <param name="outMergeFile">输出路径</param>
        public static void mergePDFFiles(List<string> reportFilelist, string outMergeFile)
        {
            PdfReader reader;
            Document document = new Document(PageSize.A4.Rotate());
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(outMergeFile, FileMode.Append));
            document.Open();
            PdfContentByte cb = writer.DirectContent;
            PdfImportedPage newPage;
            foreach (var reportFile in reportFilelist)
            {
                reader = new PdfReader(reportFile);
                int iPageNum = reader.NumberOfPages;
                for (int j = 1; j <= iPageNum; j++)
                {
                    document.NewPage();
                    newPage = writer.GetImportedPage(reader, j);
                    cb.AddTemplate(newPage, 0, 0);
                }
            }
            document.Close();
        }


        public static void MergeExcle(string reportDirectorypath, string dateNo, string outpath)
        {
            if (!Directory.Exists(outpath))//如果路径不存在
            {
                Directory.CreateDirectory(outpath);//创建一个路径的文件夹
            }
            HSSFWorkbook product = new HSSFWorkbook();
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(reportDirectorypath);
            FileInfo[] reportFiles = null;
            reportFiles = di.GetFiles(dateNo + "*.xls");
            foreach (FileInfo temp in reportFiles)
            {
                byte[] byteArray = File.ReadAllBytes(temp.FullName);
                using (MemoryStream stream = new MemoryStream())
                {
                    stream.Write(byteArray, 0, (int)byteArray.Length);
                    HSSFWorkbook book = new HSSFWorkbook(stream);
                    for (int i = 0; i < book.NumberOfSheets; i++)
                    {
                        HSSFSheet sheet = book.GetSheetAt(i) as HSSFSheet;
                        //avoid sheet has same name
                        sheet.CopyTo(product, temp.Name.Substring(0, temp.Name.LastIndexOf('.') - 1), true, true);
                    }
                    book.Close();
                    stream.Close();
                }
            }
            using (FileStream fs = new FileStream(outpath + dateNo + "ZJD.xls", FileMode.Create, FileAccess.Write))
            {
                product.Write(fs);
            }
        }

        public static void MergeExcle(List<string> reportFileList, string outpath)
        {
            HSSFWorkbook product = new HSSFWorkbook();
            foreach (string reportPath in reportFileList)
            {
                byte[] byteArray = File.ReadAllBytes(reportPath);
                using (MemoryStream stream = new MemoryStream())
                {
                    stream.Write(byteArray, 0, (int)byteArray.Length);
                    HSSFWorkbook book = new HSSFWorkbook(stream);
                    for (int i = 0; i < book.NumberOfSheets; i++)
                    {
                        HSSFSheet sheet = book.GetSheetAt(i) as HSSFSheet;
                        //avoid sheet has same name
                        sheet.CopyTo(product, Path.GetFileNameWithoutExtension(reportPath), true, true);
                    }
                    book.Close();
                    stream.Close();
                }
            }
            using (FileStream fs = new FileStream(outpath, FileMode.Create, FileAccess.Write))
            {
                product.Write(fs);
            }
        }

        private static List<string> w22(string directoryPath, string orderNo)
        {
            List<string> filelist = new List<string>();
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(directoryPath);
            FileInfo[] reportFiles = null;
            reportFiles = di.GetFiles(orderNo + "*.pdf");

            foreach (FileInfo temp in reportFiles)
            {
                filelist.Add(temp.FullName);

            }
            return filelist;
        }

    }
}
