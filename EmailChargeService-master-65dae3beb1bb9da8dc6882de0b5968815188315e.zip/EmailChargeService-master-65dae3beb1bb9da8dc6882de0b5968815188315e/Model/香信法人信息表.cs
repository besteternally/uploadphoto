﻿using SqlSugar;

namespace Model
{
    /// <summary>
    /// 
    /// </summary>
    public class 香信法人信息表
    {
        /// <summary>
        /// 
        /// </summary>
        public 香信法人信息表()
        {
        }

        private System.String _法人;
        /// <summary>
        /// 
        /// </summary>
        public System.String 法人 { get { return this._法人; } set { this._法人 = value; } }
    }
}
