﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Bll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bll.Tests
{
    [TestClass()]
    public class EmailUserInfoBllTests
    {
        [TestMethod()]
        public void UpdateReconciliationUserTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void testRole()
        {
            EmailUserInfoBll emailUserInfoBll = new EmailUserInfoBll();
            emailUserInfoBll.UpdateReconciliationUser();
        }
    }
}