﻿using Dal;
using Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Bll
{
    public class EmailUserInfoBll
    {
        private readonly log4net.ILog _log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private MsSqlDbContext<Object> db = new MsSqlDbContext<object>();
        /// <summary>
        /// 通过香信更新使用者信息
        /// </summary>
        /// <returns></returns>
        public string UpdateEmailUserInfo()
        {
            string res = "";
            try
            {
                UpdateEmailUserInfoNow();
                UpdateBGInfo();
                UpdateCorporationInfo();
                RuleBll.Instance.UpdateRule();
                UpdateRule();
                FindRepeatData();
            }
            catch (Exception ex)
            {
                res = ex.ToString();
            }
            return res;
        }


        /// <summary>
        /// 修改使用者賬號信息表
        /// </summary>
        /// <returns></returns>
        public void UpdateEmailUserInfoNow()
        {
            MsSqlDbContext<使用者賬號信息表> Db = new MsSqlDbContext<使用者賬號信息表>();
            UserDal userDal = new UserDal();
            List<使用者賬號信息表> userInfoList = Db.Db.Ado.SqlQuery<使用者賬號信息表>("select * from 使用者賬號信息表 where 賬號狀態=N'新建' and 工號!='' and 是否台幹!=N'海外賬號' and 香信對接!=N'X'").ToList();
            List<使用者賬號信息表> updateUserList = new List<使用者賬號信息表>();
            foreach (使用者賬號信息表 userInfo in userInfoList)
            {
                CivetResult<CivetUser> userResult = GetUserFromICivet.getUserByEmpNo(userInfo.工號);
                if (userResult == null || userResult.return_result != "Success" || userResult.data == null)
                {
                    continue;
                }
                CivetUser user = new CivetUser();
                if (userResult.data.Count > 0)
                {
                    user = userResult.data[0];
                    //userInfo.姓名 = user.FN;
                    if (!string.IsNullOrWhiteSpace(user.BG))
                    {
                        userInfo.事業群 = user.BG.Replace("\n", "").Replace("\t", "").Replace("\r", "").Trim();
                    }
                    if (!string.IsNullOrWhiteSpace(user.BU))
                        userInfo.事業處 = user.BU.Replace("\n", "").Replace("\t", "").Replace("\r", "").Trim();
                    if (!string.IsNullOrWhiteSpace(user.ORGNAME))
                        userInfo.付費法人 = user.ORGNAME.Replace("\n", "").Replace("\t", "").Replace("\r", "").Trim();
                    if (!string.IsNullOrWhiteSpace(user.COST_CODE))
                        userInfo.費用代碼 = user.COST_CODE.Replace("\n", "").Replace("\t", "").Replace("\r", "").Trim();
                    userInfo.香信對接 = "Y";
                    userInfo.修改時間 = DateTime.Now;
                    userInfo.修改者 = "ICivetAuto";
                    updateUserList.Add(userInfo);
                }
            }
            userDal.UpdateUser(updateUserList);
            //更新法人信息为全称
            List<string> sqlList = new List<string>();
            string sql = "";
            sql = @"UPDATE a 
SET a.付費法人 = b.法人全稱,a.原付費法人=b.法人簡稱
FROM
    使用者賬號信息表 a
    INNER JOIN 法人全稱表 b ON a.[付費法人] = b.法人簡稱
WHERE
    a.[是否有效] = 'Y'
    AND b.[是否有效] = 'Y'";
            sqlList.Add(sql);
            sql = @"UPDATE a 
SET a.付費法人 =N'未知法人' ,賬號說明=N'賬號無對應人事信息'
FROM
	使用者賬號信息表 a
WHERE
	a.[是否有效] = 'Y' 
	and a.付費法人=''";
            sqlList.Add(sql);
            //更新事业群信息
            sql = @"UPDATE a 
SET a.事業群 = b.新事業群 ,a.原事業群=b.原事業群
FROM
	使用者賬號信息表 a,事業群替換表 b 
WHERE
	a.事業群 = b.原事業群 
	AND b.是否有效 = 'Y'";
            sqlList.Add(sql);
            //更新是否台干
            sql = @"UPDATE a 
SET a.[是否台幹]='鴻海賬號'
FROM
	使用者賬號信息表 a 
WHERE a.付費法人='鴻海精密工業股份有限公司'
and a.[是否台幹]!='海外賬號'
and a.是否台幹=''
and a.事業群 not in (N'G次集團',N'CESBG')";
            sqlList.Add(sql);
            sql = @"UPDATE a 
SET a.[是否台幹]=N'非鴻海賬號'
FROM
	使用者賬號信息表 a 
WHERE a.是否台幹=''
and a.[是否台幹]!='海外賬號'";
            sqlList.Add(sql);
            Db.ExecuteSqlTran(sqlList);
        }

        #region
        /// <summary>
        /// 修改使用者賬號上月表
        /// </summary>
        /// <returns></returns>
        //public void UpdateEmailUserInfoLast()
        //{
        //    MsSqlDbContext<使用者賬號上月表> Db = new MsSqlDbContext<使用者賬號上月表>();
        //    List<使用者賬號上月表> userInfoList = Db.Db.Ado.SqlQuery<使用者賬號上月表>("select * from 使用者賬號上月表 where 香信對接=N'N' and 工號!=''").ToList();
        //    List<使用者賬號上月表> updateUserList = new List<使用者賬號上月表>();
        //    foreach (使用者賬號上月表 userInfo in userInfoList)
        //    {
        //        CivetResult<CivetUser> userResult = GetUserFromICivet.getUserByEmpNo(userInfo.工號);
        //        if (userResult == null || userResult.return_result != "Success" || userResult.data == null)
        //        {
        //            continue;
        //        }
        //        CivetUser user = new CivetUser();
        //        if (userResult.data.Count > 0)
        //        {
        //            user = userResult.data[0];
        //            //userInfo.姓名 = user.FN;
        //            userInfo.事業群 = user.BG;
        //            userInfo.事業處 = user.BU;
        //            userInfo.付費法人 = user.ORGNAME;
        //            userInfo.費用代碼 = user.COST_CODE;
        //            userInfo.香信對接 = "Y";
        //            if ("TW".Equals(user.COUNTRY))
        //            {
        //                userInfo.是否台幹 = "台幹";
        //            }
        //            else
        //            {
        //                userInfo.是否台幹 = "非台幹";
        //            }
        //            updateUserList.Add(userInfo);
        //        }
        //    }
        //    Db.UpdateUser(updateUserList);
        //}

        /// <summary>
        /// 修改使用者賬號歷史表
        /// </summary>
        /// <returns></returns>
        //public void UpdateEmailUserInfoTheLast()
        //{
        //    MsSqlDbContext<使用者賬號歷史表> Db = new MsSqlDbContext<使用者賬號歷史表>();
        //    List<使用者賬號歷史表> userInfoList = Db.Db.Ado.SqlQuery<使用者賬號歷史表>("select * from 使用者賬號歷史表 where 香信對接=N'N' and 工號!=''").ToList();
        //    List<使用者賬號歷史表> updateUserList = new List<使用者賬號歷史表>();
        //    foreach (使用者賬號歷史表 userInfo in userInfoList)
        //    {
        //        CivetResult<CivetUser> userResult = GetUserFromICivet.getUserByEmpNo(userInfo.工號);
        //        if (userResult == null || userResult.return_result != "Success" || userResult.data == null)
        //        {
        //            continue;
        //        }
        //        CivetUser user = new CivetUser();
        //        if (userResult.data.Count > 0)
        //        {
        //            user = userResult.data[0];
        //            //userInfo.姓名 = user.FN;
        //            userInfo.事業群 = user.BG;
        //            userInfo.事業處 = user.BU;
        //            userInfo.付費法人 = user.ORGNAME;
        //            userInfo.費用代碼 = user.COST_CODE;
        //            if ("TW".Equals(user.COUNTRY))
        //            {
        //                userInfo.是否台幹 = "台幹";
        //            }
        //            else
        //            {
        //                userInfo.是否台幹 = "非台幹";
        //            }
        //            userInfo.香信對接 = "Y";
        //            updateUserList.Add(userInfo);
        //        }
        //    }
        //    Db.UpdateUser(updateUserList);
        //}

        /// <summary>
        /// 修改使用者賬號未出賬表
        /// </summary>
        /// <returns></returns>
        //public void UpdateEmailUserInfoTheChargeOff()
        //{
        //    MsSqlDbContext<使用者賬號未出賬表> Db = new MsSqlDbContext<使用者賬號未出賬表>();
        //    List<使用者賬號未出賬表> userInfoList = Db.Db.Ado.SqlQuery<使用者賬號未出賬表>("select * from 使用者賬號未出賬表 where 香信對接=N'N' and 工號!=''").ToList();
        //    List<使用者賬號未出賬表> updateUserList = new List<使用者賬號未出賬表>();
        //    foreach (使用者賬號未出賬表 userInfo in userInfoList)
        //    {
        //        CivetResult<CivetUser> userResult = GetUserFromICivet.getUserByEmpNo(userInfo.工號);
        //        if (userResult == null || userResult.return_result != "Success" || userResult.data == null)
        //        {
        //            continue;
        //        }
        //        CivetUser user = new CivetUser();
        //        if (userResult.data.Count > 0)
        //        {
        //            user = userResult.data[0];
        //            //userInfo.姓名 = user.FN;
        //            userInfo.事業群 = user.BG;
        //            userInfo.事業處 = user.BU;
        //            userInfo.付費法人 = user.ORGNAME;
        //            userInfo.費用代碼 = user.COST_CODE;
        //            if ("TW".Equals(user.COUNTRY))
        //            {
        //                userInfo.是否台幹 = "台幹";
        //            }
        //            else
        //            {
        //                userInfo.是否台幹 = "非台幹";
        //            }
        //            userInfo.香信對接 = "Y";
        //            updateUserList.Add(userInfo);
        //        }
        //    }
        //    Db.UpdateUser(updateUserList);
        //}
        #endregion

        /// <summary>
        /// 更新香信事業群信息表
        /// </summary>
        public void UpdateBGInfo()
        {
            MsSqlDbContext<香信事業群信息表> Db = new MsSqlDbContext<香信事業群信息表>();
            Db.Db.Ado.SqlQuery<香信事業群信息表>("DELETE FROM 香信事業群信息表");
            Db.Db.Ado.SqlQuery<香信事業群信息表>(@"INSERT INTO 香信事業群信息表 SELECT DISTINCT
事業群
FROM
    (SELECT DISTINCT 事業群 FROM 使用者賬號信息表 UNION SELECT DISTINCT 事業群 FROM 使用者賬號上月表 UNION SELECT DISTINCT 事業群 FROM 使用者賬號歷史表) a
WHERE
    a.[事業群] != ''");
        }

        /// <summary>
        /// 更新香信法人信息表
        /// </summary>
        public void UpdateCorporationInfo()
        {
            MsSqlDbContext<香信法人信息表> Db = new MsSqlDbContext<香信法人信息表>();
            Db.Db.Ado.SqlQuery<香信法人信息表>("DELETE FROM 香信法人信息表");
            Db.Db.Ado.SqlQuery<香信法人信息表>(@"INSERT INTO 香信法人信息表 SELECT DISTINCT
付費法人 
FROM
	( SELECT DISTINCT 付費法人 FROM 使用者賬號信息表 UNION SELECT DISTINCT 付費法人 FROM 使用者賬號上月表 UNION SELECT DISTINCT 付費法人 FROM 使用者賬號歷史表 ) a 
WHERE
	a.[付費法人] != ''");
        }

        /// <summary>
        /// 香信法人信息暫存表
        /// </summary>
        public void UpdateCorporationTempInfo()
        {
            MsSqlDbContext<香信法人信息暫存表> Db = new MsSqlDbContext<香信法人信息暫存表>();
            Db.Db.Ado.SqlQuery<香信法人信息暫存表>("DELETE FROM 香信法人信息暫存表");
            Db.Db.Ado.SqlQuery<香信法人信息暫存表>(@"INSERT INTO [dbo].[香信法人信息暫存表] ( [工號], [法人], [是否台幹], [預留1], [預留2], [預留3], [預留4], [預留5] )
select 工號,付費法人,是否台幹,'','','',0,0 from 使用者賬號信息表");
        }

        /// <summary>
        /// 更新对账窗口
        /// </summary>
        public void UpdateReconciliationUser()
        {
            MsSqlDbContext<Object> db = new MsSqlDbContext<object>();
            List<string> sqlList = new List<string>();
            string sql = "";
            sql = @"UPDATE 使用者賬號信息表 
SET 對賬窗口賬號 = '', 對賬窗口姓名 = '',
賬單法人代碼 = '',
賬單法人名稱 = '',
對賬窗口聯繫方式 = '',
對賬窗口郵箱地址 = '', 修改者 = 'ICivetAuto',
修改時間 = getdate() 
FROM
	使用者賬號信息表 
WHERE
	是否有效 = 'Y' 
	AND 賬號狀態 IN ( '新建', '停用', '停用待接收', '已移除', '已送出' ) 
	AND 是否生成賬單 = 'N'; ";
            sqlList.Add(sql);
            List<RoleModel> roleList = db.Db.Ado.SqlQuery<RoleModel>("select 參數名,說明 from 基本參數表 where 是否有效='Y' and 參數類型 =N'標識代碼' order by 參數名 asc").ToList();
            foreach (var roles in roleList)
            {
                string onsql = "";
                if (roles.參數名 == null || roles.參數名[0] > 90 || roles.參數名[0] < 65)
                {
                    continue;
                }
                string[] roleArray = roles.說明.Split(';');
                foreach (string role in roleArray)
                {
                    if (!string.IsNullOrWhiteSpace(role))
                    {
                        onsql += " and a." + role.Replace("法人", "付費法人") + "=b." + role;
                    }
                }
                onsql = onsql.Substring(5);
                sql = @"UPDATE a 
SET a.對賬窗口賬號 = b.對賬窗口賬號,對賬窗口姓名 = b.對賬窗口姓名,
a.賬單法人代碼 = b.賬單法人代碼,
a.賬單法人名稱 = b.賬單法人名稱,
a.修改者='ICivetAuto',
a.修改時間=getdate()
FROM
    使用者賬號信息表 a
    INNER JOIN 生成賬單規則表 b
    ON " + onsql + @"
WHERE
    b.有效欄位 = '" + roles.參數名 + @"'
    AND a.是否有效 = 'Y'
    AND b.是否有效 = 'Y'
	AND b.對賬窗口賬號 != '' 
	AND b.賬單法人代碼 != ''
	AND a.賬號狀態 IN ( '新建', '停用', '停用待接收', '已移除', '已送出' ) 
	AND a.是否生成賬單 = 'N';";
                sqlList.Add(sql);
                _log.Debug(sql);
            }
            sql = @"UPDATE a 
SET a.對賬窗口聯繫方式 = b.分機號碼,
a.對賬窗口郵箱地址 = b.郵箱
FROM
    使用者賬號信息表 a
    INNER JOIN 人員信息表 b ON a.對賬窗口賬號 = b.工號
WHERE
    a.是否有效 = 'Y'
    AND b.是否有效 = 'Y'
	AND a.對賬窗口賬號 != '' 
	AND a.賬單法人代碼 != ''
	AND a.賬號狀態 IN ( '新建', '停用', '停用待接收', '已移除', '已送出' ) 
	AND a.是否生成賬單 = 'N';";
            sqlList.Add(sql);
            _log.Debug(sql);
            db.ExecuteSqlTran(sqlList);
        }

        /// <summary>
        /// 生成賬單規則
        /// </summary>
        public void UpdateRule()
        {
            MsSqlDbContext<Object> msSqlDbContext = new MsSqlDbContext<object>();
            List<RoleModel> roleList = msSqlDbContext.Db.Ado
                .SqlQuery<RoleModel>("select 參數名,說明,預留2 from 基本參數表 where 是否有效='Y' and 參數類型 =N'標識代碼' order by 參數名 asc")
                .ToList();
            foreach (var roles in roleList)
            {
                string onsql = "where 1=1";
                if (roles.參數名 == null || roles.參數名[0] > 90 || roles.參數名[0] < 65)
                {
                    continue;
                }

                string[] roleArray = roles.說明.Split(';');
                foreach (string role in roleArray)
                {
                    if (!string.IsNullOrWhiteSpace(role))
                    {
                        onsql += " and RTRIM(LTRIM(REPLACE(REPLACE(REPLACE(" + role.Replace("法人", "付費法人").Trim() + ",char(9),''),char(13),''),char(10),'')))!=''";
                    }
                }
                roleArray = roles.預留2.Split(';');
                foreach (string role in roleArray)
                {
                    if (!string.IsNullOrWhiteSpace(role))
                    {
                        onsql += " and RTRIM(LTRIM(REPLACE(REPLACE(REPLACE(" + role.Replace("法人", "付費法人").Trim() + ",char(9),''),char(13),''),char(10),'')))=''";
                    }
                }
                UpdateRule(roles.參數名, onsql);
            }
        }
        public void UpdateRule(string rule, string onsql)
        {
            MsSqlDbContext<Object> msSqlDbContext = new MsSqlDbContext<object>();
            List<string> sqlList = new List<string>();
            string sql = @"INSERT INTO [生成賬單規則表] SELECT
'GZ' + RIGHT ( '00000000' + CAST (( row_number () OVER ( ORDER BY 事業群 )) + " + GetMaxRuleSeq() + @" AS nvarchar ( 32 )), 8 ) 規則編號, 事業群,
事業處,
'' 廠區, 付費法人 AS 法人,
費用代碼,
'' 賬單法人代碼,
'' 賬單法人名稱,
'" + rule + @"' 有效欄位,
'' 對賬窗口賬號,
'' 對賬窗口姓名,
'Y' 是否有效,
'auto' 建立者,
getdate() 建立時間,
'auto' 修改者,
getdate() 修改時間,
'' [預留1],
'' [預留2],
'' [預留3],
'' [預留4],
'' [預留5],
0 [預留6],
0 [預留7],
0 [預留8],
0 [預留9],
'1900/1/1' [預留10],原事業群,原法人 
FROM
	( SELECT 事業群,事業處,費用代碼,付費法人, 原事業群, 原付費法人 AS 原法人 FROM [使用者賬號信息表] " + onsql + @"GROUP BY  事業群,事業處,費用代碼,付費法人, 原事業群, 原付費法人 ) a 
WHERE
	NOT EXISTS (
	SELECT
		* 
	FROM
		[生成賬單規則表] b 
	WHERE
		a.事業群 = b.事業群 
		AND a.事業處 = b.事業處 
		AND a.費用代碼 = b.費用代碼 
		AND a.付費法人 = b.法人 
		AND a.原事業群 = b.原事業群 
		AND a.原法人 = b.原法人 
		AND b.是否有效 = 'Y' 
	) 
	AND 事業群!= '系統賬號'";
            sqlList.Add(sql);
            //更新單據取號管理
            sql = "update 單據取號管理 set 目前號碼=(select right(max(規則編號),8) from 生成賬單規則表),修改人員='auto',修改時間=getdate() where 單據類別='規則編號' and 單據名稱='規則編號' and 是否有效='Y'";
            sqlList.Add(sql);
            sql = @"delete from [生成賬單規則表] where 事業群='' and 事業處='' and 費用代碼='' and 法人=''";
            sqlList.Add(sql);
            //失效重复事业群法人
            sql = @"UPDATE a 
SET a.[是否有效] = 'N' 
FROM
	生成賬單規則表 a 
WHERE
	(事業群 +法人+事業處+費用代碼 ) IN ( SELECT 事業群+法人+事業處+費用代碼 FROM 生成賬單規則表 WHERE 是否有效= 'Y' GROUP BY 事業群, 法人,事業處,費用代碼 HAVING COUNT ( * ) > 1 ) 
	AND 規則編號 NOT IN ( SELECT MIN (規則編號) FROM 生成賬單規則表 WHERE 是否有效 = 'Y' GROUP BY 事業群,法人,事業處,費用代碼 HAVING COUNT ( * ) > 1 ) 
	AND 是否有效 = 'Y'";
            sqlList.Add(sql);
            msSqlDbContext.ExecuteSqlTran(sqlList);
        }

        /// <summary>
        /// 獲取最大的規則編號的序列號
        /// </summary>
        public int GetMaxRuleSeq()
        {
            //string sql = "select 目前號碼 from 單據取號管理 where 單據類別='規則編號' and 單據名稱='規則編號' and 是否有效='Y'";         
            MsSqlDbContext<Object> Db = new MsSqlDbContext<object>();
            string seq = Db.Db.Ado.SqlQuery<string>("select right(max(規則編號),8) from 生成賬單規則表")[0];
            if (seq == "")
            {
                seq = "0";
            }
            return Convert.ToInt32(seq);
        }


        /// <summary>
        /// 查询账号类型为vip或者push的但是不存在对应普通账号的使用者信息
        /// </summary>
        private void GetErrorTypeAccount()
        {
            MsSqlDbContext<使用者賬號信息表> Db = new MsSqlDbContext<使用者賬號信息表>();
            List<string> errList = Db.Db.Ado.SqlQuery<string>(@"SELECT
	工號 
FROM
	[dbo].[使用者賬號信息表] 
WHERE
	賬號類型 IN ( N'VIPMail賬號', N'PushMail賬號' ) 
	AND 項目= 'Notes' 
	AND 是否有效= 'Y' 
	AND 工號 NOT IN (
	SELECT
		工號 
	FROM
		使用者賬號信息表 
	WHERE
		賬號類型= N'普通賬號' 
	AND 項目= 'Notes' 
	AND 是否有效= 'Y')").ToList();
        }

        private void FindRepeatData()
        {
            string sql = @"SELECT 
	count(*)
FROM
	使用者賬號信息表 a
	INNER JOIN 使用者賬號信息表 b ON a.編號 != b.編號 
	AND a.年月 = b.[年月] 
	AND a.郵箱地址 = b.[郵箱地址] 
	AND a.項目 = b.[項目] 
	AND a.賬號類型 = b.[賬號類型] 
	and a.工號=b.工號
WHERE
	a.是否有效 = 'Y'";
            MsSqlDbContext<使用者賬號信息表> Db = new MsSqlDbContext<使用者賬號信息表>();
            var i = Db.Db.Ado.SqlQuery<int>(sql)[0];
            if (i > 0)
            {
                DbHelper dbhelper = new DbHelper();
                DataTable consigneedt = dbhelper.ExecuteSqlTable(@"SELECT DISTINCT
	                                                                    a.[工號],
	                                                                    a.[郵箱],
	                                                                    a.[姓名] 
                                                                    FROM
	                                                                    人員信息表 a
	                                                                    INNER JOIN UinR b ON a.[工號] = b.UserID 
                                                                    WHERE
	                                                                    b.RoleID = N'對賬管理員' 
	                                                                    AND a.[是否有效] = 'Y'");
                DataTable dt2 = dbhelper.ExecuteSqlTable("select * from 送審跟催模板 where 流程ID='121' and 類型=N'香信對接完成'");
                List<string> mailSqlList=new List<string>(consigneedt.Rows.Count);
                foreach (DataRow dr in consigneedt.Rows)
                {
                    string tip = dt2.Rows[0]["主旨"].ToString().Trim();
                    string content = dt2.Rows[0]["郵件頭"].ToString().Trim() + dr["姓名"].ToString().Trim().Replace("'", "''") + dt2.Rows[0]["郵件正文"].ToString().Trim() + dt2.Rows[0]["郵件結尾"].ToString().Trim();
                    string mailSql = GenerateBillBll.SendMail(dr["郵箱"].ToString().Trim(), tip, content);
                    mailSqlList.Add(mailSql);
                }
                dbhelper.ExecSqlTransaction(mailSqlList);
            }
        }
    }
}
