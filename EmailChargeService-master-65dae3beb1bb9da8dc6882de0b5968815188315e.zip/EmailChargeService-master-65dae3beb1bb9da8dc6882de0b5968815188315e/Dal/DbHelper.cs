﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Dal
{
    /// <summary>
    /// 存儲欄位對應值的類
    /// 添加人：宋玲
    /// </summary>
    public class ColumnValueInfo
    {
        public ColumnValueInfo()
        {
            this.strColumnName = "";
            this.strColumnValue = "";
            this.bValueFlag = false;
        }

        public ColumnValueInfo(string strColName, string strColValue, bool bValueFlag = false)
        {
            this.strColumnName = strColName;
            this.strColumnValue = strColValue;
            this.bValueFlag = bValueFlag;
        }

        public bool bValueFlag { get; set; } // 標記欄位值是否為公式等非具體值，默認為false[具體的某個值，可是使用''包含]
        public string strColumnName { get; set; }
        public string strColumnValue { get; set; }
    }

    public class DbHelper
    {
        //public string strConnstring = ""; 
        public log4net.ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private string strConnstring;

        /// <summary>
        /// 
        /// </summary>
        public DbHelper()
        {
            strConnstring = ConfigurationManager.ConnectionStrings["ProjectDB"].ConnectionString;
        }
        public DbHelper(string strConnstring)
        {
            this.strConnstring = strConnstring;
        }
        /// <summary>
        /// 組裝插入語句
        /// </summary>
        /// <param name="strTableName"></param>
        /// <param name="lsColInfos"></param>
        /// 添加人：宋玲 2015-01-10
        /// <returns></returns>
        public string AssemBleInsSQL(string strTableName, List<ColumnValueInfo> lsColInfos)
        {
            string strRel = "";

            if (lsColInfos == null || lsColInfos.Count <= 0)
            {
                return "";
            }
            string strCols = "";
            string strVals = "";
            foreach (ColumnValueInfo colInfo in lsColInfos)
            {
                if (colInfo.strColumnName == null || colInfo.strColumnName.Trim().Equals(""))
                {
                    throw new Exception("插入的欄位名稱存在空值");
                }
                else
                {
                    strCols += colInfo.strColumnName + ",";
                    if (colInfo.bValueFlag)
                    {
                        strVals += colInfo.strColumnValue + ",";
                    }
                    else
                    {
                        strVals += "'" + colInfo.strColumnValue + "',";
                    }
                }
            }

            strRel = "INSERT INTO " + strTableName + " (" + strCols.Substring(0, strCols.Length - 1) + ")"
                   + " VALUES(" + strVals.Substring(0, strVals.Length - 1) + ");";
            log.Debug(strRel);
            return strRel;
        }

        /// <summary>
        /// 組裝刪除語句
        /// </summary> 
        /// <param name="sTableName">表格名稱</param>
        /// <param name="lsFilters">刪除條件,若為null,或者數量為0,則刪除所有</param> 
        /// 添加人：宋玲 2015-01-10
        /// <returns>組裝後的刪除語句</returns>
        public string AssembleDelSQL(string sTableName, List<string> lsFilters)
        {
            if (sTableName == null || sTableName.Equals(""))
            {
                return "";
            }

            string strRel = "DELETE FROM ";

            string strWhere = " ";
            if (lsFilters != null && lsFilters.Count() > 0) // 若List沒有字符串，則獲取所有
            {
                strWhere = " WHERE 1=1";
                foreach (string perStr in lsFilters)
                {
                    strWhere += perStr;
                }
            }

            strRel += sTableName + strWhere;
            log.Debug(strRel);
            return strRel;
        }

        /// <summary>
        ///  組裝更新語句
        /// </summary>
        /// <param name="sTableName">表格名稱</param>
        /// <param name="lsFilters">更新條件,若為null,或者數量為0,則刪除所有</param>
        /// <param name="lsCols">更新欄位,不能為null</param>
        /// <param name="strRefTable">參考數據集</param>
        /// 添加人：宋玲 2015-01-10
        /// <returns>組裝後的更新語句</returns>
        public string AssembleUpdSQL(string sTableName, List<string> lsFilters, List<ColumnValueInfo> lsCols, string strRefTable = "")
        {
            if (sTableName == null || sTableName.Equals(""))
            {
                return "";
            }

            if (lsCols == null || lsCols.Count() <= 0)
            {
                return "";
            }

            string strRel = "UPDATE ";
            string strSet = " SET ";
            foreach (ColumnValueInfo perCol in lsCols)
            {
                strSet += " " + perCol.strColumnName + "=";
                if (perCol.bValueFlag)
                {
                    strSet += perCol.strColumnValue + ",";
                }
                else
                {
                    strSet += "'" + perCol.strColumnValue + "',";
                }
            }
            strSet = strSet.Substring(0, strSet.Length - 1);

            string strWhere = " ";
            if (lsFilters != null && lsFilters.Count() > 0) // 若List沒有字符串，則獲取所有
            {
                strWhere = " WHERE 1=1 ";
                foreach (string perStr in lsFilters)
                {
                    strWhere += perStr;
                }
            }

            strRel += sTableName + strSet + strRefTable + strWhere;
            log.Debug(strRel);
            return strRel;
        }

        /// <summary>
        ///  組裝更新語句
        /// </summary>
        /// <param name="sTableName">表格名稱</param>
        /// <param name="lsFilters">更新條件,若為null,或者數量為0,則刪除所有</param>
        /// <param name="lsCols">更新欄位,不能為null,樣式為 ColumnName=ColumnValue</param>
        /// <param name="strRefTable">參考數據集</param>
        /// 添加人：宋玲 2015-01-10
        /// <returns>組裝後的更新語句</returns>
        public string AssembleUpdSQL(string sTableName, List<string> lsFilters, List<string> lsCols, string strRefTable = "")
        {
            if (sTableName == null || sTableName.Equals(""))
            {
                return "";
            }

            if (lsCols == null || lsCols.Count() <= 0)
            {
                return "";
            }

            string strRel = "UPDATE ";
            string strSet = " SET ";
            foreach (string strPer in lsCols)
            {
                strSet += " " + strPer + ",";
            }
            strSet = strSet.Substring(0, strSet.Length - 1);

            string strWhere = " ";
            if (lsFilters != null && lsFilters.Count() > 0) // 若List沒有字符串，則獲取所有
            {
                strWhere = " WHERE 1=1 ";
                foreach (string perStr in lsFilters)
                {
                    strWhere += perStr;
                }
            }

            strRel += sTableName + strSet + strRefTable + strWhere;
            log.Debug(strRel);
            return strRel;
        }

        /// <summary>
        /// 組裝查詢SQL
        /// </summary>
        /// <param name="sTableName">查詢表</param>
        /// <param name="lsCols">查詢字段，包括命名欄位,若List沒有字符串，則獲取所有</param>
        /// <param name="lsFilters">查詢條件List</param>
        /// <param name="strSortCols">排序字段，若只有字段名，則升序，如果需要降序，須在字段後加desc,例如 Col1,Col2 desc</param>
        /// <param name="bIsDistinct">是否移除重複</param>
        /// 添加人：宋玲 2015-01-10
        /// <returns>組裝後SQL</returns>
        public string AssembleSQL(string sTableName, List<string> lsCols, List<string> lsFilters, string strSortCols = "", bool bIsDistinct = false)
        {
            if (sTableName == null || sTableName.Equals(""))
            {
                return "";
            }

            string strRel = "SELECT " + (bIsDistinct ? "DISTINCT " : "");

            string strSelCols = "";
            if (lsCols == null || lsCols.Count() <= 0) // 若List沒有字符串，則獲取所有
            {
                strSelCols += " * ";
            }
            else
            {
                foreach (string perStr in lsCols)
                {
                    strSelCols += perStr + ",";
                }

                strSelCols = " " + strSelCols.Substring(0, strSelCols.Length - 1) + " ";
            }

            string strFrom = " FROM " + sTableName + " ";
            string strWhere = "  ";
            if (lsFilters != null && lsFilters.Count() > 0) // 若List沒有字符串，則獲取所有
            {
                strWhere = " WHERE 1=1 ";
                foreach (string perStr in lsFilters)
                {
                    strWhere += perStr;
                }
            }
            string strOrder = (strSortCols.Trim().Equals("") ? "" : " order by " + strSortCols);

            strRel += (strSelCols + strFrom + strWhere + strOrder);
            log.Debug(strRel);
            return strRel;
        }


        #region 執行SQL的語句
        /// <summary>
        /// 查詢數據返回一個DataTable類型的數據
        /// </summary>
        /// <param name="sql">查詢語句</param>
        /// <returns>Datatable</returns>
        public DataTable ExecuteSqlTable(string sql)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return null;
            }

            SqlConnection conn = new SqlConnection(strConnstring);
            DataTable table = new DataTable();
            try
            {

                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(sql, strConnstring);
                adapter.SelectCommand.CommandTimeout = 0;
                adapter.Fill(table);
                adapter.Dispose();
                if (table == null)
                    return new DataTable();
            }
            catch (Exception ex)
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                    conn.Dispose();
                }
                throw ex;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
                SqlConnection.ClearPool(conn);
                //SqlConnection.ClearAllPools();
            }

            //log.Info("ExecuteSqlTable end" + sql);
            return table;
        }

        /// <summary>
        /// 判斷數據是否已經存在於數據庫中
        /// </summary>
        /// <param name="strsql"></param>
        /// <returns>true,表示存在;否則不存在</returns>
        public bool Exists(string strsql)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return false;
            }

            bool bRel = false;
            SqlConnection conn = new SqlConnection(strConnstring);
            using (conn)
            {
                using (SqlCommand cmd = new SqlCommand(strsql, conn))
                {
                    try
                    {
                        conn.Open();
                        cmd.CommandTimeout = 0;
                        object obj = cmd.ExecuteScalar();
                        if (object.Equals(obj, null) || (object.Equals(obj, System.DBNull.Value)))
                        {
                            bRel = false;
                        }
                        else
                        {
                            bRel = true;
                        }
                    }
                    catch
                    {
                        if (conn.State != ConnectionState.Closed)
                        {
                            conn.Close();
                            conn.Dispose();
                        }

                        bRel = false;
                    }
                    finally
                    {
                        cmd.Dispose();
                        conn.Dispose();
                    }
                }

                log.Info("Exists end" + strsql);
            }

            return bRel;
        }

        /// <summary>
        /// 執行帶參數的sql語句
        /// </summary>
        /// <param name="sql">sql語句</param>
        /// <param name="parameters">參數</param>
        /// <returns>成功返回真，否則返回假</returns>
        public bool ExecuteWithParameters(string sql, IDataParameter[] parameters)
        {
            SqlConnection conn = new SqlConnection(strConnstring);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                foreach (SqlParameter parameter in parameters)
                {
                    cmd.Parameters.Add(parameter);
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }
        /// <summary>
        /// 判斷是否執行存儲過程
        /// </summary>
        /// <param name="storedProcName"></param>
        /// <param name="parameters"></param>
        /// <returns>存儲過程是否執行成功</returns>
        public bool RunProcedure(string storedProcName, IDataParameter[] parameters)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return false;
            }

            bool bFlag = false;
            SqlConnection conn = new SqlConnection(strConnstring);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(storedProcName, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                foreach (SqlParameter parameter in parameters)
                {
                    cmd.Parameters.Add(parameter);
                }
                cmd.ExecuteNonQuery();
                bFlag = true;
            }
            catch (SqlException ex)
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                    conn.Dispose();
                }
                bFlag = false;
                throw ex;
                // return false;
            }
            finally
            {
                conn.Close();
            }

            log.Info("RunProcedure end" + storedProcName);
            return bFlag;
        }

        /// <summary>
        /// 執行存儲過程,並返回執行存儲過程的結果(ReturnValue)
        /// </summary>
        /// <param name="storedProcName"></param>
        /// <param name="parameters"></param>
        /// <returns>存儲過程的返回值,返回值為null或空字符串則執行失敗</returns>
        public string RunProcedures(string storedProcName, IDataParameter[] parameters)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return null;
            }

            string strfalge = "";
            SqlConnection conn = new SqlConnection(strConnstring);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(storedProcName, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                foreach (SqlParameter parameter in parameters)
                {
                    cmd.Parameters.Add(parameter);
                }
                cmd.Parameters.Add("@flag", SqlDbType.NVarChar, 200).Direction = ParameterDirection.ReturnValue;
                cmd.ExecuteNonQuery();
                strfalge = cmd.Parameters["@flag"].Value.ToString();
            }
            catch (SqlException ex)
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                    conn.Dispose();
                }

                throw ex;
            }
            finally
            {
                conn.Close();
            }

            log.Info("RunProcedures end" + storedProcName);
            return strfalge;
        }

        /// <summary>
        /// 執行存儲過程(含一個輸出參數)
        /// </summary>
        /// <param name="storedProcName"></param>
        /// <param name="parameters"></param>
        /// <returns>存儲過程的輸出值</returns>
        public string RunOvtProcedures(string storedProcName, IDataParameter[] parameters)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return null;
            }

            string strFlag = "";
            SqlConnection conn = new SqlConnection(strConnstring);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(storedProcName, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                foreach (SqlParameter parameter in parameters)
                {
                    cmd.Parameters.Add(parameter);
                }
                cmd.Parameters.Add("@p_out_rlt", SqlDbType.NVarChar, 10).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();

                strFlag = cmd.Parameters["@p_out_rlt"].Value.ToString();
            }
            catch (SqlException ex)
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                    conn.Dispose();
                }

                strFlag = "";
                throw ex;

            }
            finally
            {
                conn.Close();
                log.Info("RunOvtProcedures end" + storedProcName);
            }

            return strFlag;
        }

        /// <summary>
        /// 執行SQL語句返回執行是否成功
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public bool Execute(string sql)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return false;
            }

            SqlConnection conn = new SqlConnection(strConnstring);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                    conn.Dispose();
                }

                throw ex;
            }
            finally
            {
                if (conn.State != ConnectionState.Closed)
                {
                    conn.Close();
                    conn.Dispose();
                    SqlConnection.ClearPool(conn);
                }

                log.Info("Execute end" + sql);
            }
        }

        /// <summary>
        /// 執行SQL語句獲取某個欄位的值
        /// </summary>
        /// <param name="sql"></param>
        /// <returns>欄位的值</returns>
        public string ExecuteSql(string sql)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return null;
            }

            SqlConnection conn = new SqlConnection(strConnstring);
            string str1 = "";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                Object o = cmd.ExecuteScalar();
                str1 = Convert.ToString(o);
                return str1;
            }
            catch (Exception ex)
            {
                log.Info("ExecuteSql error " + sql);
                throw ex;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
                SqlConnection.ClearPool(conn);            
            }
        }
        #endregion

        /// <summary>
        /// 獲取表的所有欄位
        /// </summary>
        /// <returns></returns>
        public DataTable GetTableColumn(string strTableName)
        {
            if (strTableName == null || strTableName.Trim().Equals(""))
            {
                return null;
            }

            DataTable dtRel = new DataTable();
            try
            {
                List<string> lstCols = new List<string>();
                lstCols.Add(" a.name as colName");
                lstCols.Add(" a.[precision] as [precision]");
                lstCols.Add(" a.[scale] as  scale");
                lstCols.Add(" a.[max_length] as  scale");
                lstCols.Add(" b.[name] as  colType");

                List<string> lstFilters = new List<string>();
                lstFilters.Add(" and object_id=object_id('" + strTableName + "') ");

                string strTable = @" sys.columns as a INNER JOIN sys.types  as b 
                                    ON a.system_type_id=b.system_type_id AND a.user_type_id=b.user_type_id ";

                string strSQL = AssembleSQL(strTable, lstCols, lstFilters);
                if (strSQL == null || strSQL.Trim().Equals(""))
                {
                    log.Error("拼接查詢語句失敗！！！");
                    return null;
                }

                dtRel = ExecuteSqlTable(strSQL);
            }
            catch (Exception e)
            {
                log.Error("查詢數據庫失敗:" + e.Message.ToString());
                dtRel = null;
            }

            return dtRel;
        }


        #region 方法執行體，此部分有的方法用不到，不用管，直接用自己能用到的，如果沒有需要的方法，可以自己參照著寫一下。
        /// <summary>
        /// 執行sql語句返回受影響行數，
        /// </summary>
        /// <param name="sqlstring">sql語句</param>
        /// <returns>受影響行數</returns>
        public int ExecuteSqlNone(string sql)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return -1;
            }
            SqlConnection conn = new SqlConnection(strConnstring);
            SqlCommand cmd = new SqlCommand(sql, conn);
            try
            {
                conn.Open();
                int count = cmd.ExecuteNonQuery();
                return count;
            }
            catch
            {
                return 0;
            }
            finally
            {
                conn.Close();
                cmd.Dispose();
                conn.Dispose();
                log.Info("ExecuteSqlNone end" + sql);
            }
        }


        public bool ExecuteNonQuery(string sql)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return false;
            }
            SqlConnection conn = new SqlConnection(strConnstring);
            SqlCommand cmd = new SqlCommand(sql, conn);
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                return true;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
                cmd.Dispose();
                log.Info("ExecuteNonQuery end" + sql);
            }
        }

        /// <summary>
        /// 執行事務
        /// </summary>
        /// <param name="SQLStringList">語句列表</param>
        public void ExecSqlTransaction(List<string> SQLStringList)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return;
            }

            using (SqlConnection conn = new SqlConnection(strConnstring))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandTimeout = 0;
                SqlTransaction tx = conn.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    for (int n = 0; n < SQLStringList.Count; n++)
                    {
                        string strsql = SQLStringList[n].ToString();
                        if (strsql.Trim().Length > 1)
                        {
                            log.Info(strsql);
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    log.Error(ex.ToString() + " " + ex.Message.ToString());
                    throw ex;
                }
                finally
                {
                    conn.Close();
                    cmd.Dispose();
                    conn.Dispose();
                    log.Info("ExecSqlTransaction end");
                }
            }
        }

        /// <summary>
        /// 執行事務
        /// </summary>
        /// <param name="SQLStringList">語句列表</param>
        public bool ExecSqlList(List<string> SQLStringList)
        {
            bool flag = true;
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return false;
            }

            using (SqlConnection conn = new SqlConnection(strConnstring))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandTimeout = 0;
                SqlTransaction tx = conn.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    for (int n = 0; n < SQLStringList.Count; n++)
                    {
                        string strsql = SQLStringList[n].ToString();
                        if (strsql.Trim().Length > 1)
                        {
                            log.Info(strsql);
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    log.Error(ex.ToString() + "\n" + ex.Message.ToString());
                    flag = false;
                }
                finally
                {
                    conn.Close();
                    cmd.Dispose();
                    conn.Dispose();
                    log.Info("ExecSqlTransaction end");
                }
                return flag;
            }
        }

        /// <summary>
        /// 執行事務
        /// </summary>
        /// <param name="SQLStringList">組合SQL語句，每個執行語句以“；”隔開</param>
        public void ExecSqlTransaction(string SQLString)
        {
            string[] strSqls = SQLString.Split(';');
            ExecSqlTransaction(strSqls);
        }

        /// <summary>
        /// 執行事務
        /// </summary>
        /// <param name="SQLStringList">語句列表</param>
        public void ExecSqlTransaction(string[] SQLStringList)
        {
            if (strConnstring == null || strConnstring.Trim().Equals(""))
            {
                log.Error("數據庫連接字串為空");
                return;
            }
            using (SqlConnection conn = new SqlConnection(strConnstring))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandTimeout = 0;
                SqlTransaction tx = conn.BeginTransaction();
                cmd.Transaction = tx;
                try
                {
                    for (int n = 0; n < SQLStringList.Length; n++)
                    {
                        string strsql = SQLStringList[n].ToString();
                        if (strsql.Trim().Length > 1)
                        {
                            log.Info(strsql);
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    log.Error(ex.ToString() + "\n" + ex.Message.ToString());
                    throw ex;
                }
                finally
                {
                    conn.Close();
                    log.Info("ExecSqlTransaction end");
                }
            }
        }

        #endregion


        public static DataTable ListToDataTable<T>(List<T> entitys)
        {

            //检查实体集合不能为空
            if (entitys == null || entitys.Count < 1)
            {
                return new DataTable();
            }

            //取出第一个实体的所有Propertie
            Type entityType = entitys[0].GetType();
            PropertyInfo[] entityProperties = entityType.GetProperties();

            //生成DataTable的structure
            //生产代码中，应将生成的DataTable结构Cache起来，此处略
            DataTable dt = new DataTable("dt");
            for (int i = 0; i < entityProperties.Length; i++)
            {
                //dt.Columns.Add(entityProperties[i].Name, entityProperties[i].PropertyType);
                dt.Columns.Add(entityProperties[i].Name);
            }

            //将所有entity添加到DataTable中
            foreach (object entity in entitys)
            {
                //检查所有的的实体都为同一类型
                if (entity.GetType() != entityType)
                {
                    throw new Exception("要转换的集合元素类型不一致");
                }
                object[] entityValues = new object[entityProperties.Length];
                for (int i = 0; i < entityProperties.Length; i++)
                {
                    entityValues[i] = entityProperties[i].GetValue(entity, null);

                }
                dt.Rows.Add(entityValues);
            }
            return dt;
        }
    }
}
