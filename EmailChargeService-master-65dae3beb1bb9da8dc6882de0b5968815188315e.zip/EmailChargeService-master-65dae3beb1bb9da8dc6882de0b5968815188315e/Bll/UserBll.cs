﻿using Dal;
using Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Util;
using static Util.CommonUse;

namespace Bll
{
    public class UserBll
    {
        private DbHelper dbHelper = new DbHelper();
        private static readonly string adminUserAccount = System.Configuration.ConfigurationManager.AppSettings["adminUserAccount"].ToString();
        private static readonly string adminUserPasswd = System.Configuration.ConfigurationManager.AppSettings["adminUserPasswd"].ToString();
        private static readonly string emaliChargeWebserviceUrl = System.Configuration.ConfigurationManager.AppSettings["emaliChargeWebserviceUrl"].ToString();

        public bool ExistisUser(string empNo) => dbHelper.Exists("select UserName from aspnet_Users where UserName='"+empNo+"'");

        /// <summary>
        /// 自动登录工号信息获取
        /// </summary>
        /// <param name="code"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public OAuthUser UserLogin(string code, string appid)
        {
            string empo;
            string str = GetData("http://civetInterface.foxconn.com/open/get_user_info_bycode?code=" + code + "&appid=" + appid);
            OAuthUser UerInfo = JsonConvert.DeserializeObject<OAuthUser>(str);
            return UerInfo;
        }

        public string GetData(string url)
        {
            HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(url);
            myRequest.Method = "GET";
            HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
            StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);
            string content = reader.ReadToEnd();
            reader.Close();
            return content;
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="newPassword"></param>
        /// <returns></returns>
        public string ResetPassword(string userID, string newPassword)
        {
            string oldPassword = dbHelper.ExecuteSql("select convert(nvarchar,DecryptByPassphrase('Amebiz99!',UserPsw)) from User_PswInfo where UserID='" + userID + "'");
            string ameuser = CheckAmeUser(adminUserAccount, adminUserPasswd);
            IService proxy = WcfInvokeFactory.CreateServiceByUrl<IService>(emaliChargeWebserviceUrl);
            string res = proxy.ResetPwd(ameuser,userID,oldPassword,newPassword);
            if (res == "")
            {
                dbHelper.Execute("update User_PswInfo set UserPsw= EncryptByPassPhrase('Amebiz99!',N'"+newPassword+ "') where UserID='" + userID + "'");
            }
            return res;
        }



    }
}
