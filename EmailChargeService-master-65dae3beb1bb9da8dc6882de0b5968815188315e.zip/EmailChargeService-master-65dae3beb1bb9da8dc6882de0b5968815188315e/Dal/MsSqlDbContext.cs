﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Dal
{
    public class MsSqlDbContext<T> where T : class, new()
    {
        log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        public MsSqlDbContext()
        {
            Db = new SqlSugarClient(new ConnectionConfig()
            {
                ConnectionString = System.Configuration.ConfigurationManager.AppSettings["mssql"],
                DbType = DbType.SqlServer,
                InitKeyType = InitKeyType.Attribute,//从特性读取主键和自增列信息
                IsAutoCloseConnection = true,//开启自动释放模式和EF原理一样我就不多解释了

            });
            //调式代码 用来打印SQL 
            //Db.Aop.OnLogExecuting = (sql, pars) =>
            //{
            //    Log.Info(sql + "\r\n" +
            //        Db.Utilities.SerializeObject(pars.ToDictionary(it => it.ParameterName, it => it.Value)));
            //};

        }
        //注意：不能写成静态的
        public SqlSugarClient Db;//用来处理事务多表查询和复杂的操作
        public SimpleClient<T> CurrentDb { get { return new SimpleClient<T>(Db); } }//用来操作当前表的数据


        //执行事务
        public bool ExecuteSqlTran(List<string> sqlList)
        {
            int i=0;
            try
            {
                Db.Ado.BeginTran();
                foreach (string sqlStr in sqlList)
                {
                    Db.Ado.SqlQuery<object>(sqlStr);
                    i++;
                }
                Db.Ado.CommitTran();
            }
            catch (Exception ex)
            {
                Db.Ado.RollbackTran();
                Log.Info(ex.ToString());
                Log.Info(sqlList[i]);
                return false;
            }
            return true;
        }
    }
}
