﻿using Dal;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bll
{
    public class RuleBll
    {
        private class Nested
        {
            internal static readonly RuleBll Instance = new RuleBll();
        }
        private RuleBll() { }
        public static RuleBll Instance = Nested.Instance;

        public string UpdateRule()
        {
            string res = "";
            string[] tableNameArray = new string[] { "使用者賬號信息表", "使用者賬號上月表", "使用者賬號歷史表", "使用者賬號未出賬表" };
            foreach (string tablename in tableNameArray)
            {
                res += UpdateReconciliationUser(tablename);
            }
            return res;
        }
        public string UpdateRule(string bg)
        {
            string res = "";
            string[] tableNameArray = new string[] { "使用者賬號信息表", "使用者賬號上月表", "使用者賬號歷史表", "使用者賬號未出賬表" };
            foreach(string tablename in tableNameArray)
            {
                res+=UpdateReconciliationUser(tablename, bg);
            }
            return res;
        }
        public string UpdateReconciliationUser(string tablename, string bg = "")
        {
            MsSqlDbContext<Object> db = new MsSqlDbContext<object>();
            List<string> sqlList = new List<string>();
            string sql = "";
            sql = $@"UPDATE {tablename} 
SET 對賬窗口賬號 = '', 對賬窗口姓名 = '',
賬單法人代碼 = '',
賬單法人名稱 = '',
對賬窗口聯繫方式 = '',
對賬窗口郵箱地址 = '', 修改者 = 'RuleUpdate',
修改時間 = getdate() 
FROM
	{tablename}
WHERE
	是否有效 = 'Y' 
	AND 賬號狀態 IN ( '新建', '停用', '停用待接收', '已移除', '已送出' ) 
	AND 是否生成賬單 = 'N' ";
            if (bg != "")
            {
                sql +=$"AND 事業群 = '{bg}'";
            }
            sqlList.Add(sql);
            List<RoleModel> roleList = db.Db.Ado.SqlQuery<RoleModel>("select 參數名,說明 from 基本參數表 where 是否有效='Y' and 參數類型 =N'標識代碼' order by 參數名 asc").ToList();
            foreach (var roles in roleList)
            {
                string onsql = "";
                if (roles.參數名 == null || roles.參數名[0] > 90 || roles.參數名[0] < 65)
                {
                    continue;
                }
                string[] roleArray = roles.說明.Split(';');
                foreach (string role in roleArray)
                {
                    if (!string.IsNullOrWhiteSpace(role))
                    {
                        onsql += " and a." + role.Replace("法人", "付費法人") + "=b." + role;
                    }
                }
                onsql = onsql.Substring(5);
                sql = $@"UPDATE a 
SET a.對賬窗口賬號 = b.對賬窗口賬號,對賬窗口姓名 = b.對賬窗口姓名,
a.賬單法人代碼 = b.賬單法人代碼,
a.賬單法人名稱 = b.賬單法人名稱,
a.修改者='RuleUpdate',
a.修改時間=getdate()
FROM
    {tablename} a
    INNER JOIN 生成賬單規則表 b
    ON {onsql} 
    WHERE
    b.有效欄位 = '{roles.參數名}'
    AND a.是否有效 = 'Y'
    AND b.是否有效 = 'Y'
	AND b.對賬窗口賬號 != '' 
	AND b.賬單法人代碼 != ''
	AND a.賬號狀態 IN ( '新建', '停用', '停用待接收', '已移除', '已送出' ) 
	AND a.是否生成賬單 = 'N' ";
                if (bg != "")
                {
                    sql += $"AND a.事業群 = '{bg}'";
                }
                sqlList.Add(sql);
                //_log.Debug(sql);
            }
            sql = $@"UPDATE a 
SET a.對賬窗口聯繫方式 = b.分機號碼,
a.對賬窗口郵箱地址 = b.郵箱
FROM
    {tablename} a
    INNER JOIN 人員信息表 b ON a.對賬窗口賬號 = b.工號
WHERE
    a.是否有效 = 'Y'
    AND b.是否有效 = 'Y'
	AND a.對賬窗口賬號 != '' 
	AND a.賬單法人代碼 != ''
	AND a.賬號狀態 IN ( '新建', '停用', '停用待接收', '已移除', '已送出' ) 
	AND a.是否生成賬單 = 'N' ";
            if (bg != "")
            {
                sql += $"AND a.事業群 = '{bg}'";
            }
            sqlList.Add(sql);
            //_log.Debug(sql);
            try
            {
                db.ExecuteSqlTran(sqlList);
                return "";
            }
            catch (Exception ex)
            {
                return $"{tablename}表{bg}事业群的账单规则更新执行失败,失败原因为{ex}";
            }
        }
    }
}
