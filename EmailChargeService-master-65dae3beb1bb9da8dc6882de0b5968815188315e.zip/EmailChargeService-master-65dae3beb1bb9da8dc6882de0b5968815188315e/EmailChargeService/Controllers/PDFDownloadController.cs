﻿using Bll;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmailChargeService.Controllers
{
    public class PDFDownloadController : Controller
    {
        private DownloadBll downloadBll = new DownloadBll();
        // GET: PDFDownload
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult DownZip(string id,string downstring)
        {
            ViewData["FileName"] = id;
            ViewData["DateNo"] = downstring;
            return View();
        }

        public JsonResult QueryDownloadTable()
        {
            LayuiResult<EmailFee> layuiResult = downloadBll.QueryDownloadTable();
            return Json(layuiResult, JsonRequestBehavior.AllowGet);
        }

        public string DownloadQuery(string id, string downstring)
        {
            string res = downloadBll.DownLoadPdf(id, downstring);
            return res;
        }
    }
}