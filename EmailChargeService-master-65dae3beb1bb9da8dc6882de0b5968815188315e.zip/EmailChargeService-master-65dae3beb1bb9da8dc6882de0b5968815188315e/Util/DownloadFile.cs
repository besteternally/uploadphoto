﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Util
{
    public static class DownloadFile
    {
        private const string UserName = "RDUser";
        private const string PassWord = "8HSQmpUYnkzG";
        //private const string UserName = "NJ";
        //private const string PassWord = "Amebiz99";

        /// <summary>
        /// 下载对账单
        /// </summary>
        /// <param name="url"></param>
        /// <param name="orderNum"></param>
        /// <param name="outputPath"></param>
        public static void DownLoadFileByUrl(string url, string orderNum, string outputPath)
        {
            if (!Directory.Exists(outputPath))//如果路径不存在
            {
                Directory.CreateDirectory(outputPath);//创建一个路径的文件夹
            }
            WebClient webClient = new WebClient { UseDefaultCredentials = true };
            string credentials = Convert.ToBase64String(
                Encoding.ASCII.GetBytes(UserName + ":" + PassWord));
            webClient.Headers[HttpRequestHeader.Authorization] = $"Basic {credentials}";
            webClient.Headers[HttpRequestHeader.UserAgent] = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36";
            try
            {
                webClient.DownloadFile(url, outputPath + orderNum + "Report.pdf");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static CredentialCache GetCredentialCache(string uri, string username, string password)
        {
            string authorization = $"{username}:{password}";
            CredentialCache credCache = new CredentialCache
            {
                {new Uri(uri), "Basic", new NetworkCredential(username, password)}
            };
            return credCache;
        }
        private static string GetAuthorization(string username, string password)
        {
            string authorization = $"{username}:{password}";
            return "Basic " + Convert.ToBase64String(new ASCIIEncoding().GetBytes(authorization));
        }
        private static void ForceCanonicalPathAndQuery(Uri uri)
        {
            string paq = uri.PathAndQuery; // need to access PathAndQuery
            FieldInfo flagsFieldInfo = typeof(Uri).GetField("m_Flags", BindingFlags.Instance | BindingFlags.NonPublic);
            if (flagsFieldInfo != null)
            {
                ulong flags = (ulong)flagsFieldInfo.GetValue(uri);
                flags &= ~((ulong)0x30); // Flags.PathNotCanonical|Flags.QueryNotCanonical
                flagsFieldInfo.SetValue(uri, flags);
            }
        }
        /// <summary>
        /// 下载转嫁单
        /// </summary>
        /// <param name="url"></param>
        /// <param name="orderNum"></param>
        /// <param name="outputPath"></param>
        /// <param name="dateNo"></param>
        public static void DownLoadFileByUrl(string url, string orderNum, string outputPath, string dateNo)
        {
            if (!Directory.Exists(outputPath))//如果路径不存在
            {
                Directory.CreateDirectory(outputPath);//创建一个路径的文件夹
            }
            Uri uri = new Uri(url);
            ForceCanonicalPathAndQuery(uri);
            WebClient webClient = new WebClient { UseDefaultCredentials = true };
            string credentials = Convert.ToBase64String(
                Encoding.ASCII.GetBytes(UserName + ":" + PassWord));
            webClient.Headers[HttpRequestHeader.Authorization] = $"Basic {credentials}";
            webClient.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36");
            webClient.Headers.Add("Host", "10.134.96.126");
            webClient.DownloadFile(url, outputPath + dateNo + orderNum + "Report.pdf");
        }

        /// <summary>
        /// 下载转嫁单Excel
        /// </summary>
        /// <param name="url"></param>
        /// <param name="orderNum"></param>
        /// <param name="outputPath"></param>
        /// <param name="dateNo"></param>
        public static void DownLoadExcelByUrl(string url, string orderNum, string outputPath, string dateNo)
        {
            if (!Directory.Exists(outputPath))//如果路径不存在
            {
                Directory.CreateDirectory(outputPath);//创建一个路径的文件夹
            }
            Uri uri = new Uri(url);
            ForceCanonicalPathAndQuery(uri);
            WebClient webClient = new WebClient { UseDefaultCredentials = true };
            string credentials = Convert.ToBase64String(
                Encoding.ASCII.GetBytes(UserName + ":" + PassWord));
            webClient.Headers[HttpRequestHeader.Authorization] = $"Basic {credentials}";
            webClient.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36");
            webClient.Headers.Add("Host", "10.134.96.126");
            webClient.DownloadFile(url, outputPath + dateNo + orderNum + "Report.xls");
        }

        /// <summary>
        /// 下载样式报表Excel
        /// </summary>
        /// <param name="url">样式报表url</param>
        /// <param name="outputPath">目标文件</param>
        public static void DownLoadFileByUrl(string url, string outputPath)
        {
            WebClient webClient = new WebClient { UseDefaultCredentials = true };
            string credentials = Convert.ToBase64String(
                Encoding.ASCII.GetBytes(UserName + ":" + PassWord));
            webClient.Headers[HttpRequestHeader.Authorization] = $"Basic {credentials}";
            webClient.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36");
            webClient.Headers.Add("Host", "10.134.96.126");
            try
            {
                webClient.DownloadFile(url, outputPath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            string pdfurl = System.Threading.Thread.GetDomain().BaseDirectory + "/DownLoad/PDF/" + DateTime.Now.ToString("yyyyMM");
            if (!Directory.Exists(pdfurl))
            {
                Directory.CreateDirectory(pdfurl);
            }
            File.Copy(outputPath, pdfurl + "/" + DateTime.Now.ToString("yyyyMMdd") + "purchasingstyle.xls",true);
        }

        public static void DownloadCompressFile(string filePath)
        {
            WebClient webClient = new WebClient();
            webClient.DownloadFile(filePath, "dzd.zip");
        }

    }
}
